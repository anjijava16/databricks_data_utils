# Databricks notebook source
print(" Spark Structured Straeming Kafka with Python MDL Flow ")

# COMMAND ----------

# Adding All Notebook realated Import statements

# COMMAND ----------

from pyspark.sql import SparkSession

# COMMAND ----------

# Adding All Constants Utils

# COMMAND ----------

bootstartup_Servers="localhost:9092";
topicName="mds-dev-report-edl-flow";


# COMMAND ----------

# Connect With Kafka Streaming Using as Spark 

# COMMAND ----------

dsraw = spark \
  .readStream \
  .format("kafka") \
  .option("kafka.bootstrap.servers", bootstartup_Servers) \
  .option("subscribe", topicName) \
  .option("startingOffsets", "earliest") \
  .load()

# COMMAND ----------

display(dsraw)

# COMMAND ----------



# COMMAND ----------

ds = dsraw.selectExpr("CAST(value AS STRING)")

dsraw.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")


# COMMAND ----------

# Create output for Spark Structured Streaming

# COMMAND ----------

rawQuery = dsraw \
        .writeStream \
        .queryName("qraw")\
        .format("memory")\
        .start()

# COMMAND ----------

alertQuery = ds \
        .writeStream \
        .queryName("qalerts")\
        .format("memory")\
        .start()

# COMMAND ----------



# COMMAND ----------

raw = spark.sql("select * from qraw")
raw.show()

# COMMAND ----------

alerts = spark.sql("select * from qalerts")
alerts.show()