// Databricks notebook source
// MAGIC
// MAGIC %md # Course: IDBML
// MAGIC * Version 1.0.0
// MAGIC * Built 2021-06-23 13:24:01 UTC
// MAGIC * Git revision: c979b9e7dd282e917ced3439cb4f70c04a82fbcd
// MAGIC
// MAGIC Copyright © 2021 Databricks, Inc.