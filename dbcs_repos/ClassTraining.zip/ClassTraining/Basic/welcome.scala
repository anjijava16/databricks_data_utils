// Databricks notebook source
// MAGIC %scala
// MAGIC print("hii")
// MAGIC
// MAGIC print(spark)