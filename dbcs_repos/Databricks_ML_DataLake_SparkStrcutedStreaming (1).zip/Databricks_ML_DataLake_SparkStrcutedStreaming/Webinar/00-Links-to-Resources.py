# Databricks notebook source
# MAGIC %md
# MAGIC Check out these great articles, presentations, and resources:
# MAGIC * https://delta.io/
# MAGIC * https://docs.databricks.com/delta/delta-streaming.html
# MAGIC * https://databricks.com/blog/2017/05/22/running-streaming-jobs-day-10x-cost-savings.html
# MAGIC * https://databricks.com/session/keynote-from-apple
# MAGIC * https://academy.databricks.com/