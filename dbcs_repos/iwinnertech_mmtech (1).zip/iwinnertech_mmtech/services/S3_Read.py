# Databricks notebook source
# MAGIC %run ./include/utils

# COMMAND ----------

print(NAME)

# COMMAND ----------

