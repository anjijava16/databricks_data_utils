# Databricks notebook source
# MAGIC %md
# MAGIC ## Update Downstream System 

# COMMAND ----------

from random import randint
from time import sleep
import os
# connect to external API 
# retrieve data for last 12 month
# 
#

def ingest_all_orders():
  msg="connection refused: external API"
  
  # comment out the command below that causes the error (by adding a #). make sure to keep the indentation same as this comment here. 
  raise ConnectionError(msg)
    
    
    
# call the method to simulate an error    
ingest_all_orders()
    

# COMMAND ----------

