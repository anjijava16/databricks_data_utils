// Databricks notebook source
// MAGIC
// MAGIC %md # Course: ml-models
// MAGIC * Version 1.0.0
// MAGIC * Built 2020-08-23 18:34:58 UTC
// MAGIC * Git revision: 5219d501e33b57d218279335ca0d074a27c52363
// MAGIC
// MAGIC Copyright © 2020 Databricks, Inc.