# Databricks notebook source

import numpy as np
from sklearn.metrics import r2_score
from sklearn.linear_model import LogisticRegression
from sklearn.base import BaseEstimator

class AdaptiveLassoLogisticRegression(BaseEstimator):

    def __init__(self, alpha=1.0, n_iter=5):
        self.alpha   = alpha
        self.n_iter  = n_iter
        self._g      = lambda w: np.sqrt(np.abs(w))
        self._gprime = lambda w: (
            1. / (2. * np.sqrt(np.abs(w)) + np.finfo(float).eps)
        )

    def fit(self, X, y, eps=1):
        n_samples, n_features = X.shape
        p_obj = lambda w: (
            1. / (2 * n_samples) * np.sum((y - np.dot(X, w)) ** 2) +
            alpha * np.sum(self._g(w))
        )
        weights = np.ones(n_features)

        for k in range(self.n_iter):
            X_w = X / weights[np.newaxis, :]
            clf = LogisticRegression(C=1/self.alpha, solver='saga', penalty='l1', max_iter=10000)
            clf.fit(X_w, y)
            self.coef_ = clf.coef_ / weights
            self.intercept_ = clf.intercept_
            weights = self._gprime(self.coef_)

    def predict(self, X):
        return X @ self.coef_ + self.intercept_

    def score(self, X, y):
        yhat = self.predict(X)
        return r2_score(y, yhat)
