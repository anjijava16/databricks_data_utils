# Databricks notebook source

import os
import pandas as pd
import numpy as np
import mlflow

from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error

# COMMAND ----------

# MAGIC %run ./configuration

# COMMAND ----------

def mlflow_run(experiment_id, estimator, param_grid, data):
    (X_train, X_test, y_train, y_test) = data

    with mlflow.start_run(experiment_id=experiment_id) as run:
        gs = GridSearchCV(estimator, param_grid)
        gs.fit(X_train, y_train)

        train_acc = gs.score(X_train, y_train)
        test_acc = gs.score(X_test, y_test)
        mlflow.log_param("model",
                         (str(estimator.__class__)
                          .split('.')[-1].replace("'>","")))

        np.save("model_coefs.npy", gs.best_estimator_.coef_)
        mlflow.log_artifact("model_coefs.npy")
        for param, value in gs.best_params_.items():
            mlflow.log_param(param, value)
        mlflow.log_metric("train acc", train_acc)
        mlflow.log_metric("test acc", test_acc)
        os.remove("model_coefs.npy")

# COMMAND ----------

def prepare_results(experiment_id):
    results = mlflow.search_runs()
    columns = [
      col for col in results.columns
      if any([
        'metric' in col,
        'param' in col,
        'artifact' in col
      ])
    ]
    return results[columns]

# COMMAND ----------

def prepare_coefs(experiment_id):
    desc_test_r2 = "metrics.`test r2` DESC"
    results = mlflow.search_runs(experiment_id,
                                 order_by=[desc_test_r2])
    param_columns = [col for col in results.columns if 'param' in col]
    coefs = (results[param_columns + ["artifact_uri"]]
             .set_index(param_columns)
             .sort_values(param_columns))
    coefs["artifact"] = (coefs.artifact_uri
                         .apply(lambda x: np.load(x + "/model_coefs.npy")
                                .reshape((13,))))
    coefs_df = pd.DataFrame(coefs.artifact.tolist(), index=coefs.index)
    coefs_df.columns = columns = [
        "lp", "v", "gtt", "gtn", "ggn", "tp", "t48", "t2",
        "p48", "p2", "pexh", "tic", "mf"
    ]
    ax = coefs_df.T.plot(figsize=(20,7))
    ax.set_xticks(range(len(coefs_df.columns)));
    ax.set_xticklabels(coefs_df.columns.tolist(), rotation=45)
    return coefs_df, ax
