# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab: Running a Project within a Project
# MAGIC
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) In this lab you:<br>
# MAGIC - Check directory for appropriate files
# MAGIC - Create and run a driver-less workflow

# COMMAND ----------

# MAGIC %run "./../Includes/Classroom-Setup"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Check for Appropriate Files
# MAGIC
# MAGIC This lab will reuse your work from lesson 3.  Run the following 2 cells to check that your `/user/ < username > /ml-production` folder still contains the files created and saved in the 03 notebook.
# MAGIC
# MAGIC Under `train_path`, you should have the following 3 files: 
# MAGIC * `MLproject`
# MAGIC * `conda.yaml`
# MAGIC * `train.py`
# MAGIC
# MAGIC Under `load_path`, you should have the following 3 files: 
# MAGIC * `MLproject`
# MAGIC * `conda.yaml`
# MAGIC * `load.py`
# MAGIC
# MAGIC <img alt="Side Note" title="Side Note" style="vertical-align: text-bottom; position: relative; height:1.75em; top:0.05em; transform:rotate(15deg)" src="https://files.training.databricks.com/static/images/icon-note.webp"/> If these files are not present, [re-run Lesson 3.]($../03-Packaging-ML-Projects )

# COMMAND ----------

train_path = userhome + "/ml-production/mlflow-model-training/"

dbutils.fs.ls(train_path)

# COMMAND ----------

load_path = userhome + "/ml-production/mlflow-data-loading/"

dbutils.fs.ls(load_path)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## Create a Driver-less Workflow
# MAGIC
# MAGIC At the end of notebook 3, we retrieved the data path artifact saved from the data loading run and used that as the `data_path` parameter of our training code. We did this by making two separate calls to `mlflow.projects.run`.
# MAGIC
# MAGIC <div><img src="https://files.training.databricks.com/images/eLearning/ML-Part-4/mlproject-architecture3.png" style="height: 250px; margin: 20px"/></div>
# MAGIC
# MAGIC Now we want log the same projects but through **only 1 explicit `mlflow.projects.run` call.**  In other words, the first project should call the second project:<br><br>
# MAGIC
# MAGIC 1. Edit the following `data_load` function to take in `train_path` as an additional parameter 
# MAGIC 2. Call the MLproject saved at `train_path` as its last step

# COMMAND ----------

# TODO
import mlflow

def data_load(data_input_path, FILL_IN):

  with mlflow.start_run() as run:
    # Log the data
    mlflow.log_artifact(data_input_path, "data-csv-dir")
  # FILL IN

if __name__ == "__main__":
  data_load( "/dbfs/mnt/training/airbnb/sf-listings/airbnb-cleaned-mlflow.csv", train_path.replace("dbfs:", "/dbfs"))

# COMMAND ----------

# MAGIC %md
# MAGIC Double check that the UI correctly logged your 2 project runs (the data loading and then training) from above by comparing it to the last 2 runs from the end of the 03 notebook.
# MAGIC
# MAGIC Then fill in the below code to overwrite the original `load.py` file to have the new `data_load(data_input_path, train_path)` function. Be sure to add an appropriate `@click.option` for the new `train_path` parameter.

# COMMAND ----------

#  TODO
dbutils.fs.put(load_path + "/load.py", 
'''
import click
import mlflow

@click.command()
@click.option("--data_input_path", default="/dbfs/mnt/training/airbnb/sf-listings/airbnb-cleaned-mlflow.csv", type=str)
@click.option(FILL_IN)
def data_load(data_input_path, FILL_IN):
  # REPLACE WITH data_load FUNCTION WRITTEN ABOVE

if __name__ == "__main__":
  data_load()

'''.strip(), overwrite = True)

dbutils.fs.ls(load_path)

# COMMAND ----------

# MAGIC %md
# MAGIC Lastly, fill in the following single `mlflow.projects.run` call to directly run the loading data project which should then indirectly invoke the training code, all on the driver node of our Spark cluster. 

# COMMAND ----------

# TODO

mlflow.projects.run(load_path.replace("dbfs:", "/dbfs"), 
  parameters = {
  # FILL_IN
})

# COMMAND ----------

# MAGIC %md
# MAGIC Check that these logged runs also show up properly on the MLflow UI. 
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2019 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>