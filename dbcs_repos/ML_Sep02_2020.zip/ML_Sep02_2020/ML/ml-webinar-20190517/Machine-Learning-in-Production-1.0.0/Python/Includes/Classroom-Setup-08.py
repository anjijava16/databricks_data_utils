# Databricks notebook source
# MAGIC
# MAGIC %python
# MAGIC module_name = "Time Travel"

# COMMAND ----------

# MAGIC %run ./Classroom-Setup

# COMMAND ----------

basePath = userhome+"/time-travel"

def getOrCreateMLfowRun(experimentPath):
  
  import mlflow
  from mlflow.exceptions import MlflowException
  from mlflow.tracking import MlflowClient

  try:
    experimentID = mlflow.create_experiment(experimentPath)
  except MlflowException:
    experimentID = MlflowClient().get_experiment_by_name(experimentPath).experiment_id
    mlflow.set_experiment(experimentPath)
    
  return experimentID

None # Suppress Output
