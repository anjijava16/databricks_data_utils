# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Querying Data Lakes with SQL
# MAGIC
# MAGIC Apache Spark&trade; and Databricks&reg; make it easy to work with hierarchical data, such as nested JSON records.
# MAGIC
# MAGIC Perform exploratory data analysis (EDA) to gain insights from a Data Lake.
# MAGIC
# MAGIC ## In this lesson you:
# MAGIC * Use SQL to query a Data Lake
# MAGIC * Clean messy data sets
# MAGIC * Join two cleaned data sets
# MAGIC
# MAGIC ## Audience
# MAGIC * Primary Audience: Data Analysts
# MAGIC * Additional Audiences: Data Engineers and Data Scientists
# MAGIC
# MAGIC ## Prerequisites
# MAGIC * Web browser: Chrome or Firefox
# MAGIC * Lesson: <a href="$./02-Querying-Files">Querying Files with SQL</a>
# MAGIC * Concept: <a href="https://www.w3schools.com/sql/" target="_blank">Basic SQL</a>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Lakes
# MAGIC
# MAGIC Companies frequently have thousands of large data files gathered from various teams and departments, typically using a diverse variety of formats including CSV, JSON, and XML.  Analysts often wish to extract insights from this data.
# MAGIC
# MAGIC The classic approach to querying this data is to load it into a central database called a Data Warehouse.  This involves the time-consuming operation of designing the schema for the central database, extracting the data from the various data sources, transforming the data to fit the warehouse schema, and loading it into the central database.  The analyst can then query this enterprise warehouse directly or query smaller data marts created to optimize specific types of queries.
# MAGIC
# MAGIC This classic Data Warehouse approach works well but requires a great deal of upfront effort to design and populate schemas.  It also limits historical data, which is restrained to only the data that fits the warehouse’s schema.
# MAGIC
# MAGIC An alternative to this approach is the Data Lake.  A _Data Lake_:
# MAGIC
# MAGIC * Is a storage repository that cheaply stores a vast amount of raw data in its native format
# MAGIC * Consists of current and historical data dumps in various formats including XML, JSON, CSV, Parquet, etc.
# MAGIC * Also may contain operational relational databases with live transactional data
# MAGIC
# MAGIC Spark is ideal for querying Data Lakes as the Spark SQL query engine is capable of reading directly from the raw files and then executing SQL queries to join and aggregate the Data.
# MAGIC
# MAGIC You will see in this lesson that once two tables are created (independent of their underlying file type), we can join them, execute nested queries, and perform other operations across our Data Lake.

# COMMAND ----------

# MAGIC %md
# MAGIC # Purchase for this lesson
# MAGIC This lesson is available in the full paid version of this course.  You can purchase it at:
# MAGIC https://academy.databricks.com/course/getting-started-with-apache-spark-sql-and-aws-databricks

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2019 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>