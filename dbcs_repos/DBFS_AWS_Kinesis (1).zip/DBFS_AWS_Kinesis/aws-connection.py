# Databricks notebook source
dbutils.fs.unmount("/mnt/s3data")

# COMMAND ----------

dbutils.fs.ls("/mnt/")

# COMMAND ----------

import urllib
ACCESS_KEY="AKIA5QDW56UI62CXCSAA"
SECR_KEY="yLyUPCNpJBunCceDSsXBdU6ePYGtRAlcY/8QOJo8"
ENCODED_SEC_KEY=urllib.parse.quote(SECR_KEY,"")
AWS_BUCKET_NAME="databricks-mmtech-ops"
MOUNT_DATA="s3data"
dbutils.fs.mount("s3n://%s:%s@%s"%(ACCESS_KEY,ENCODED_SEC_KEY,AWS_BUCKET_NAME),"/mnt/%s" %MOUNT_DATA)

# COMMAND ----------

display(dbutils.fs.ls("/mnt/s3data/"))

# COMMAND ----------

file_Location="dbfs:/mnt/s3data/amazon_revenue_profit.csv"
file_type="csv"

#CSV OPTIONS
infer_schema="true"
first_row_is_header="true"
delimiter=","
df=spark.read.format(file_type)\
        .option("inferSchema",infer_schema) \
        .option("header",first_row_is_header) \
        .option("sep",delimiter) \
        .load(file_Location)


# COMMAND ----------

display(df)

# COMMAND ----------

MOUNT_NAME="s3data"
df.write.save('/mnt/{}/{}'.format(MOUNT_NAME, "dev"), format='csv')

# COMMAND ----------

file_new_Location="dbfs:/mnt/s3data/dev"
df_read=spark.read.format("csv").load(file_new_Location)

# COMMAND ----------

display(df_read)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE external TABLE amazon_price
# MAGIC (
# MAGIC  Quarter string,
# MAGIC  Revenue int,
# MAGIC  Net int
# MAGIC )
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
# MAGIC STORED AS TEXTFILE LOCATION '/mnt/s3data/amazon_price/';

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from amazon_price

# COMMAND ----------

