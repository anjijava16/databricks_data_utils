# Databricks notebook source
# MAGIC %md 
# MAGIC
# MAGIC # CARTO and Databricks Webinar
# MAGIC
# MAGIC This is the notebook used in the "Using CARTO & Databricks for Spatial Data Science" webinar.
# MAGIC
# MAGIC It shows several examples of how to use CARTOframes within a Databricks notebook to visualize data, read and write data from the CARTO platform, perform spatial analysis tasks and enrich your datasets with CARTO [Data Observatory](https://carto.com/spatial-data-catalog/).
# MAGIC
# MAGIC CARTOframes is a **Python library** that brings **spatial data stored in your CARTO account into a Python data science environment**, and allows you to **build and publish visualizations**, leverage **location data services**, and **enrich your spatial data with our Data Observatory** quickly and easily.
# MAGIC
# MAGIC You can learn more about CARTOframes and CARTO with these links:
# MAGIC
# MAGIC - [CARTO Homepage](https://carto.com/)
# MAGIC - [CARTOframes Documentation & Examples](https://carto.com/developers/cartoframes/)
# MAGIC - [CARTOframes v1 Announcement](https://carto.com/blog/spatial-analysis-cartoframes-release-announcement/)
# MAGIC - [CARTO Developers Center](https://carto.com/developers/)

# COMMAND ----------

# MAGIC %md # Getting started
# MAGIC
# MAGIC First, let's import some libraries so we can use CARTOframes. We will authenticate against your CARTO account, and we can bring in some different CARTOframes libraries as well.

# COMMAND ----------

dbutils.library.installPyPI('cartoframes', version='1.0.4')
import logging
logging.getLogger("py4j").setLevel(logging.ERROR)

# COMMAND ----------

import pandas as pd
from geopandas import GeoDataFrame, points_from_xy
import geopandas as gpd
import time

from cartoframes import read_carto, to_carto
from cartoframes.auth import set_default_credentials, Credentials
from cartoframes.viz import Map, Layer, basemaps
from cartoframes.data.clients import SQLClient

username = 'username' # <-- insert your username here
api_key = 'api_key'   # <-- insert your API key here

set_default_credentials(
    username=username,
    api_key=api_key
)

credentials = Credentials(
    username=username,
    api_key=api_key
)

sql = SQLClient(credentials)

# COMMAND ----------

# MAGIC %md # Read data, visualize, and import to CARTO
# MAGIC
# MAGIC First, let's take a look at the data. We are going to use a CSV file with **Target store locations around the United States**. You can download this dataset from Kaggle:
# MAGIC https://www.kaggle.com/ben1989/target-store-dataset
# MAGIC
# MAGIC We will view the locations on a map, then import that file to a table in CARTO. It will then be stored on our PostGIS database.

# COMMAND ----------

target = pd.read_csv('path_to_csv_file') # <-- Substitute with the path to your CSV file (local or URL)
target.head(2)

# COMMAND ----------

# MAGIC %md ### Transform our Pandas DataFrame to a GeoPandas GeoDataFrame

# COMMAND ----------

gdf = GeoDataFrame(target, geometry=points_from_xy(target['Longitude'], target['Latitude']))
gdf.head(2)

# COMMAND ----------

# MAGIC %md ### Create a map with CARTOframes to see our points on a map

# COMMAND ----------

from cartoframes.viz import Layer

Layer(gdf)

# COMMAND ----------

# MAGIC %md ### Upload our data to CARTO to store the data

# COMMAND ----------

to_carto(gdf, 'target_stores', if_exists='replace')

# COMMAND ----------

# MAGIC %md # Read data from CARTO and build a dashboard
# MAGIC
# MAGIC Let's retrieve our data back from CARTO and make a dashboard, and publish it so others can see!

# COMMAND ----------

# MAGIC %md ### Call either a dataset name or SQL query from CARTO to retrieve data

# COMMAND ----------

target = read_carto('SELECT * FROM target_stores', decode_geom=True)

# COMMAND ----------

target.head()

# COMMAND ----------

# MAGIC %md ### Create a dashboard using CARTOframes visualization toolkit
# MAGIC
# MAGIC Learn more about the different visualization methods [here](https://carto.com/developers/cartoframes/examples/#example-data-visualization).

# COMMAND ----------

from cartoframes.viz import Map, Layer, basemaps, color_category_legend, category_widget, color_category_style, formula_widget, category_widget, popup_element


Map(
    Layer(
    'target_stores',
     color_category_style('subtype'),
    popup_click=[
        popup_element('store_name', 'Store'),
        popup_element('formatted', 'Address')
    ],
     widgets=[
        formula_widget(
            value='count',
            title='Number of Stores in View',
            description='Zoom and/or pan the map to update count'
        ),
        category_widget(
            'state',
            title='State'
        )
    ]
),
legends=color_category_legend(),
basemap=basemaps.darkmatter
)


# COMMAND ----------

# MAGIC %md ### Publish the final dashboard to your CARTO account
# MAGIC
# MAGIC Learn more about publishing maps [here](https://carto.com/developers/cartoframes/examples/#example-publish-and-share).

# COMMAND ----------

map_viz = Map(
    Layer(
    'target_stores',
     color_category_style('subtype'),
    popup_click=[
        popup_element('store_name', 'Store'),
        popup_element('formatted', 'Address')
    ],
     widgets=[
        formula_widget(
            value='count',
            title='Number of Stores in View',
            description='Zoom and/or pan the map to update count'
        ),
        category_widget(
            'state',
            title='State'
        )
    ]
),
legends=color_category_legend(),
basemap=basemaps.darkmatter
)


# COMMAND ----------

map_viz.publish(
    name='Target Stores',
    password='password',      # You can use a password to protect access to your published map
    if_exists='replace',
    maps_api_key='api_key')   # User your own API key with access to the Maps API

# COMMAND ----------

# MAGIC %md # Create drive time trade areas 
# MAGIC
# MAGIC To study these stores in greater detail, let's create 10 minute drive times around our stores.

# COMMAND ----------

# MAGIC %md ### Create 10-minute (600 seconds) drive time isolines around our stores
# MAGIC
# MAGIC Learn more about location data services in CARTOframes [here](https://carto.com/developers/cartoframes/examples/#example-data-services).

# COMMAND ----------

from cartoframes.data.services import Isolines

iso_service = Isolines()
isochrones_gdf, isochrones_metadata = iso_service.isochrones(target, [600], mode='car')

# COMMAND ----------

isochrones_gdf.head(5)

# COMMAND ----------

# MAGIC %md ### Upload the dataset and store in CARTO

# COMMAND ----------

to_carto(isochrones_gdf, 'target_stores_drive_times', if_exists='replace')

# COMMAND ----------

Map(Layer(read_carto('target_stores_drive_times')))

# COMMAND ----------

# MAGIC %md # Let's find some demographic data to enrich our trade areas
# MAGIC
# MAGIC Using the [Data Observatory](https://carto.com/spatial-data-catalog/) we can enrich our data with relevant data streams.

# COMMAND ----------

# MAGIC %md ### First we will look for data in the United States

# COMMAND ----------

from cartoframes.data.observatory import Catalog, Dataset

categories = Catalog().country('usa').categories.to_dataframe()
categories

# COMMAND ----------

# MAGIC %md ### Next, let's discover demographic data, and the geographic scale of that data

# COMMAND ----------

geographies = Catalog().country('usa').category('demographics').geographies
geographies.to_dataframe()

# COMMAND ----------

# MAGIC %md ### Let's choose a specific dataset to look at in more detail

# COMMAND ----------

dataset = Dataset.get('acs_sociodemogr_b758e778')
dataset

# COMMAND ----------

# MAGIC %md ### We can make a map to see the area it covers

# COMMAND ----------

dataset.geom_coverage()

# COMMAND ----------

# MAGIC %md ### Let's look at the variables in the dataset

# COMMAND ----------

variables_df = dataset.variables.to_dataframe()
variables_df

# COMMAND ----------

# MAGIC %md ## And we can look for variables with the word 'income'

# COMMAND ----------

vdf = variables_df[variables_df['description'].str.contains('income', case=False, na=False)]

# COMMAND ----------

vdf

# COMMAND ----------

# MAGIC %md ### Let's select the `Median Household Income` variable and `Total Population` variable

# COMMAND ----------

vdf = variables_df[variables_df['description'].str.contains('median household income', case=False, na=False)]
vdf

# COMMAND ----------

vdf = variables_df[variables_df['description'].str.contains('population', case=False, na=False)]
vdf

# COMMAND ----------

# MAGIC %md # Finally, let's enrich our drive time dataset with the selected variables

# COMMAND ----------

income_df = read_carto('target_stores_drive_times')

# COMMAND ----------

from cartoframes.data.observatory import Enrichment

enrichment = Enrichment()

enriched_dataset_gdf = enrichment.enrich_polygons(
    income_df,
    variables=['median_income_70005174', 'total_pop_3cf008b3'],
    aggregation='default'
)

# COMMAND ----------

enriched_dataset_gdf.head()

# COMMAND ----------

to_carto(enriched_dataset_gdf, 'target_stores_enriched', if_exists='replace')

# COMMAND ----------

# MAGIC %md # Let's create a GeoDataFrame from a query, joining our two datasets, and make a final map!

# COMMAND ----------

target = read_carto('''
SELECT stores.*,
       drivetimes.total_pop,
       drivetimes.median_income,
       stores.the_geom as isoline
  FROM target_stores_enriched drivetimes LEFT JOIN 
       target_stores stores ON stores.cartodb_id = drivetimes.source_id
''', decode_geom=True)

# COMMAND ----------

target.head()

# COMMAND ----------

from cartoframes.viz import Map, Layer, basemaps, color_category_legend, category_widget, color_continuous_style, formula_widget, category_widget, popup_element, histogram_widget


Map(
    Layer(target,
    color_continuous_style('median_income'),
    popup_click=[
        popup_element('store_name', 'Store'),
        popup_element('formatted', 'Address'),
        popup_element('median_income', 'Median Income'),
        popup_element('total_pop', 'Total Population')
    ],
     widgets=[
        formula_widget(
            value='count',
            title='Number of Stores in View',
            description='Zoom and/or pan the map to update count'
        ),
        category_widget(
            'state',
            title='State'
        ),
        histogram_widget(
            'median_income',
            title='Average Median Income',
            description='Average median household income for households within a 10-minute drive time',
            buckets=24
        ),
         histogram_widget(
            'total_pop',
            title='Total Population',
            description='Total population within a 10-minute drive time',
            buckets=24
        )
    ]
),
legends=color_category_legend(),
basemap=basemaps.darkmatter
)
