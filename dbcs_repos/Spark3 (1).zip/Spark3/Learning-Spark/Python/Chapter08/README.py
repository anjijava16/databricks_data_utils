# Databricks notebook source
# MAGIC
# MAGIC %md
# MAGIC # The notebooks for Chapter 8 will be available soon.
# MAGIC