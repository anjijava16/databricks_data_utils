# Databricks notebook source
my_country = "France"

# COMMAND ----------

def addition(a, b):
    print(a + b)

# COMMAND ----------

def my_job(x:int,y:int):
  return x+y