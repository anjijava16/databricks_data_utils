# Databricks notebook source
# MAGIC %run ./_databricks-academy-helper $lesson="4.02"

# COMMAND ----------

# MAGIC %run ./_utility-functions

# COMMAND ----------

DA.cleanup()
DA.init()
DA.conclude_setup()
