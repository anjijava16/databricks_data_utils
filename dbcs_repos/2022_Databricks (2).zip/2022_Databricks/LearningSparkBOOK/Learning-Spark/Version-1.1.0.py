# Databricks notebook source
# MAGIC
# MAGIC %md # Course: Learning-Spark
# MAGIC * Version 1.1.0
# MAGIC * Built 2021-12-12
# MAGIC * Tested on DBR 9.1 ML LTS (Spark 3.1.2)
# MAGIC
# MAGIC Copyright © 2021 Databricks, Inc.