# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Incremental ETL Using Auto Loader
# MAGIC
# MAGIC This Notebook simulates an environment to demonstrate the Auto Loader feature by synthesizing data into a DBFS location that functions as a simulated data source. 
# MAGIC
# MAGIC We then apply Auto Loader to ingest data from this simulated source into a bronze Delta table, using the default directory listing mode. For detailed reference on Auto Loader, review [Auto Loader Documentation](https://docs.databricks.com/spark/latest/structured-streaming/auto-loader.html).

# COMMAND ----------

# MAGIC %md
# MAGIC ##Initialize Data Source
# MAGIC The following cell resets our demo environment and defines paths and variables that will be used in the demo. A Python class is also defined that we'll use later to create and load additional fake data.

# COMMAND ----------

# MAGIC %run ./Includes/incremental-etl-setup $mode="reset"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Our Recommendation for Easy ETL
# MAGIC
# MAGIC
# MAGIC To enable schema inference and evolution, the following conditions need to be met:
# MAGIC 1. Do **not** provide a schema for your data
# MAGIC 1. Provide a location to store your inferred schemas using the `"cloudFiles.schemaLocation"` option in your DataStreamReader. Here we show using the checkpoint path, which is recommended
# MAGIC 1. Set the option `"mergeSchema"` to `True` in your DataStreamWriter.

# COMMAND ----------

stream = (spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "json")
    .option("cloudFiles.schemaLocation", checkpoint)
    .load(rawDataSource)
    .writeStream
    .option("path", table)
    .option("checkpointLocation", checkpoint)
    .option("mergeSchema", True)
    .table(tableName)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##Land New Data
# MAGIC A helper class was defined in our setup simulate the landing of new files. Each time you execute the cell below, a new file will be written to our source directory. Expand the stream monitor above to see this data processing.

# COMMAND ----------

File.newData()

# COMMAND ----------

# MAGIC %md
# MAGIC ##Display Bronze Table
# MAGIC We successfully configured data ingestion to automatically process new files as they arrive. Let's display our ingested data to confirm it looks OK.

# COMMAND ----------

display(spark.table(tableName))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Sample JSON Input
# MAGIC As a frame of reference, we can look at the beginning of one of our JSON source files.

# COMMAND ----------

dbutils.fs.head(rawDataSource + "/file-0.json")

# COMMAND ----------

# MAGIC %md
# MAGIC Note that there appear to only be 4 fields present, with a mix of integer, float, and string types.

# COMMAND ----------

# MAGIC %md
# MAGIC ##Clean Up
# MAGIC Stop active streams and remove created resources before continuing.

# COMMAND ----------

# MAGIC %run ./Includes/incremental-etl-setup $mode="cleanup"

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2021 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>