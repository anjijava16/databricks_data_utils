# Databricks notebook source
# MAGIC %md
# MAGIC * Equal -> `=` or `==`
# MAGIC * Not Equal -> `!=`
# MAGIC * Greater Than -> `>`
# MAGIC * Less Than -> `<`
# MAGIC * Greater Than or Equal To -> `>=`
# MAGIC * Less Than or Equal To -> `<=`
# MAGIC * IN Operator -> `isin` function or `IN` or `contains` function
# MAGIC * Between Operator -> `between` function or `BETWEEN` with `AND`

# COMMAND ----------

