# Databricks notebook source
# MAGIC %md
# MAGIC # Windowing Functions
# MAGIC
# MAGIC As part of this section we will primarily talk about Windowing Functions. These are also known as Analytic Functions in Databases like Oracle.
# MAGIC
# MAGIC * Prepare HR Database
# MAGIC * Overview of Windowing Functions
# MAGIC * Aggregations using Windowing Functions
# MAGIC * Getting LEAD and LAG values
# MAGIC * Getting first and last values
# MAGIC * Ranking using Windowing Functions
# MAGIC * Understanding order of execution of SQL
# MAGIC * Overview of Nested Sub Queries
# MAGIC * Filtering - Window Function Results

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    appName("Spark SQL - Windowing Functions").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %%sql
# MAGIC SET spark.sql.shuffle.partitions=2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare HR Database
# MAGIC
# MAGIC Let us prepare HR database with **EMPLOYEES** Table. We will be using this for some of the examples as well as exercises related to Window Functions.
# MAGIC
# MAGIC * Create Database **itversity_hr** (replace itversity with your OS User Name)
# MAGIC * Create table **employees** in **itversity_hr** database.
# MAGIC * Load data into the table.
# MAGIC
# MAGIC First let us start with creating the database.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_hr CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE itversity_hr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_hr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %md
# MAGIC As the database is created, let us go ahead and add table to it.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE employees (
# MAGIC   employee_id     int,
# MAGIC   first_name      varchar(20),
# MAGIC   last_name       varchar(25),
# MAGIC   email           varchar(25),
# MAGIC   phone_number    varchar(20),
# MAGIC   hire_date       date,
# MAGIC   job_id          varchar(10),
# MAGIC   salary          decimal(8,2),
# MAGIC   commission_pct  decimal(2,2),
# MAGIC   manager_id      int,
# MAGIC   department_id   int
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'

# COMMAND ----------

# MAGIC %md
# MAGIC Let us load the data and validate the table.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/hr_db/employees' 
# MAGIC INTO TABLE employees

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM employees LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT employee_id, department_id, salary FROM employees LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM employees

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Windowing Functions
# MAGIC
# MAGIC Let us get an overview of Analytics or Windowing Functions in Spark SQL.
# MAGIC
# MAGIC * Aggregate Functions (`sum`, `min`, `max`, `avg`)
# MAGIC * Window Functions (`lead`, `lag`, `first_value`, `last_value`)
# MAGIC * Rank Functions (`rank`, `dense_rank`, `row_number` etc)
# MAGIC * For all the functions we use `OVER` clause.
# MAGIC * For aggregate functions we typically use `PARTITION BY`
# MAGIC * For ranking and windowing functions we might use `ORDER BY sorting_column` or `PARTITION BY partition_column ORDER BY sorting_column`.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_hr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT employee_id, department_id, salary FROM employees LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT employee_id, department_id, salary,
# MAGIC     count(1) OVER (PARTITION BY department_id) AS employee_count,
# MAGIC     rank() OVER (ORDER BY salary DESC) AS rnk,
# MAGIC     lead(employee_id) OVER (PARTITION BY department_id ORDER BY salary DESC) AS lead_emp_id,
# MAGIC     lead(salary) OVER (PARTITION BY department_id ORDER BY salary DESC) AS lead_emp_sal
# MAGIC FROM employees
# MAGIC ORDER BY employee_id

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregations using Windowing Functions
# MAGIC
# MAGIC Let us see how we can perform aggregations with in a partition or group using Windowing/Analytics Functions.
# MAGIC
# MAGIC * For simple aggregations where we have to get grouping key and aggregated results we can use **GROUP BY**.
# MAGIC * If we want to get the raw data along with aggregated results, then using **GROUP BY** is not possible or overly complicated.
# MAGIC * Using aggregate functions with **OVER** Clause not only simplifies the process of writing query, but also better with respect to performance.
# MAGIC * Let us take an example of getting employee salary percentage when compared to department salary expense.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_hr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT employee_id, department_id, salary 
# MAGIC FROM employees 
# MAGIC ORDER BY department_id, salary
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC > Let us write the query using `GROUP BY` approach.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT department_id,
# MAGIC        sum(salary) AS department_salary_expense
# MAGIC FROM employees
# MAGIC GROUP BY department_id
# MAGIC ORDER BY department_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT e.employee_id, e.department_id, e.salary,
# MAGIC        ae.department_salary_expense,
# MAGIC        ae.avg_salary_expense
# MAGIC FROM employees e JOIN (
# MAGIC      SELECT department_id, 
# MAGIC             sum(salary) AS department_salary_expense,
# MAGIC             avg(salary) AS avg_salary_expense
# MAGIC      FROM employees
# MAGIC      GROUP BY department_id
# MAGIC ) ae
# MAGIC ON e.department_id = ae.department_id
# MAGIC ORDER BY department_id, salary

# COMMAND ----------

# MAGIC %md
# MAGIC > Let us see how we can get it using Analytics/Windowing Functions. 
# MAGIC
# MAGIC * We can use all standard aggregate functions such as `count`, `sum`, `min`, `max`, `avg` etc.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT e.employee_id, e.department_id, e.salary,
# MAGIC        sum(e.salary) 
# MAGIC          OVER (PARTITION BY e.department_id)
# MAGIC          AS department_salary_expense
# MAGIC FROM employees e
# MAGIC ORDER BY e.department_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT e.employee_id, e.department_id, e.salary,
# MAGIC     sum(e.salary) OVER (PARTITION BY e.department_id) AS sum_sal_expense,
# MAGIC     avg(e.salary) OVER (PARTITION BY e.department_id) AS avg_sal_expense,
# MAGIC     min(e.salary) OVER (PARTITION BY e.department_id) AS min_sal_expense,
# MAGIC     max(e.salary) OVER (PARTITION BY e.department_id) AS max_sal_expense,
# MAGIC     count(e.salary) OVER (PARTITION BY e.department_id) AS cnt_sal_expense
# MAGIC FROM employees e
# MAGIC ORDER BY e.department_id

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create tables to get daily revenue
# MAGIC
# MAGIC Let us create couple of tables which will be used for the demonstrations of Windowing and Ranking functions.
# MAGIC
# MAGIC * We have **ORDERS** and **ORDER_ITEMS** tables.
# MAGIC * Let us take care of computing daily revenue as well as daily product revenue.
# MAGIC * As we will be using same data set several times, let us create the tables to pre compute the data.
# MAGIC * **daily_revenue** will have the **order_date** and **revenue**, where data is aggregated using **order_date** as partition key.
# MAGIC * **daily_product_revenue** will have **order_date**, **order_item_product_id** and **revenue**. In this case data is aggregated using **order_date** and **order_item_product_id** as partition keys.
# MAGIC
# MAGIC Let us create table to compute daily revenue.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS daily_revenue

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE daily_revenue
# MAGIC AS
# MAGIC SELECT o.order_date,
# MAGIC        round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * 
# MAGIC FROM daily_revenue
# MAGIC ORDER BY order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC Let us create table to compute daily product revenue.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS daily_product_revenue

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE daily_product_revenue
# MAGIC AS
# MAGIC SELECT o.order_date,
# MAGIC        oi.order_item_product_id,
# MAGIC        round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date, oi.order_item_product_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * 
# MAGIC FROM daily_product_revenue
# MAGIC ORDER BY order_date, order_item_product_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ## Getting LEAD and LAG values
# MAGIC
# MAGIC Let us understand LEAD and LAG functions to get column values from following or prior rows.
# MAGIC
# MAGIC Here is the example where we can get prior or following records based on **ORDER BY** Clause.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM daily_revenue
# MAGIC ORDER BY order_date DESC
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   lead(order_date) OVER (ORDER BY order_date DESC) AS prior_date,
# MAGIC   lead(revenue) OVER (ORDER BY order_date DESC) AS prior_revenue
# MAGIC FROM daily_revenue t
# MAGIC ORDER BY order_date DESC
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC We can also pass number of rows as well as default values for nulls as arguments.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   lead(order_date, 7) OVER (ORDER BY order_date DESC) AS prior_date,
# MAGIC   lead(revenue, 7) OVER (ORDER BY order_date DESC) AS prior_revenue
# MAGIC FROM daily_revenue t
# MAGIC ORDER BY order_date DESC
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   lead(order_date, 7) OVER (ORDER BY order_date DESC) AS prior_date,
# MAGIC   lead(revenue, 7) OVER (ORDER BY order_date DESC) AS prior_revenue
# MAGIC FROM daily_revenue t
# MAGIC ORDER BY order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   lead(order_date, 7) OVER (ORDER BY order_date DESC) AS prior_date,
# MAGIC   lead(revenue, 7, 0) OVER (ORDER BY order_date DESC) AS prior_revenue
# MAGIC FROM daily_revenue t
# MAGIC ORDER BY order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC Let us see how we can get prior or following records with in a group based on particular order.
# MAGIC
# MAGIC Here is the example where we can get prior or following records based on **PARTITION BY** and then **ORDER BY** Clause.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE daily_product_revenue

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM daily_product_revenue LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   LEAD(order_item_product_id) OVER (
# MAGIC     PARTITION BY order_date 
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) next_product_id,
# MAGIC   LEAD(revenue) OVER (
# MAGIC     PARTITION BY order_date 
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) next_revenue
# MAGIC FROM daily_product_revenue t
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC We can also pass number of rows as well as default values for nulls as arguments.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   LEAD(order_item_product_id) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue DESC
# MAGIC   ) next_product_id,
# MAGIC   LEAD(revenue, 1, 0) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue DESC
# MAGIC   ) next_revenue
# MAGIC FROM daily_product_revenue t
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC ## Getting first and last values
# MAGIC
# MAGIC Let us see how we can get first and last value based on the criteria. We can also use min or max as well.
# MAGIC
# MAGIC Here is the example of using first_value.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   first_value(order_item_product_id) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue DESC
# MAGIC   ) first_product_id,
# MAGIC   first_value(revenue) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue DESC
# MAGIC   ) first_revenue
# MAGIC FROM daily_product_revenue t
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC Let us see an example with last_value. While using last_value we need to specify **ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING/PRECEEDING**. By default it uses

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   last_value(order_item_product_id) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue
# MAGIC     ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
# MAGIC   ) last_product_id,
# MAGIC   last_value(revenue) OVER (
# MAGIC     PARTITION BY order_date ORDER BY revenue
# MAGIC     ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING
# MAGIC   )  last_revenue
# MAGIC FROM daily_product_revenue AS t
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ranking using Windowing Functions
# MAGIC
# MAGIC Let us see how we can get sparse ranks using **rank** function.
# MAGIC
# MAGIC * If we have to get ranks globally, we just need to specify **ORDER BY**
# MAGIC * If we have to get ranks with in a key then we need to specify **PARTITION BY** and then **ORDER BY**.
# MAGIC * By default **ORDER BY** will sort the data in ascending order. We can change the order by passing **DESC** after order by.
# MAGIC
# MAGIC Here is an example to assign sparse ranks using daily_product_revenue with in each day based on revenue.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT t.*,
# MAGIC   rank() OVER (
# MAGIC     PARTITION BY order_date
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) AS rnk
# MAGIC FROM daily_product_revenue t
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC Here is another example to assign sparse ranks using employees data set with in each department.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_hr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT
# MAGIC   employee_id,
# MAGIC   department_id,
# MAGIC   salary,
# MAGIC   rank() OVER (
# MAGIC     PARTITION BY department_id
# MAGIC     ORDER BY salary DESC
# MAGIC   ) rnk,
# MAGIC   dense_rank() OVER (
# MAGIC     PARTITION BY department_id
# MAGIC     ORDER BY salary DESC
# MAGIC   ) drnk,
# MAGIC   row_number() OVER (
# MAGIC     PARTITION BY department_id
# MAGIC     ORDER BY salary DESC
# MAGIC   ) rn
# MAGIC FROM employees
# MAGIC ORDER BY department_id, salary DESC

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM employees ORDER BY salary LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT employee_id, salary,
# MAGIC     dense_rank() OVER (ORDER BY salary DESC) AS drnk
# MAGIC FROM employees

# COMMAND ----------

# MAGIC %md
# MAGIC Let us understand the difference between **rank**, **dense_rank** and **row_number**.
# MAGIC
# MAGIC * We can either of the functions to generate ranks when the rank field does not have duplicates.
# MAGIC * When rank field have duplicates then row_number should not be used as it generate unique number for each record with in the partition.
# MAGIC * **rank** will skip the ranks in between if multiple people get the same rank while **dense_rank** continue with the next number.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Understanding order of execution of SQL
# MAGIC
# MAGIC Let us review the order of execution of SQL. First let us review the order of writing the query.
# MAGIC
# MAGIC 1. **SELECT**
# MAGIC 2. **FROM**
# MAGIC 3. **JOIN** or **OUTER JOIN** with **ON**
# MAGIC 4. **WHERE**
# MAGIC 5. **GROUP BY** and optionally **HAVING**
# MAGIC 6. **ORDER BY**
# MAGIC
# MAGIC Let us come up with a query which will compute daily revenue using COMPLETE or CLOSED orders and also ordered by order_date.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC   round(sum(oi.order_item_order_id), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date
# MAGIC ORDER BY o.order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     round(sum(oi.order_item_order_id), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date
# MAGIC     HAVING revenue >= 2000000
# MAGIC ORDER BY order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC However order of execution is different.
# MAGIC
# MAGIC 1. **FROM**
# MAGIC 2. **JOIN** or **OUTER JOIN** with **ON**
# MAGIC 3. **WHERE**
# MAGIC 4. **GROUP BY** and optionally **HAVING**
# MAGIC 5. **SELECT**
# MAGIC 6. **ORDER BY**
# MAGIC
# MAGIC As **SELECT** is executed before **ORDER BY** Clause, we will not be able to refer the aliases in **SELECT** in other clauses except for **ORDER BY**.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Nested Sub Queries
# MAGIC
# MAGIC Let us recap about Nested Sub Queries.
# MAGIC
# MAGIC * We typically have Nested Sub Queries in **FROM** Clause.
# MAGIC * We need to provide alias to the Nested Sub Queries in **FROM** Clause in Hive.
# MAGIC * We use nested queries quite often over queries using Analytics/Windowing Functions

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (SELECT current_date) AS q

# COMMAND ----------

# MAGIC %md
# MAGIC Let us see few more examples with respected to Nested Sub Queries.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (
# MAGIC   SELECT order_date, count(1) AS order_count
# MAGIC   FROM orders
# MAGIC   GROUP BY order_date
# MAGIC ) q
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (
# MAGIC   SELECT order_date, count(1) AS order_count
# MAGIC   FROM orders
# MAGIC   GROUP BY order_date
# MAGIC ) q
# MAGIC WHERE q.order_count > 0

# COMMAND ----------

# MAGIC %md
# MAGIC * We can achieve using HAVING clause (no need to be nested to filter)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filtering - Window Function Results
# MAGIC
# MAGIC Let us understand how to filter on top of results of Window Functions.
# MAGIC
# MAGIC * We can use Window Functions only in **SELECT** Clause.
# MAGIC * If we have to filter based on Window Function results, then we need to use Nested Sub Queries.
# MAGIC * Once the query is nested, we can apply filter using aliases of the Window Functions.
# MAGIC
# MAGIC Here is the example where we can filter data based on Window Functions.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (
# MAGIC   SELECT t.*,
# MAGIC     dense_rank() OVER (
# MAGIC       PARTITION BY order_date
# MAGIC       ORDER BY revenue DESC
# MAGIC     ) AS drnk
# MAGIC   FROM daily_product_revenue t
# MAGIC ) q
# MAGIC WHERE drnk <= 5
# MAGIC ORDER BY q.order_date, q.revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC ### Ranking and Filtering - Recap
# MAGIC
# MAGIC Let us recap the procedure to get top 5 orders by revenue for each day.
# MAGIC
# MAGIC * We have our original data in **orders** and **order_items**
# MAGIC * We can pre-compute the data or create a view with the logic to generate **daily product revenue**
# MAGIC * Then, we have to use the view or table or even nested query to compute rank
# MAGIC * Once the ranks are computed, we need to nest it to filter based up on our requirement.
# MAGIC * Let us see using the query example.
# MAGIC
# MAGIC Let us come up with the query to compute daily product revenue.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC        oi.order_item_product_id,
# MAGIC        round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date, oi.order_item_product_id
# MAGIC ORDER BY o.order_date, revenue DESC
# MAGIC LIMIT 100

# COMMAND ----------

# MAGIC %md
# MAGIC Let us compute the rank for each product with in each date using revenue as criteria.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT q.*,
# MAGIC   rank() OVER (
# MAGIC     PARTITION BY order_date
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) AS rnk
# MAGIC FROM (SELECT o.order_date,
# MAGIC         oi.order_item_product_id,
# MAGIC         round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC       FROM orders o JOIN order_items oi
# MAGIC       ON o.order_id = oi.order_item_order_id
# MAGIC       WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC       GROUP BY o.order_date, oi.order_item_product_id) q
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 35

# COMMAND ----------

# MAGIC %md
# MAGIC Now let us see how we can filter the data.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (SELECT q.*,
# MAGIC   dense_rank() OVER (
# MAGIC     PARTITION BY order_date
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) AS drnk
# MAGIC FROM (SELECT o.order_date,
# MAGIC         oi.order_item_product_id,
# MAGIC         round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC       FROM orders o JOIN order_items oi
# MAGIC       ON o.order_id = oi.order_item_order_id
# MAGIC       WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC       GROUP BY o.order_date, oi.order_item_product_id) q) q1
# MAGIC WHERE drnk <= 5
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 35

# COMMAND ----------

spark.sql("DESCRIBE daily_product_revenue").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (SELECT dpr.*,
# MAGIC   dense_rank() OVER (
# MAGIC     PARTITION BY order_date
# MAGIC     ORDER BY revenue DESC
# MAGIC   ) AS drnk
# MAGIC FROM daily_product_revenue AS dpr)
# MAGIC WHERE drnk <= 5
# MAGIC ORDER BY order_date, revenue DESC
# MAGIC LIMIT 35

# COMMAND ----------

