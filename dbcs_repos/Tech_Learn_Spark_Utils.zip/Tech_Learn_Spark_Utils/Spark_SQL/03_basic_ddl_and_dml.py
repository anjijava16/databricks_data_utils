# Databricks notebook source
# MAGIC %md
# MAGIC # Basic DDL and DML
# MAGIC
# MAGIC As part of this section we will primarily focus on basic DDL and DML using Spark Metastore.
# MAGIC
# MAGIC * Create Spark Metastore Tables
# MAGIC * Overview of Data Types
# MAGIC * Adding Comments
# MAGIC * Loading Data into Tables - Local
# MAGIC * Loading Data into Tables - HDFS
# MAGIC * Loading Data - Append and Overwrite
# MAGIC * Creating External Tables
# MAGIC * Managed Tables vs. External Tables
# MAGIC * Overview of File Formats
# MAGIC * Dropping Tables and Databases
# MAGIC * Truncating Tables

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    appName("Spark SQL - Managing Tables - Basic DDL and DML").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %md
# MAGIC If you are going to use CLIs, you can use Spark SQL using one of the 3 approaches.
# MAGIC
# MAGIC **Using Spark SQL**
# MAGIC
# MAGIC ```
# MAGIC spark2-sql \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Scala**
# MAGIC
# MAGIC ```
# MAGIC spark2-shell \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Pyspark**
# MAGIC
# MAGIC ```
# MAGIC pyspark2 \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Spark Metastore Tables
# MAGIC
# MAGIC Let us understand how to create tables in Spark Metastore. We will be focusing on syntax and semantics.
# MAGIC
# MAGIC * Let us drop and recreate the table. We need to determine table type, file format based up on the files that will be copied to the table. If the file format is delimited text file then we need to understand field delimiter as well.
# MAGIC   * Managed Table
# MAGIC   * Text File Format
# MAGIC   * Field Delimiter ','
# MAGIC * We will create the table based on the structure of data in **/data/retail_db/orders**
# MAGIC * If you are using `spark-sql` make sure to end the statements with **semi-colon**. With `spark-shell` or `pyspark` make sure to use `spark.sql` to pass these commands.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
# MAGIC STORED AS TEXTFILE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
# MAGIC STORED AS TEXTFILE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("DROP TABLE orders")

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
""")

# COMMAND ----------

spark.sql("SHOW tables").show()

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("DROP TABLE orders")

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
  order_id INT,
  order_date STRING,
  order_customer_id INT,
  order_status STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
""")

# COMMAND ----------

spark.sql("SHOW tables").show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Once the table is created either we can copy files using LOAD or insert query results using INSERT. We will see how to use insert to insert query results as part of the next section.
# MAGIC * We can also use INSERT to insert individual records. But this approach is used less often. Let us create additional table and see how we can use INSERT to insert individual records.

# COMMAND ----------

# MAGIC %%sql
# MAGIC DROP DATABASE IF EXISTS itversity_sms CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE students (
# MAGIC     student_id INT,
# MAGIC     student_first_name STRING,
# MAGIC     student_last_name STRING,
# MAGIC     student_phone_number STRING,
# MAGIC     student_address STRING
# MAGIC ) STORED AS TEXTFILE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (2, 'Donald', 'Duck', '1234567890', NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES 
# MAGIC     (3, 'Mickey', 'Mouse', '2345678901', 'A Street, One City, Some State, 12345'),
# MAGIC     (4, 'Bubble', 'Guppy', '6789012345', 'Bubbly Street, Guppy, La la land, 45678')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES ('Scott', 'Tiger', 1, NULL, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("DROP DATABASE IF EXISTS itversity_sms CASCADE")

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS itversity_sms")

# COMMAND ----------

spark.sql("USE itversity_sms")

# COMMAND ----------

spark.sql("""
CREATE TABLE students (
    student_id INT,
    student_first_name STRING,
    student_last_name STRING,
    student_phone_number STRING,
    student_address STRING
) STORED AS TEXTFILE
""")

# COMMAND ----------

spark.sql("INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)")

# COMMAND ----------

spark.sql("INSERT INTO students VALUES (2, 'Donald', 'Duck', '1234567890', NULL)")

# COMMAND ----------

spark.sql("""
INSERT INTO students VALUES 
    (3, 'Mickey', 'Mouse', '2345678901', 'A Street, One City, Some State, 12345'),
    (4, 'Bubble', 'Guppy', '6789012345', 'Bubbly Street, Guppy, La la land, 45678')
""")    

# COMMAND ----------

spark.sql("SELECT * FROM students").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Data Types
# MAGIC
# MAGIC Let us get an overview of Data Types.
# MAGIC
# MAGIC * Syntactically Hive and Spark SQL are almost same.
# MAGIC * Go to this [hive page](https://cwiki.apache.org/confluence/display/Hive/LanguageManual+DDL) and review supported data types.
# MAGIC * Spark Metastore supports all standard data types.
# MAGIC   * Numeric - INT, BIGINT, FLOAT etc
# MAGIC   * Alpha Numeric or String - CHAR, VARCHAR, STRING
# MAGIC   * Date and Timestamp - DATE, TIMESTAMP
# MAGIC   * Special Data Types - ARRAY, STRUCT etc
# MAGIC   * Boolean - BOOLEAN
# MAGIC * If the file format is text file with special types, then we need to consider other clauses under DELIMITED ROW FORMAT (if we don't want to use default delimiters).

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_sms CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE students (
# MAGIC     student_id INT,
# MAGIC     student_first_name STRING,
# MAGIC     student_last_name STRING,
# MAGIC     student_phone_numbers ARRAY<STRING>,
# MAGIC     student_address STRUCT<street:STRING, city:STRING, state:STRING, zip:STRING>
# MAGIC ) STORED AS TEXTFILE
# MAGIC ROW FORMAT
# MAGIC     DELIMITED FIELDS TERMINATED BY '\t'
# MAGIC     COLLECTION ITEMS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE students

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (2, 'Donald', 'Duck', ARRAY('1234567890', '2345678901'), NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES 
# MAGIC     (3, 'Mickey', 'Mouse', ARRAY('1234567890', '2345678901'), STRUCT('A Street', 'One City', 'Some State', '12345')),
# MAGIC     (4, 'Bubble', 'Guppy', ARRAY('5678901234', '6789012345'), STRUCT('Bubbly Street', 'Guppy', 'La la land', '45678'))

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

val username = System.getProperty("user.name")

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/warehouse/${username}_sms.db/students"!

# COMMAND ----------

s"hdfs dfs -cat /user/${username}/warehouse/${username}_sms.db/students/*"!

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("DROP DATABASE IF EXISTS itversity_sms CASCADE")

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS itversity_sms")

# COMMAND ----------

spark.sql("USE itversity_sms")

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS students")

# COMMAND ----------

spark.sql("""
CREATE TABLE students (
    student_id INT,
    student_first_name STRING,
    student_last_name STRING,
    student_phone_numbers ARRAY<STRING>,
    student_address STRUCT<street:STRING, city:STRING, state:STRING, zip:STRING>
) STORED AS TEXTFILE
ROW FORMAT
    DELIMITED FIELDS TERMINATED BY '\t'
    COLLECTION ITEMS TERMINATED BY ','
    MAP KEYS TERMINATED BY ':'
""")

# COMMAND ----------

spark.sql("INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)")

# COMMAND ----------

spark.sql("INSERT INTO students VALUES (2, 'Donald', 'Duck', ARRAY('1234567890', '2345678901'), NULL)")

# COMMAND ----------

spark.sql("""
INSERT INTO students VALUES 
    (3, 'Mickey', 'Mouse', ARRAY('1234567890', '2345678901'), STRUCT('A Street', 'One City', 'Some State', '12345')),
    (4, 'Bubble', 'Guppy', ARRAY('5678901234', '6789012345'), STRUCT('Bubbly Street', 'Guppy', 'La la land', '45678'))
""")

# COMMAND ----------

spark.sql("SELECT * FROM students")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding Comments
# MAGIC
# MAGIC Let us understand how to create table with comments in Hive using orders as example.
# MAGIC
# MAGIC * We can specify comments for both columns as well as tables using COMMENT keyword.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT COMMENT 'Unique order id',
# MAGIC   order_date STRING COMMENT 'Date on which order is placed',
# MAGIC   order_customer_id INT COMMENT 'Customer id who placed the order',
# MAGIC   order_status STRING COMMENT 'Current status of the order'
# MAGIC ) COMMENT 'Table to save order level details'

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("DROP TABLE orders")

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
  order_id STRING COMMENT 'Unique order id',
  order_date STRING COMMENT 'Date on which order is placed',
  order_customer_id INT COMMENT 'Customer id who placed the order',
  order_status STRING COMMENT 'Current status of the order'
) COMMENT 'Table to save order level details'
""")

# COMMAND ----------

# MAGIC %md
# MAGIC * Default field delimiter is \001 character.
# MAGIC * We can see the comments using `DESCRIBE orders` or `DESCRIBE FORMATTED orders`.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FORMATTED orders

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED orders").show(200, false) // Scala

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading Data into Tables - Local
# MAGIC
# MAGIC Let us understand how to load data into Spark Metastore tables. We can load either from local file system or from HDFS.
# MAGIC
# MAGIC * Data should be in sync with Spark Metastore table structure.
# MAGIC * We need to create table with the same file format and delimiters so that we can load the data in files into Spark Metastore tables.
# MAGIC * Our data is in text files, line delimiter is new line character and field delimiter is comma.
# MAGIC * As our table uses default file format (text file), default line/record delimiter and field delimiter is specified as comma, we should be able to load the data with out any issues.
# MAGIC * Here is the script which will create table and then load data into the table.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT COMMENT 'Unique order id',
# MAGIC   order_date STRING COMMENT 'Date on which order is placed',
# MAGIC   order_customer_id INT COMMENT 'Customer id who placed the order',
# MAGIC   order_status STRING COMMENT 'Current status of the order'
# MAGIC ) COMMENT 'Table to save order level details'
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' INTO TABLE orders

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("DROP TABLE orders")

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
  order_id INT COMMENT 'Unique order id',
  order_date STRING COMMENT 'Date on which order is placed',
  order_customer_id INT COMMENT 'Customer id who placed the order',
  order_status STRING COMMENT 'Current status of the order'
) COMMENT 'Table to save order level details'
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
""")

# COMMAND ----------

spark.sql("LOAD DATA LOCAL INPATH '/data/retail_db/orders' INTO TABLE orders")

# COMMAND ----------

# MAGIC %md
# MAGIC * Once the data is loaded we can run these queries to preview the data.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading Data into Tables - HDFS
# MAGIC
# MAGIC Let us understand how we can load data from HDFS location into Spark Metastore table.
# MAGIC
# MAGIC * We can use load command with out **LOCAL** to get data from HDFS location into Spark Metastore Table.
# MAGIC * User running load command from HDFS location need to have write permissions on the source location as data will be moved (deleted on source and copied to Spark Metastore table)
# MAGIC * Make sure user have write permissions on the source location.
# MAGIC * First we need to copy the data into HDFS location where user have write permissions.

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")

# COMMAND ----------

s"hadoop fs -rm -R /user/${username}/retail_db/orders" !

# COMMAND ----------

s"hadoop fs -mkdir /user/${username}/retail_db" !

# COMMAND ----------

s"hadoop fs -put -f /data/retail_db/orders /user/${username}/retail_db" !

# COMMAND ----------

s"hadoop fs -ls /user/${username}/retail_db/orders" !

# COMMAND ----------

# MAGIC %md
# MAGIC * Here is the script which will truncate the table and then load the data from HDFS location to Hive table.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA INPATH '/user/itversity/retail_db/orders' 
# MAGIC   INTO TABLE orders

# COMMAND ----------

s"hadoop fs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

s"hadoop fs -ls /user/${username}/retail_db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("TRUNCATE TABLE orders")

# COMMAND ----------

spark.sql("""
LOAD DATA INPATH '/user/itversity/retail_db/orders' 
  INTO TABLE orders""")

# COMMAND ----------

s"hadoop fs -ls /user/${username}/retail_db/orders" !

# COMMAND ----------

spark.sql("SELECT * FROM orders LIMIT 10")

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders")

# COMMAND ----------

# MAGIC %md
# MAGIC * If you look at **/user/training/retail_db** orders directory would have been deleted.
# MAGIC * Move is much faster compared to copying the files by moving blocks around, hence Hive load command from HDFS location will always try to move files.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading Data - Append and Overwrite
# MAGIC Let us understand different approaches to load the data into Spark Metastore table.
# MAGIC * `INTO TABLE` will append in the existing table
# MAGIC * If we want to overwrite we have to specify `OVERWRITE INTO TABLE`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
# MAGIC   INTO TABLE orders

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
# MAGIC   OVERWRITE INTO TABLE orders

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders").show()

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

spark.sql("""
LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
  INTO TABLE orders
""")

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders").show()

# COMMAND ----------

spark.sql("""
LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
  OVERWRITE INTO TABLE orders
""")

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders" !

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating External Tables
# MAGIC
# MAGIC Let us understand how to create external table in Spark Metastore using orders as example. Also we will see how to load data into external table.
# MAGIC
# MAGIC * We just need to add **EXTERNAL** keyword in the **CREATE** clause and **LOCATION** after **STORED AS** clause or just **LOCATION** as part of **CREATE TABLE** statement.
# MAGIC * We can use same LOAD commands to get data from either local file system or HDFS which we have used for Managed table.
# MAGIC * Once table is created we can run `DESCRIBE FORMATTED orders` to check the metadata of the table and confirm whether it is managed table or external table.
# MAGIC * We need to specify the location while creating external tables.
# MAGIC
# MAGIC Here is the script to create external table in Spark Metastore.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders

# COMMAND ----------

import sys.process._

val username = System.getProperty("user.name")

# COMMAND ----------

s"hdfs dfs -rm -R /user/${username}/external/retail_db/orders" !

# COMMAND ----------

s"hdfs dfs -mkdir -p /user/${username}/external/retail_db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE EXTERNAL TABLE orders (
# MAGIC   order_id INT COMMENT 'Unique order id',
# MAGIC   order_date STRING COMMENT 'Date on which order is placed',
# MAGIC   order_customer_id INT COMMENT 'Customer id who placed the order',
# MAGIC   order_status STRING COMMENT 'Current status of the order'
# MAGIC ) COMMENT 'Table to save order level details'
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
# MAGIC LOCATION '/user/itversity/external/retail_db/orders'

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/external/retail_db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
# MAGIC   INTO TABLE orders

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/external/retail_db/orders" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED orders").show(200, false)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managed Tables vs. External Tables
# MAGIC
# MAGIC Let us compare and contrast between Managed Tables and External Tables.
# MAGIC
# MAGIC * When we say EXTERNAL and specify LOCATION or LOCATION alone as part of CREATE TABLE, it makes the table EXTERNAL.
# MAGIC * Rest of the syntax is same as Managed Table.
# MAGIC * However, when we drop **Managed Table**, it will delete metadata from metastore as well as data from HDFS.
# MAGIC * When we drop **External Table**, only metadata will be dropped, not the data.
# MAGIC * Typically we use **External Table** when same dataset is processed by multiple frameworks such as Hive, Pig, Spark etc.
# MAGIC * We cannot run **TRUNCATE TABLE** command against External Tables.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED orders").show(200, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE orders

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED order_items").show(200, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE order_items

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/retail_db/orders" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of File Formats
# MAGIC Let us go through the details about different file formats supported by STORED AS Clause.
# MAGIC
# MAGIC * Go to this [page](https://cwiki.apache.org/confluence/display/Hive/LanguageManual+DDL) and review supported file formats.
# MAGIC * Supported File Formats
# MAGIC   * TEXTFILE
# MAGIC   * ORC
# MAGIC   * PARQUET
# MAGIC   * AVRO
# MAGIC   * SEQUENCEFILE - is not important
# MAGIC   * JSONFILE - only available in recent vesions of Hive.
# MAGIC   * and more
# MAGIC * We can even specify custom file formats (out of scope)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_sms CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE students (
# MAGIC     student_id INT,
# MAGIC     student_first_name STRING,
# MAGIC     student_last_name STRING,
# MAGIC     student_phone_numbers ARRAY<STRING>,
# MAGIC     student_address STRUCT<street:STRING, city:STRING, state:STRING, zip:STRING>
# MAGIC ) STORED AS parquet

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (2, 'Donald', 'Duck', ARRAY('1234567890', '2345678901'), NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES 
# MAGIC     (3, 'Mickey', 'Mouse', ARRAY('1234567890', '2345678901'), STRUCT('A Street', 'One City', 'Some State', '12345')),
# MAGIC     (4, 'Bubble', 'Guppy', ARRAY('5678901234', '6789012345'), STRUCT('Bubbly Street', 'Guppy', 'La la land', '45678'))

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")

# COMMAND ----------

s"hdfs dfs -ls /user/${username}/warehouse/${username}_sms.db/students"!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Dropping Tables and Databases
# MAGIC
# MAGIC Let us understand how to DROP Spark Metastore Tables as well as Databases.
# MAGIC
# MAGIC * We can use **DROP TABLE** command to drop the table.. Let us drop orders table

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders

# COMMAND ----------

# MAGIC %md
# MAGIC * **DROP TABLE** on managed table will delete both metadata in metastore as well as data in HDFS, while **DROP TABLE** on external table will only delete metadata in metastore.
# MAGIC * We can drop database by using **DROP DATABASE** Command. However we need to drop all the tables in the database first.
# MAGIC * Here is the example to drop the database itversity_retail - `DROP DATABASE itversity_retail`
# MAGIC * We can also drop all the tables and databases by adding **CASCADE**.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_retail CASCADE

# COMMAND ----------

# MAGIC %md
# MAGIC ## Truncating Tables
# MAGIC
# MAGIC Let us understand how to truncate tables.
# MAGIC
# MAGIC * **TRUNCATE** works only for managed tables. Only data will be deleted, structure will be retained.
# MAGIC * Launch Spark SQL

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders'
# MAGIC   INTO TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE EXTERNAL TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
# MAGIC LOCATION '/user/itversity/external/retail_db/orders'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders'
# MAGIC   OVERWRITE INTO TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE orders

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managed Tables - Exercise
# MAGIC
# MAGIC Let us use NYSE data and see how we can create tables in Spark Metastore.
# MAGIC
# MAGIC * Duration: **30 Minutes**
# MAGIC * Data Location (Local): /data/nyse_all/nyse_data
# MAGIC * Create a database with the name - YOUR_OS_USER_NAME_nyse
# MAGIC * Table Name: nyse_eod
# MAGIC * File Format: TEXTFILE (default)
# MAGIC * Review the files by running Linux commands before using data sets. Data is compressed and we can load the files as is.
# MAGIC * Copy one of the zip file to your home directory and preview the data. There should be 7 fields. You need to determine the delimiter.
# MAGIC * Field Names: stockticker, tradedate, openprice, highprice, lowprice, closeprice, volume. For example, you need to use `BIGINT` for volume not `INT`.
# MAGIC * Determine correct data types based on the values
# MAGIC * Create Managed table with default Delimiter.
# MAGIC > As delimiters in data and table are not same, you need to figure out how to get data into the target table.
# MAGIC * Make sure the data is copied into the table as per the structure defined and validate.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation
# MAGIC
# MAGIC Run the following queries to ensure that you will be able to read the data.
# MAGIC
# MAGIC ```
# MAGIC DESCRIBE FORMATTED YOUR_OS_USER_NAME_nyse.nyse_eod;
# MAGIC SELECT * FROM YOUR_OS_USER_NAME_nyse.nyse_eod LIMIT 10
# MAGIC SELECT count(1) FROM YOUR_OS_USER_NAME_nyse.nyse_eod;
# MAGIC ```

# COMMAND ----------

// There should not be field delimiter as the requirement is to use default delimiter
spark.sql("DESCRIBE FORMATTED itversity_nyse.nyse_eod").show(200, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM itversity_nyse.nyse_eod LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM itversity_nyse.nyse_eod

# COMMAND ----------

