# Databricks notebook source
# MAGIC %md
# MAGIC # DML and Partitioning
# MAGIC
# MAGIC As part of this section we will continue understanding further concepts related to DML and also get into the details related to partitioning tables. With respect to DML, earlier we have seen how to use LOAD command, now we will see how to use INSERT command primarily to get query results copied into a table.
# MAGIC
# MAGIC * Introduction to Partitioning
# MAGIC * Creating Tables using Parquet
# MAGIC * LOAD vs. INSERT
# MAGIC * Inserting Data using Stage Table
# MAGIC * Creating Partitioned Tables
# MAGIC * Adding Partitions to Tables
# MAGIC * Loading data into Partitions
# MAGIC * Inserting Data into Partitions
# MAGIC * Using Dynamic Partition Mode
# MAGIC * Exercise - Partitioned Tables
# MAGIC
# MAGIC **Unlike Hive, Spark SQL does not support Bucketing which is similar to Hash Partitioning. However, Delta Lake does. Delta Lake is 3rd party library which facilitate us additional capabilities such as ACID transactions on top of Spark Metastore tables**
# MAGIC
# MAGIC Let us make sure that we have orders table with data as we will be using it to populate partitioned tables very soon.

# COMMAND ----------

val username = System.getProperty("user.name")

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    appName("Spark SQL - Managing Tables - DML and Partitioning").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS itversity_retail.orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders'
# MAGIC     OVERWRITE INTO TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %md
# MAGIC ## Introduction to Partitioning
# MAGIC
# MAGIC Let us get an overview of partitioning of Spark Metastore tables.
# MAGIC
# MAGIC * It is similar to list partitioning where each partition is equal to a particular value for a given column.
# MAGIC * Spark Metastore does not support range partitioning and bucketing. Bucketing is supported in Hive which is similar to Hash Partitioning.
# MAGIC * Once the table is created, we can add static partitions and then load or insert data into it.
# MAGIC * Spark Metastore also support creation of partitions dynamically, where partitions will be created based up on the partition column value.
# MAGIC * A Partitioned table can be managed or external.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Tables using Parquet
# MAGIC
# MAGIC Let us create order_items table using Parquet file format. By default, the files of table using Parquet file format are compressed using Snappy algorithm.
# MAGIC * A table with parquet file format can be external.
# MAGIC * In our case we will create managed table with file format as parquet in STORED AS clause.
# MAGIC * We will explore INSERT to insert query results into this table of type parquet.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %md
# MAGIC * Drop order_items, if it already exists

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE order_items (
# MAGIC   order_item_id INT,
# MAGIC   order_item_order_id INT,
# MAGIC   order_item_product_id INT,
# MAGIC   order_item_quantity INT,
# MAGIC   order_item_subtotal FLOAT,
# MAGIC   order_item_product_price FLOAT
# MAGIC ) STORED AS parquet

# COMMAND ----------

# MAGIC %md
# MAGIC * To get complete output run the below command using `spark-sql`. Here is the output look like.
# MAGIC
# MAGIC ![image.png](attachment:image.png)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FORMATTED order_items

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED order_items").show(200, false)

# COMMAND ----------

val username = System.getProperty("user.name")

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/order_items" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## LOAD vs. INSERT
# MAGIC
# MAGIC Let us compare and contrast LOAD and INSERT commands. These are the main approaches using which we get data into Spark Metastore tables.
# MAGIC
# MAGIC * LOAD will copy the files by dividing them into blocks.
# MAGIC * LOAD is the fastest way of getting data into Spark Metastore tables. However, there will be minimal validations at File level. 
# MAGIC * There will be no transformations or validations at data level.
# MAGIC * If it require any transformation while getting data into Spark Metastore table, then we need to use INSERT command.
# MAGIC * Here are some of the usage scenarios of insert:
# MAGIC   * Changing delimiters in case of text file format
# MAGIC   * Changing file format
# MAGIC   * Loading data into partitioned or bucketed tables (if bucketing is supported).
# MAGIC   * Apply any other transformations at data level (widely used)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE order_items (
# MAGIC   order_item_id INT,
# MAGIC   order_item_order_id INT,
# MAGIC   order_item_product_id INT,
# MAGIC   order_item_quantity INT,
# MAGIC   order_item_subtotal FLOAT,
# MAGIC   order_item_product_price FLOAT
# MAGIC ) STORED AS parquet

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/order_items'
# MAGIC     INTO TABLE order_items

# COMMAND ----------

val username = System.getProperty("user.name")

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/order_items" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inserting Data using Stage Table
# MAGIC
# MAGIC Let us understand how to insert data into order_items with Parquet file format. 
# MAGIC
# MAGIC As data is in text file format and our table is created with Parquet file format, we will not be able to use LOAD command to load the data.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/order_items'
# MAGIC     OVERWRITE INTO TABLE order_items

# COMMAND ----------

# MAGIC %md
# MAGIC * Above load command will be successful, however when we try to query it will fail as the query expects data to be in Parquet file format.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE order_items

# COMMAND ----------

# MAGIC %md
# MAGIC Following are the steps to get data into table which is created using different file format or delimiter than our source data.
# MAGIC
# MAGIC * We need to create stage table with text file format and comma as delimiter (order_items_stage).
# MAGIC * Load data from our files in local file system to stage table.
# MAGIC * Using stage table run insert command to insert data into our target table (order_items).
# MAGIC
# MAGIC Let us see an example of inserting data into the target table from staging table.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE order_items_stage (
# MAGIC   order_item_id INT,
# MAGIC   order_item_order_id INT,
# MAGIC   order_item_product_id INT,
# MAGIC   order_item_quantity INT,
# MAGIC   order_item_subtotal FLOAT,
# MAGIC   order_item_product_price FLOAT
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED order_items_stage").show(200, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/order_items' INTO TABLE order_items_stage

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items_stage LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC TRUNCATE TABLE order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO TABLE order_items
# MAGIC SELECT * FROM order_items_stage

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM order_items

# COMMAND ----------

# MAGIC %md
# MAGIC * `INSERT INTO` will append data into the target table by adding new files.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO TABLE order_items
# MAGIC SELECT * FROM order_items_stage

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM order_items

# COMMAND ----------

# MAGIC %md
# MAGIC * `INSERT OVERWRITE` will overwrite the data in target table by deleting the files related to old data from the directory pointed by the Spark Metastore table.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT OVERWRITE TABLE order_items
# MAGIC SELECT * FROM order_items_stage

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM order_items

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/order_items" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Partitioned Tables
# MAGIC
# MAGIC Let us understand how to create partitioned table and get data into that table.
# MAGIC
# MAGIC * Earlier we have already created orders table. We will use that as reference and create partitioned table.
# MAGIC * We can use `PARTITIONED BY` clause to define the **column along with data type**. In our case we will use **order_month as partition column**.
# MAGIC * We will not be able to directly load the data into the partitioned table using our original orders data (as data is not in sync with structure).
# MAGIC
# MAGIC Here is the example of creating partitioned tables in Spark Metastore.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %md
# MAGIC * Drop orders_part if it already exists

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders_part

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders_part (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) PARTITIONED BY (order_month INT)
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders_part

# COMMAND ----------

spark.sql("DESCRIBE FORMATTED orders_part").show(200, false)

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding Partitions to Tables
# MAGIC
# MAGIC Let us understand how we can add static partitions to Partitioned tables in Spark Metastore.
# MAGIC
# MAGIC * We can add partitions using `ALTER TABLE` command with `ADD PARTITION`.
# MAGIC * For each and every partition created, a subdirectory will be created using partition column name and corresponding value under the table directory.
# MAGIC * Let us understand how to add partitions to **orders_part** table under **itversity_retail** database.

# COMMAND ----------

# MAGIC %md
# MAGIC > Here is the script to add static partitions to a Partitioned table where partition column type is string.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders_part

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders_part (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) PARTITIONED BY (order_month STRING)
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC ALTER TABLE orders_part ADD PARTITION (order_month='2013-07')

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %md
# MAGIC > Here is the script to add static partitions to a Partitioned table where partition column type is integer. We can add one or more partitions at a time. For further demos we will be using this table

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS orders_part

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders_part (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) PARTITIONED BY (order_month INT)
# MAGIC ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders_part

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC ALTER TABLE orders_part ADD PARTITION (order_month=201307)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC ALTER TABLE orders_part ADD
# MAGIC     PARTITION (order_month=201308)
# MAGIC     PARTITION (order_month=201309)
# MAGIC     PARTITION (order_month=201310)

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Loading into Partitions
# MAGIC
# MAGIC Let us understand how to use load command to load data into partitioned tables.
# MAGIC
# MAGIC * We need to make sure that file format of the file which is being loaded into table is same as the file format used while creating the table.
# MAGIC * We also need to make sure that delimiters are consistent between files and table for text file format.
# MAGIC * Also data should match the criteria for the partition into which data is loaded.
# MAGIC * Our `/data/retail_db/orders` have data for the whole year and hence we should not load the data directly into partition.
# MAGIC * We need to split into files matching partition criteria and then load into the table.
# MAGIC
# MAGIC To use load command to load the files into partitions we need to pre-partition the data based on partition logic. 
# MAGIC
# MAGIC Here is the example of using simple shell commands to partition the data. Use command prompt to run these commands
# MAGIC
# MAGIC
# MAGIC ```shell
# MAGIC rm -rf ~/orders
# MAGIC mkdir -p ~/orders
# MAGIC
# MAGIC grep 2013-07 /data/retail_db/orders/part-00000 > ~/orders/orders_201307
# MAGIC grep 2013-08 /data/retail_db/orders/part-00000 > ~/orders/orders_201308
# MAGIC grep 2013-09 /data/retail_db/orders/part-00000 > ~/orders/orders_201309
# MAGIC grep 2013-10 /data/retail_db/orders/part-00000 > ~/orders/orders_201310
# MAGIC ```
# MAGIC
# MAGIC Let us see how we can load data into corresponding partitions. Data has to be pre-partitioned based on the partitioned column.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/home/itversity/orders/orders_201307'
# MAGIC   INTO TABLE orders_part PARTITION (order_month=201307)

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls -R /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/home/itversity/orders/orders_201308'
# MAGIC   INTO TABLE orders_part PARTITION (order_month=201308)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/home/itversity/orders/orders_201309'
# MAGIC   INTO TABLE orders_part PARTITION (order_month=201309)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/home/itversity/orders/orders_201310'
# MAGIC   INTO TABLE orders_part PARTITION (order_month=201310)

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls -R /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

import sys.process._

s"hdfs dfs -tail /user/${username}/warehouse/${username}_retail.db/orders_part/order_month=201310/orders_201310"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders_part LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inserting Data into Partitions
# MAGIC
# MAGIC Let us understand how to use insert to get data into static partitions in Spark Metastore from existing table called as orders.
# MAGIC
# MAGIC * Let us recap what is covered so far related to partitioned tables.
# MAGIC   * We have created a table called as orders_part with order_month of type INT as partitioned column.
# MAGIC   * We have added 4 static partitions for 201307, 201308, 201309 and 201310 using ALTER TABLE command.
# MAGIC   * Once the table is created and partitions are added we have pre-processed the data to get data into the partitions using LOAD command.
# MAGIC * It is not practical to use LOAD command always. We typically use `INSERT` via stage table to copy data into partitioned table.
# MAGIC * We can pre-create partitions in partitioned tables and insert data into partitions using appropriate `INSERT `command. One need to ensure that required filter condition is applied to get the data relevant to the partition that is being populated.
# MAGIC * We can also create partitions dynamically which we will see as part of the next topic.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC ALTER TABLE orders_part ADD PARTITION (order_month=201311)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders_part

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO TABLE orders_part PARTITION (order_month=201311)
# MAGIC   SELECT * FROM orders WHERE order_date LIKE '2013-11%'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders_part

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls -R /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using Dynamic Partition Mode
# MAGIC
# MAGIC Let us understand how we can insert data into partitioned table using dynamic partition mode.
# MAGIC
# MAGIC * Using dynamic partition mode we need not pre create the partitions. Partitions will be automatically created when we issue INSERT command in dynamic partition mode.
# MAGIC * To insert data using dynamic partition mode, we need to set the property `hive.exec.dynamic.partition` to **true**
# MAGIC * Also we need to set `hive.exec.dynamic.partition.mode` to **nonstrict**
# MAGIC
# MAGIC Here is the example of inserting data into partitions using dynamic partition mode.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders_part

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET hive.exec.dynamic.partition

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET hive.exec.dynamic.partition.mode

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET hive.exec.dynamic.partition=true

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET hive.exec.dynamic.partition.mode=nonstrict

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO TABLE orders_part PARTITION (order_month)
# MAGIC SELECT o.*, date_format(order_date, 'yyyyMM') order_month
# MAGIC FROM orders o
# MAGIC WHERE order_date >= '2013-12-01 00:00:00.0'

# COMMAND ----------

import sys.process._

s"hdfs dfs -ls -R /user/${username}/warehouse/${username}_retail.db/orders_part" !

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders_part

# COMMAND ----------

# MAGIC %md
# MAGIC * You will see new partitions created starting from 201312 to 201407.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise - Partitioned Tables
# MAGIC
# MAGIC Let us take care of this exercise related to partitioning to self evaluate our comfort level in working with partitioned tables.
# MAGIC
# MAGIC * Duration: **30 Minutes**
# MAGIC * Use data from **/data/nyse_all/nyse_data**
# MAGIC * Use database **YOUR_OS_USER_NAME_nyse**
# MAGIC * Create partitioned table **nyse_eod_part**
# MAGIC * Field Names: stockticker, tradedate, openprice, highprice, lowprice, closeprice, volume
# MAGIC * Determine correct data types based on the values
# MAGIC * Create Managed table with "," as delimiter.
# MAGIC * Partition Field should be **tradeyear** and of type **INT** (one partition for corresponding year)
# MAGIC * Insert data into partitioned table using dynamic partition mode.
# MAGIC * Here are the steps to come up with the solution.
# MAGIC   * Review the files under **/data/nyse_all/nyse_data** - determine data types (For example: tradedate should be INT and volume should be BIGINT)
# MAGIC   * Create database **YOUR_OS_USER_NAME_nyse** (if it does not exists)
# MAGIC   * Create non partitioned stage table
# MAGIC   * Load data into non partitioned stage table
# MAGIC   * Validate the count and also see that data is as expected by running simple select query.
# MAGIC   * Create partitioned table
# MAGIC   * Set required properties to use dynamic partition
# MAGIC   * Insert data into partitioned table - here is how you can compute year from tradedate of type int `year(to_date(cast(tradedate AS STRING), 'yyyyMMdd')) AS tradeyear`
# MAGIC   * Run below validate commands to validate

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validation
# MAGIC Here are the instructions to validate the results.
# MAGIC * Run `hdfs dfs -ls /user/YOUR_OS_USER_NAME/warehouse/YOUR_OS_USER_NAME_nyse.db/nyse_eod_part`
# MAGIC * Run `SHOW PARTITIONS YOUR_OS_USER_NAME_nyse.nyse_eod_part`. You should see partitions for all the years using which you have loaded the data.
# MAGIC * Run `SELECT count(1) FROM YOUR_OS_USER_NAME_nyse.nyse_eod_part`. The count should match the number of records in our dataset.
# MAGIC * You can compare with the output generated by this simple Python code which is validated in our labs.
# MAGIC
# MAGIC ```
# MAGIC import pandas as pd
# MAGIC import glob
# MAGIC
# MAGIC path = r'/data/nyse_all/nyse_data' # use your path
# MAGIC all_files = glob.glob(path + "/*.txt.gz")
# MAGIC
# MAGIC li = []
# MAGIC
# MAGIC for filename in all_files:
# MAGIC     df = pd.read_csv(filename, index_col=None, header=None)
# MAGIC     li.append(df)
# MAGIC
# MAGIC frame = pd.concat(li, axis=0, ignore_index=True)
# MAGIC frame.shape
# MAGIC ```

# COMMAND ----------

