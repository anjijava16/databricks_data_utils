# Databricks notebook source
# MAGIC %md
# MAGIC # Basic Transformations
# MAGIC
# MAGIC As part of this section we will see basic transformations we can perform on top of Data Frames such as filtering, aggregations, joins etc using SQL. We will build end to end solution by taking a simple problem statement.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/w4IZNOCEcd4?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Spark SQL – Overview
# MAGIC * Define Problem Statement
# MAGIC * Preparing Tables
# MAGIC * Projecting Data
# MAGIC * Filtering Data
# MAGIC * Joining Tables - Inner
# MAGIC * Joining Tables - Outer
# MAGIC * Perform Aggregations
# MAGIC * Sorting Data
# MAGIC * Conclusion - Final Solution

# COMMAND ----------

# MAGIC %md
# MAGIC If you are going to use CLIs, you can use Spark SQL using one of the 3 approaches.
# MAGIC
# MAGIC **Using Spark SQL**
# MAGIC
# MAGIC ```
# MAGIC spark2-sql \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Scala**
# MAGIC
# MAGIC ```
# MAGIC spark2-shell \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Pyspark**
# MAGIC
# MAGIC ```
# MAGIC pyspark2 \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## Spark SQL – Overview
# MAGIC
# MAGIC Let us get an overview of Spark SQL.
# MAGIC
# MAGIC Here are the standard operations which we typically perform as part of processing the data. In Spark we can perform these using Data Frame APIs or **Spark SQL**.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/R7n6wDILtos?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Selection or Projection – select clause
# MAGIC   * It is also called as row level transformations.
# MAGIC   * Apply standardization rules (convert names and addresses to upper case).
# MAGIC   * Mask partial data (SSN and Date of births).
# MAGIC * Filtering data – where clause
# MAGIC   * Get orders based on date or product or category.
# MAGIC * Joins – join (supports outer join as well)
# MAGIC   * Join multiple data sets.
# MAGIC * Aggregations – group by and aggregations with support of functions such as sum, avg, min, max etc
# MAGIC   * Get revenue for a given order
# MAGIC   * Get revenue for each order
# MAGIC   * Get daily revenue
# MAGIC * Sorting – order by
# MAGIC   * Sort the final output by date.
# MAGIC   * Sort the final output by date, then by revenue in descending order.
# MAGIC   * Sort the final output by state or province, then by revenue in descending order.
# MAGIC * Analytics Functions – aggregations, ranking and windowing functions
# MAGIC   * Get top 5 stores by revenue for each state.
# MAGIC   * Get top 5 products by revenue in each category.

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    appName("Spark SQL - Overview").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define Problem Statement
# MAGIC
# MAGIC Let us define problemt statement to get an overview of basic transformations using Spark SQL.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/dRbLxxpSeS8?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Get Daily Product Revenue using orders and order_items data set.
# MAGIC * We have following fields in **orders**.
# MAGIC   * order_id
# MAGIC   * order_date
# MAGIC   * order_customer_id
# MAGIC   * order_status
# MAGIC * We have following fields in **order_items**.
# MAGIC   * order_item_id
# MAGIC   * order_item_order_id
# MAGIC   * order_item_product_id
# MAGIC   * order_item_quantity
# MAGIC   * order_item_subtotal
# MAGIC   * order_item_product_price
# MAGIC * We have one to many relationship between orders and order_items.
# MAGIC * **orders.order_id** is **primary key** and **order_items.order_item_order_id** is foreign key to **orders.order_id**.
# MAGIC * By the end of this module we will explore all standard transformation and get daily product revenue using following fields.
# MAGIC   * **orders.order_date**
# MAGIC   * **order_items.order_item_product_id**
# MAGIC   * **order_items.order_item_subtotal** (aggregated using date and product_id).
# MAGIC * We will consider only **COMPLETE** or **CLOSED** orders.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Preparing Tables
# MAGIC
# MAGIC Let us prepare the tables to solve the problem.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/TZlQ2hohgck?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Make sure database is created.
# MAGIC * Create **orders** table.
# MAGIC * Load data from local path **/data/retail_db/orders** into newly created **orders** table.
# MAGIC * Preview data and get count from **orders**
# MAGIC * Create **order_items** table.
# MAGIC * Load data from local path **/data/retail_db/order_items** into newly created **orders** table.
# MAGIC * Preview data and get count from **order_items**
# MAGIC
# MAGIC As tables and data are ready let us get into how to write queries against tables to perform basic transformation.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_retail CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC     order_id INT,
# MAGIC     order_date STRING,
# MAGIC     order_customer_id INT,
# MAGIC     order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/orders"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' INTO TABLE orders

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/orders"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE order_items

# COMMAND ----------

# MAGIC %%sql 
# MAGIC
# MAGIC CREATE TABLE order_items (
# MAGIC     order_item_id INT,
# MAGIC     order_item_order_id INT,
# MAGIC     order_item_product_id INT,
# MAGIC     order_item_quantity INT,
# MAGIC     order_item_subtotal FLOAT,
# MAGIC     order_item_product_price FLOAT
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/order_items"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/order_items' INTO TABLE order_items

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/order_items"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM order_items LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM order_items

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("DROP DATABASE itversity_retail CASCADE")

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS itversity_retail")

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("SHOW tables")

# COMMAND ----------

spark.sql("DROP TABLE orders")

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
    order_id INT,
    order_date STRING,
    order_customer_id INT,
    order_status STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
""")

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/orders"!

# COMMAND ----------

spark.sql("LOAD DATA LOCAL INPATH '/data/retail_db/orders' INTO TABLE orders")

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/orders"!

# COMMAND ----------

spark.sql("SELECT * FROM orders LIMIT 10").show()

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders").show()

# COMMAND ----------

spark.sql("DROP TABLE order_items")

# COMMAND ----------

spark.sql("""
CREATE TABLE order_items (
    order_item_id INT,
    order_item_order_id INT,
    order_item_product_id INT,
    order_item_quantity INT,
    order_item_subtotal FLOAT,
    order_item_product_price FLOAT
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
""")

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/order_items"!

# COMMAND ----------

spark.sql("LOAD DATA LOCAL INPATH '/data/retail_db/order_items' INTO TABLE order_items")

# COMMAND ----------

import sys.process._
val username = System.getProperty("user.name")
s"hdfs dfs -ls /user/itversity/warehouse/${username}_retail.db/order_items"!

# COMMAND ----------

spark.sql("SELECT * FROM order_items LIMIT 10").show()

# COMMAND ----------

spark.sql("SELECT count(1) FROM order_items").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Projecting Data
# MAGIC
# MAGIC Let us understand different aspects of projecting data. We primarily using `SELECT` to project the data.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/8BBzd60hYFc?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We can project all columns using `*` or some columns using column names.
# MAGIC * We can provide aliases to a column or expression using `AS` in `SELECT` clause.
# MAGIC * `DISTINCT` can be used to get the distinct records from selected columns. We can also use `DISTINCT *` to get unique records using all the columns.
# MAGIC * As of now **Spark SQL** does not support projecting all but one or few columns. It is supported in Hive. Following will work in hive and it will project all the columns from orders except for order_id.
# MAGIC
# MAGIC ```
# MAGIC SET hive.support.quoted.identifiers=none;
# MAGIC SELECT `(order_id)?+.+` FROM orders;
# MAGIC ```

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_customer_id, order_date, order_status FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_customer_id, date_format(order_date, 'yyyy-MM'), order_status FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_customer_id, 
# MAGIC     date_format(order_date, 'yyyy-MM') AS order_month, 
# MAGIC     order_status 
# MAGIC FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT DISTINCT order_status FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT DISTINCT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("SELECT * FROM orders").show()

# COMMAND ----------

spark.sql("DESCRIBE orders").show()

# COMMAND ----------

spark.sql("SELECT order_customer_id, order_date, order_status FROM orders").show()

# COMMAND ----------

spark.sql("""
SELECT order_customer_id, 
    date_format(order_date, 'yyyy-MM'), 
    order_status 
FROM orders""").show()

# COMMAND ----------

spark.sql("""
SELECT order_customer_id, 
    date_format(order_date, 'yyyy-MM') AS order_month, 
    order_status 
FROM orders
""").show()

# COMMAND ----------

spark.sql("SELECT DISTINCT order_status FROM orders").show()

# COMMAND ----------

spark.sql("SELECT DISTINCT * FROM orders").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filtering Data
# MAGIC
# MAGIC Let us understand how we can filter the data in Spark SQL.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/x6sUnQ553Ow?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We use `WHERE` clause to filter the data.
# MAGIC * All comparison operators such as `=`, `!=`, `>`, `<`, etc can be used to compare a column or expression or literal with another column or expression or literal.
# MAGIC * We can use operators such as LIKE with % and regexp_like for pattern matching.
# MAGIC * Boolan OR and AND can be performed when we want to apply multiple conditions.
# MAGIC   * Get all orders with order_status equals to COMPLETE or CLOSED. We can also use IN operator.
# MAGIC   * Get all orders from month 2014 January with order_status equals to COMPLETE or CLOSED
# MAGIC * We need to use `IS NULL` and `IS NOT NULL` to compare against null values.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders WHERE order_status = 'COMPLETE' LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders WHERE order_status = 'COMPLETE'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders WHERE order_status IN ('COMPLETE', 'CLOSED') LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders WHERE order_status = 'COMPLETE' OR order_status = 'CLOSED' LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders WHERE order_status IN ('COMPLETE', 'CLOSED')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders WHERE order_status = 'COMPLETE' OR order_status = 'CLOSED'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders 
# MAGIC WHERE order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND order_date LIKE '2014-01%'
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders 
# MAGIC WHERE order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND order_date LIKE '2014-01%'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders 
# MAGIC WHERE order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND date_format(order_date, 'yyyy-MM') = '2014-01'
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM orders 
# MAGIC WHERE order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND date_format(order_date, 'yyyy-MM') = '2014-01'

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("SHOW tables").show()

# COMMAND ----------

spark.sql("SELECT * FROM orders WHERE order_status = 'COMPLETE'").show()

# COMMAND ----------

spark.sql("SELECT count(1) FROM orders WHERE order_status = 'COMPLETE'").show()

# COMMAND ----------

spark.sql("SELECT * FROM orders WHERE order_status IN ('COMPLETE', 'CLOSED')").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM orders 
WHERE order_status = 'COMPLETE' OR order_status = 'CLOSED'
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1) FROM orders 
WHERE order_status IN ('COMPLETE', 'CLOSED')
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1) FROM orders
WHERE order_status = 'COMPLETE' OR order_status = 'CLOSED'
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM orders 
WHERE order_status IN ('COMPLETE', 'CLOSED')
    AND order_date LIKE '2014-01%'
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1) FROM orders 
WHERE order_status IN ('COMPLETE', 'CLOSED')
    AND order_date LIKE '2014-01%'
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM orders 
WHERE order_status IN ('COMPLETE', 'CLOSED')
    AND date_format(order_date, 'yyyy-MM') = '2014-01'
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1) FROM orders 
WHERE order_status IN ('COMPLETE', 'CLOSED')
    AND date_format(order_date, 'yyyy-MM') = '2014-01'
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Let us prepare the table to demonstrate how to deal with null values while filtering the data.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_sms CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_sms

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS students

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE students (
# MAGIC     student_id INT,
# MAGIC     student_first_name STRING,
# MAGIC     student_last_name STRING,
# MAGIC     student_phone_number STRING,
# MAGIC     student_address STRING
# MAGIC ) STORED AS avro

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (1, 'Scott', 'Tiger', NULL, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES (2, 'Donald', 'Duck', '1234567890', NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO students VALUES 
# MAGIC     (3, 'Mickey', 'Mouse', '2345678901', 'A Street, One City, Some State, 12345'),
# MAGIC     (4, 'Bubble', 'Guppy', '6789012345', 'Bubbly Street, Guppy, La la land, 45678')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM students

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("DROP DATABASE IF EXISTS itversity_sms CASCADE")

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS itversity_sms")

# COMMAND ----------

spark.sql("DROP TABLE IF EXISTS students")

# COMMAND ----------

spark.sql("""
CREATE TABLE students (
    student_id INT,
    student_first_name STRING,
    student_last_name STRING,
    student_phone_number STRING,
    student_address STRING
) STORED AS avro
""")

# COMMAND ----------

spark.sql("""
INSERT INTO students 
VALUES (1, 'Scott', 'Tiger', NULL, NULL)
""")

# COMMAND ----------

spark.sql("""
INSERT INTO students 
VALUES (2, 'Donald', 'Duck', '1234567890', NULL)
""")

# COMMAND ----------

spark.sql("""
INSERT INTO students VALUES 
    (3, 'Mickey', 'Mouse', '2345678901', 'A Street, One City, Some State, 12345'),
    (4, 'Bubble', 'Guppy', '6789012345', 'Bubbly Street, Guppy, La la land, 45678')
""")

# COMMAND ----------

spark.sql("SELECT * FROM students").show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Comparison against null can be done with `IS NULL` and `IS NOT NULL`. Below query will not work even though we have one record with phone_numbers as null.

# COMMAND ----------

spark.sql("""
SELECT * FROM students 
WHERE student_phone_number = NULL
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM students 
WHERE student_phone_number != NULL
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM students
WHERE student_phone_number IS NULL
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM students
WHERE student_phone_number IS NOT NULL
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Joining Tables - Inner
# MAGIC
# MAGIC Let us understand how to join data from multiple tables.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/gKAhugUD218?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * **Spark SQL** supports ASCII style join (**JOIN with ON**).
# MAGIC * There are different types of joins.
# MAGIC   * INNER JOIN - Get all the records from both the datasets which satisfies JOIN condition.
# MAGIC   * OUTER JOIN - We will get into the details as part of the next topic
# MAGIC * Example for INNER JOIN
# MAGIC
# MAGIC ```
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC LIMIT 10
# MAGIC ```
# MAGIC
# MAGIC * We can join more than 2 tables in one query. Here is how it will look like.
# MAGIC
# MAGIC ```
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC     JOIN products p
# MAGIC     ON p.product_id = oi.order_item_product_id
# MAGIC LIMIT 10
# MAGIC ```
# MAGIC
# MAGIC * If we have to apply additional filters, it is recommended to use WHERE clause. ON clause should only have join conditions.
# MAGIC * We can have non equal join conditions as well, but they are not used that often.
# MAGIC * Here are some of the examples for INNER JOIN:
# MAGIC   * Get order id, date, status and item revenue for all order items.
# MAGIC   * Get order id, date, status and item revenue for all order items for all orders where order status is either COMPLETE or CLOSED.
# MAGIC   * Get order id, date, status and item revenue for all order items for all orders where order status is either COMPLETE or CLOSED for the orders that are placed in the month of 2014 January.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND date_format(order_date, 'yyyy-MM') = '2014-01'
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND date_format(order_date, 'yyyy-MM') = '2014-01'
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_subtotal
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark("""
SELECT count(1)
FROM orders
""").show()

# COMMAND ----------

spark("""
SELECT count(1)
FROM order_items
""").show()

# COMMAND ----------

spark("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_subtotal
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark("""
SELECT count(1)
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_subtotal
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
""").show()

# COMMAND ----------

spark("""
SELECT count(1)
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
""").show()

# COMMAND ----------

spark("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_subtotal
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
    AND date_format(order_date, 'yyyy-MM') = '2014-01'
""").show()

# COMMAND ----------

spark("""
SELECT count(1)
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
    AND date_format(order_date, 'yyyy-MM') = '2014-01'
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Joining Tables - Outer
# MAGIC
# MAGIC Let us understand how to perform outer joins using Spark SQL. There are 3 different types of outer joins.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/RSE61x6B_90?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * LEFT OUTER JOIN (default) - Get all the records from both the datasets which satisfies JOIN condition along with those records which are in the left side table but not in the right side table.
# MAGIC * RIGHT OUTER JOIN - Get all the records from both the datasets which satisfies JOIN condition along with those records which are in the right side table but not in the left side table.
# MAGIC * FULL OUTER JOIN - left union right
# MAGIC * When we perform the outer join (lets say left outer join), we will see this.
# MAGIC   * Get all the values from both the tables when join condition satisfies.
# MAGIC   * If there are rows on left side tables for which there are no corresponding values in right side table, all the projected column values for right side table will be null.
# MAGIC * Here are some of the examples for outer join.
# MAGIC     * Get all the orders where there are no corresponding order items.
# MAGIC     * Get all the order items where there are no corresponding orders.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_order_id,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o LEFT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o LEFT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_order_id,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o LEFT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE oi.order_item_order_id IS NULL
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o LEFT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE oi.order_item_order_id IS NULL

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o LEFT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE oi.order_item_order_id IS NULL
# MAGIC     AND o.order_status IN ('COMPLETE', 'CLOSED')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_order_id,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o RIGHT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1)
# MAGIC FROM orders o RIGHT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_id,
# MAGIC     o.order_date,
# MAGIC     o.order_status,
# MAGIC     oi.order_item_order_id,
# MAGIC     oi.order_item_subtotal
# MAGIC FROM orders o RIGHT OUTER JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_id IS NULL
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_order_id,
    oi.order_item_subtotal
FROM orders o LEFT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1)
FROM orders o LEFT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_order_id,
    oi.order_item_subtotal
FROM orders o LEFT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE oi.order_item_order_id IS NULL
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1)
FROM orders o LEFT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE oi.order_item_order_id IS NULL

# COMMAND ----------

spark.sql("""
SELECT count(1)
FROM orders o LEFT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE oi.order_item_order_id IS NULL
    AND o.order_status IN ('COMPLETE', 'CLOSED')
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_order_id,
    oi.order_item_subtotal
FROM orders o RIGHT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1)
FROM orders o RIGHT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_id,
    o.order_date,
    o.order_status,
    oi.order_item_order_id,
    oi.order_item_subtotal
FROM orders o RIGHT OUTER JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_id IS NULL
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregating Data
# MAGIC
# MAGIC Let us understand how to aggregate the data.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/sbKVUr7fZCk?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We can perform global aggregations as well as aggregations by key.
# MAGIC * Global Aggregations
# MAGIC   * Get total number of orders.
# MAGIC   * Get revenue for a given order id.
# MAGIC   * Get number of records with order_status either COMPLETED or CLOSED.
# MAGIC * Aggregations by key - using `GROUP BY`
# MAGIC   * Get number of orders by date or status.
# MAGIC   * Get revenue for each order_id.
# MAGIC   * Get daily product revenue (using order date and product id as keys).
# MAGIC * We can also use `HAVING` clause to apply filtering on top of aggregated data.
# MAGIC   * Get daily product revenue where revenue is greater than $500 (using order date and product id as keys).
# MAGIC * Rules while using `GROUP BY`.
# MAGIC   * We can have the columns which are specified as part of `GROUP BY` in `SELECT` clause.
# MAGIC   * On top of those, we can have derived columns using aggregate functions.
# MAGIC   * We cannot have any other columns that are not used as part of `GROUP BY` on derived column using non aggregate functions.
# MAGIC   * We will not be able to use aggregate functions or aliases used in the select clause as part of the where clause.
# MAGIC   * If we want to filter based on aggregated results, then we can leverage `HAVING` on top of `GROUP BY` (specifying `WHERE` is not an option)
# MAGIC * Typical query execution - FROM -> WHERE -> GROUP BY -> SELECT

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(order_id) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(DISTINCT order_date) FROM orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT round(sum(order_item_subtotal), 2) AS order_revenue
# MAGIC FROM order_items 
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) 
# MAGIC FROM orders
# MAGIC WHERE order_status IN ('COMPLETE', 'CLOSED')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_date,
# MAGIC     count(1)
# MAGIC FROM orders
# MAGIC GROUP BY order_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_status,
# MAGIC     count(1) AS status_count
# MAGIC FROM orders
# MAGIC GROUP BY order_status

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id,
# MAGIC     round(sum(order_item_subtotal), 2) AS order_revenue
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC     AND revenue >= 500
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id
# MAGIC HAVING revenue >= 500
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("SELECT count(order_id) FROM orders").show()

# COMMAND ----------

spark.sql("SELECT count(DISTINCT order_date) FROM orders").show()

# COMMAND ----------

spark.sql("""
SELECT round(sum(order_item_subtotal), 2) AS order_revenue
FROM order_items 
WHERE order_item_order_id = 2
""").show()

# COMMAND ----------

spark.sql("""
SELECT count(1) 
FROM orders
WHERE order_status IN ('COMPLETE', 'CLOSED')
""").show()

# COMMAND ----------

spark.sql("""
SELECT order_date,
    count(1)
FROM orders
GROUP BY order_date
""").show()

# COMMAND ----------

spark.sql("""
SELECT order_status,
    count(1) AS status_count
FROM orders
GROUP BY order_status
""").show()

# COMMAND ----------

spark.sql("""
SELECT order_item_order_id,
    round(sum(order_item_subtotal), 2) AS order_revenue
FROM order_items
GROUP BY order_item_order_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
GROUP BY o.order_date,
    oi.order_item_product_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
    AND revenue >= 500
GROUP BY o.order_date,
    oi.order_item_product_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
GROUP BY o.order_date,
    oi.order_item_product_id
HAVING revenue >= 500
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sorting Data
# MAGIC
# MAGIC Let us understand how to sort the data using **Spark SQL**.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/zh3fWDXknfg?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We typically perform sorting as final step.
# MAGIC * Sorting can be done either by using one field or multiple fields.
# MAGIC * We can sort the data either in ascending order or descending order by using column or expression.
# MAGIC * By default, the sorting order is ascendig and we can change it to descending by using `DESC`.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders
# MAGIC ORDER BY order_customer_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders
# MAGIC ORDER BY order_customer_id,
# MAGIC     order_date
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders
# MAGIC ORDER BY order_customer_id,
# MAGIC     order_date DESC
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id
# MAGIC ORDER BY o.order_date,
# MAGIC     revenue DESC
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("""
SELECT * FROM orders
ORDER BY order_customer_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM orders
ORDER BY order_customer_id,
    order_date
""").show()

# COMMAND ----------

spark.sql("""
SELECT * FROM orders
ORDER BY order_customer_id,
    order_date DESC
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
GROUP BY o.order_date,
    oi.order_item_product_id
ORDER BY o.order_date,
    revenue DESC
""").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion - Final Solution
# MAGIC
# MAGIC Let us review the Final Solution for our problem statement **daily_product_revenue**.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/TiCkbK87aQk?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Prepare tables
# MAGIC   * Create tables
# MAGIC   * Load the data into tables
# MAGIC * We need to project the fields which we are interested in.
# MAGIC   * order_date
# MAGIC   * order_item_product_id
# MAGIC   * product_revenue
# MAGIC * As we have fields from multiple tables, we need to perform join after which we have to filter for COMPLETE or CLOSED orders.
# MAGIC * We have to group the data by order_date and order_item_product_id, then we have to perform aggregation on order_item_subtotal to get product_revenue.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_retail CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC     order_id INT,
# MAGIC     order_date STRING,
# MAGIC     order_customer_id INT,
# MAGIC     order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/orders' INTO TABLE orders

# COMMAND ----------

# MAGIC %%sql 
# MAGIC
# MAGIC CREATE TABLE order_items (
# MAGIC     order_item_id INT,
# MAGIC     order_item_order_id INT,
# MAGIC     order_item_product_id INT,
# MAGIC     order_item_quantity INT,
# MAGIC     order_item_subtotal FLOAT,
# MAGIC     order_item_product_price FLOAT
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC LOAD DATA LOCAL INPATH '/data/retail_db/order_items' INTO TABLE order_items

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS product_revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.order_date,
# MAGIC     oi.order_item_product_id,
# MAGIC     round(sum(oi.order_item_subtotal), 2) AS product_revenue
# MAGIC FROM orders o JOIN order_items oi
# MAGIC     ON o.order_id = oi.order_item_order_id
# MAGIC WHERE o.order_status IN ('COMPLETE', 'CLOSED')
# MAGIC GROUP BY o.order_date,
# MAGIC     oi.order_item_product_id
# MAGIC ORDER BY o.order_date,
# MAGIC     product_revenue DESC

# COMMAND ----------

# MAGIC %md
# MAGIC * Using Spark SQL with Python or Scala

# COMMAND ----------

spark.sql("DROP DATABASE itversity_retail CASCADE")

# COMMAND ----------

spark.sql("CREATE DATABASE IF NOT EXISTS itversity_retail")

# COMMAND ----------

spark.sql("USE itversity_retail")

# COMMAND ----------

spark.sql("SHOW tables").show()

# COMMAND ----------

spark.sql("""
CREATE TABLE orders (
    order_id INT,
    order_date STRING,
    order_customer_id INT,
    order_status STRING
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
""")

# COMMAND ----------

spark.sql("""
LOAD DATA LOCAL INPATH '/data/retail_db/orders' 
INTO TABLE orders
""")

# COMMAND ----------

spark.sql("""
CREATE TABLE order_items (
    order_item_id INT,
    order_item_order_id INT,
    order_item_product_id INT,
    order_item_quantity INT,
    order_item_subtotal FLOAT,
    order_item_product_price FLOAT
) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
""")

# COMMAND ----------

spark.sql("""
LOAD DATA LOCAL INPATH '/data/retail_db/order_items' 
INTO TABLE order_items
""")

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS product_revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
GROUP BY o.order_date,
    oi.order_item_product_id
""").show()

# COMMAND ----------

spark.sql("""
SELECT o.order_date,
    oi.order_item_product_id,
    round(sum(oi.order_item_subtotal), 2) AS product_revenue
FROM orders o JOIN order_items oi
    ON o.order_id = oi.order_item_order_id
WHERE o.order_status IN ('COMPLETE', 'CLOSED')
GROUP BY o.order_date,
    oi.order_item_product_id
ORDER BY o.order_date,
    product_revenue DESC
""").show()

# COMMAND ----------

