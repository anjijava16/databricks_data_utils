# Databricks notebook source
# MAGIC %md
# MAGIC # Getting Started
# MAGIC
# MAGIC Let us get started to get into Spark SQL. In this module we will see how to launch and use Spark SQL.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/p83npp8FYe0?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Overview of Spark Documentation
# MAGIC * Launching and Using Spark SQL
# MAGIC * Overview of Spark SQL Properties
# MAGIC * Running OS Commands using Spark SQL
# MAGIC * Understanding Warehouse Directory
# MAGIC * Managing Spark Metastore Databases
# MAGIC * Managing Spark Metastore Tables
# MAGIC * Retrieve Metadata of Tables
# MAGIC * Role of Spark or Hive Metastore

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Spark Documentation
# MAGIC
# MAGIC Let us go through the details related to Spark Documentation. It is very important for you to get comfortable with Spark Documentation if you are aspiring for open book certification exams like CCA 175.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/_gAD1tdxoKw?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Click [here](https://spark.apache.org/docs/latest/sql-programming-guide.html) to go to latest Spark SQL and Data Frames documentation. 
# MAGIC * We typically get documentation for latest version.
# MAGIC * We can replace **latest** in the URL with the version of Spark to get specific version's official documentation.
# MAGIC * Also we have resources provided by **databricks**.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Launching and Using Spark SQL
# MAGIC
# MAGIC Let us understand how to launch Spark SQL CLI.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/R-qwe2E9ob0?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Logon to the gateway node of the cluster.
# MAGIC * We have 2 versions of Spark in our labs. One can use `spark-sql` to launch Spark SQL using 1.6.x and `spark2-sql` to launch Spark SQL using 2.3.x.
# MAGIC * Launch Spark SQL CLI using `spark-sql`. In clustered mode we might have to add additional arguments. For example
# MAGIC
# MAGIC ```
# MAGIC spark2-sql \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC * One can get help using `spark-sql --help`
# MAGIC * For e. g.: we can use `spark-sql --database training_retail` to connect to specific database. Here is the example in clustered mode.
# MAGIC
# MAGIC ```
# MAGIC spark2-sql \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse \
# MAGIC     --database ${USER}_retail
# MAGIC ```
# MAGIC * Spark SQL CLI will be launched and will be connected to **${USER}_retail** database.
# MAGIC * We can validate to which database we are connected to using `SELECT current_database()`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Spark SQL Properties
# MAGIC Let us understand details about Spark SQL properties which control Spark SQL run time environment. 

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/2JrWYGbBR_8?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Spark SQL inherits properties defined for Spark. There are some Spark SQL related properties as well and these are applicable even for Data Frames.
# MAGIC * We can review these properties using Management Tools such as **Ambari** or **Cloudera Manager Web UI**
# MAGIC * Spark run time behavior is controlled by HDFS Properties files, YARN Properties files, Hive Properties files etc in those clusters where Spark is integrated with Hadoop and Hive.
# MAGIC * We can get all the properties using `SET;` in Spark SQL CLI
# MAGIC
# MAGIC Let us review some important properties in Spark SQL. 
# MAGIC
# MAGIC ```
# MAGIC spark.sql.warehouse.dir
# MAGIC spark.sql.catalogImplementation
# MAGIC ```
# MAGIC * We can review the current value using `SET spark.sql.warehouse.dir;`

# COMMAND ----------

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    master("yarn").
    appName("Getting Started - Spark SQL").
    getOrCreate

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET spark.sql.warehouse.dir

# COMMAND ----------

# MAGIC %md
# MAGIC * Properties with default values does not show up as part of `SET` command. But we can check and overwrite the values - for example

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET spark.sql.shuffle.partitions

# COMMAND ----------

# MAGIC %md
# MAGIC * We can overwrite property by setting value using the same **SET** command, eg:

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET spark.sql.shuffle.partitions=2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Running OS Commands using Spark SQL
# MAGIC
# MAGIC Let us understand how to run OS commands using Spark SQL CLI.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/1yp8aTJXYAI?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We can run OS commands using **!** at the beginning.
# MAGIC   * Listing local Files `!ls -ltr;`
# MAGIC   * Listing HDFS Files `!hdfs dfs -ls /public/retail_db;`

# COMMAND ----------

import sys.process._

"ls -ltr"!

# COMMAND ----------

import sys.process._

"hdfs dfs -ls /public/retail_db"!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Understanding Warehouse Directory
# MAGIC
# MAGIC Let us go through the details related to Spark Metastore Warehouse Directory.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/JjMnOstLLUk?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * A Database in Spark SQL is nothing but directory in underlying file system like HDFS. 
# MAGIC * A Spark Metastore Table is nothing but directory in underlying file systems like HDFS.
# MAGIC * A Partition of Spark Metastore Table is nothing but directory in underlying file systems like HDFS under table.
# MAGIC * Warehouse Directory is the base directory where directories related to databases, tables go by default.
# MAGIC * It is controlled by `spark.sql.warehouse.dir`. You can get the value by saying `SET spark.sql.warehouse.dir;`
# MAGIC > <span style="color:red">Do not overwrite this property Spark SQL CLI. It will not have any effect.</span>
# MAGIC * Underlying directory for a database will have **.db** extension.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SET spark.sql.warehouse.dir

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managing Spark Metastore Databases
# MAGIC
# MAGIC Let us undestand how to manage Spark Metastore Databases.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/LhayXSutoHk?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Make a habit of reviewing Language Manual.
# MAGIC * We can create database using **CREATE DATABASE** Command.
# MAGIC * For e. g.: `CREATE DATABASE itversity_demo;`
# MAGIC * If the database exists it will fail. If you want to ignore with out throwing error you can use **IF NOT EXISTS**
# MAGIC * e. g.: `CREATE DATABASE IF NOT EXISTS itversity_demo;`
# MAGIC * We can list the databases using `SHOW databases;`
# MAGIC * Spark Metastore is multi tenant database. To switch to a database, you can use **USE** Command. e. g.: `USE itversity_demo;`
# MAGIC * We can drop empty database by using `DROP DATABASE itversity_demo;`.
# MAGIC * Add cascade to drop all the tables and then the database `DROP DATABASE itversity_demo CASCADE;`.
# MAGIC * We can also specify location while creating the database - `CREATE DATABASE itversity_demo LOCATION '/user/itversity/custom/itversity_demo.db'`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW databases

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

val username = System.getProperty("user.name")

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/warehouse/${username}_demo.db"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE table_demo (i INT)

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/warehouse/${username}_demo.db"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_demo CASCADE

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/warehouse/${username}_demo.db"!

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE itversity_demo LOCATION '/user/itversity/custom/itversity_demo.db'

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/custom"! // Directory will be created if it does not exists

# COMMAND ----------

import sys.process._
s"hdfs dfs -ls /user/${username}/custom/${username}_demo.db"!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managing Spark Metastore Tables
# MAGIC
# MAGIC Let us create our first Spark Metastore table. We will also have a look into how to list the tables.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/I8-TFwtIHrw?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We will get into details related to DDL Commands at a later point in time. 
# MAGIC * For now we will just create our first table. We will get into the details about creating tables as part of subsequent sections.
# MAGIC > <span style="color:red">Use your OS username as prefix for the databases, if you are using our labs</span>

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE itversity_retail CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ','

# COMMAND ----------

# MAGIC %md
# MAGIC * We can list the tables using `SHOW tables;`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %md
# MAGIC * We can also drop the table using `DROP TABLE` command. We will get into more details at a later point in time.
# MAGIC * We can also truncate the managed tables using `TRUNCATE TABLE` command.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Retrieve Metadata of Tables
# MAGIC
# MAGIC As the table is created, let us understand how to get the metadata of a table.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/AHaoOnQci30?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * We can get metadata of Hive Tables using several commands.
# MAGIC   * DESCRIBE - e.g.: `DESCRIBE orders;`
# MAGIC   * DESCRIBE EXTENDED - e.g.: `DESCRIBE EXTENDED orders;`
# MAGIC   * DESCRIBE FORMATTED - e.g.: `DESCRIBE FORMATTED orders;`
# MAGIC * **DESCRIBE** will give only field names and data types.
# MAGIC * **DESCRIBE EXTENDED** will give all the metadata, but not in readable format in Hive. It is same as **DESCRIBE FORMATTED** in Spark SQL.
# MAGIC * **DESCRIBE FORMATTED** will give metadata in readable format.
# MAGIC
# MAGIC **As the output is truncated using Jupyter, we will actually see the details using `spark-sql`**

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE EXTENDED orders

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FORMATTED orders

# COMMAND ----------

# MAGIC %md
# MAGIC ## Role of Spark or Hive Metastore
# MAGIC
# MAGIC Let us understand the role of Spark Metastore or Hive Metasore. We need to first understand details related to Metadata generated for Spark Metastore tables.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/MKzHiKgKHIY?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * When we create a Spark Metastore table, there is metadata associated with it.
# MAGIC   * Table Name
# MAGIC   * Column Names and Data Types
# MAGIC   * Location
# MAGIC   * File Format
# MAGIC   * and more
# MAGIC * This metadata has to be stored some where so that Query Engines such as Spark SQL can access the information to serve our queries.
# MAGIC
# MAGIC Let us understand where the metadata is stored.
# MAGIC
# MAGIC * Information is typically stored in relational database and it is called as metastore.
# MAGIC * It is extensively used by Hive or Spark SQL engine for syntax and semantics check as well as execution of queries.
# MAGIC * In our case it is stored in MySQL Database. Let us review the details by going through relevant properties.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise - Getting Started with Spark SQL
# MAGIC
# MAGIC Let's do a simple exercise to conclude this section.

# COMMAND ----------

# MAGIC %%HTML
# MAGIC <iframe width="560" height="315" src="https://www.youtube.com/embed/9Wr1A2Mvtv8?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>

# COMMAND ----------

# MAGIC %md
# MAGIC * Launch Spark SQL (don't use database) (use spark-sql command). Here is the script for our labs. In other environments, you can skip last line. I have also included commands to launch Spark using Scala or Python (for CCA 175 Certification purpose)
# MAGIC
# MAGIC **Using Spark SQL**
# MAGIC
# MAGIC ```
# MAGIC spark2-sql \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Scala**
# MAGIC
# MAGIC ```
# MAGIC spark2-shell \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC **Using Pyspark**
# MAGIC
# MAGIC ```
# MAGIC pyspark2 \
# MAGIC     --master yarn \
# MAGIC     --conf spark.ui.port=0 \
# MAGIC     --conf spark.sql.warehouse.dir=/user/${USER}/warehouse
# MAGIC ```
# MAGIC
# MAGIC * Create Database and exit (make sure to prefix database name with your OS username, e. g.: **training_retail** for OS user training)
# MAGIC * Exit and launch connecting to your database
# MAGIC * Create Table orders. You can use below script to create the table.
# MAGIC
# MAGIC ```
# MAGIC CREATE TABLE orders (
# MAGIC   order_id INT,
# MAGIC   order_date STRING,
# MAGIC   order_customer_id INT,
# MAGIC   order_status STRING
# MAGIC ) ROW FORMAT DELIMITED FIELDS TERMINATED BY ',';
# MAGIC ```
# MAGIC
# MAGIC * List the tables
# MAGIC * Describe the table and review the whole metadata