# Databricks notebook source
# MAGIC %md
# MAGIC # Pre-defined Functions
# MAGIC
# MAGIC Let us go through the functions that can be used while processing the data. These are typically applied on columns to get derived values from existing column values.
# MAGIC
# MAGIC * Overview of Functions
# MAGIC * Validating Functions
# MAGIC * String Manipulation Functions
# MAGIC * Date Manipulation Functions
# MAGIC * Overview of Numeric Functions
# MAGIC * Data Type Conversion
# MAGIC * Handling NULL Values
# MAGIC * Using CASE and WHEN
# MAGIC * Query Example - Word Count

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    config("spark.sql.warehouse.dir", "/user/itversity/warehouse").
    enableHiveSupport.
    appName("Spark SQL - Overview of Functions").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Functions
# MAGIC Let us get overview of pre-defined functions in Spark SQL.
# MAGIC
# MAGIC * We can get list of functions by running `SHOW functions`
# MAGIC * We can use DESCRIBE command to get the syntax and symantecs of a function - `DESCRIBE FUNCTION substr`
# MAGIC * Following are the categories of functions that are more commonly used.
# MAGIC   * String Manipulation
# MAGIC   * Date Manipulation
# MAGIC   * Numeric Functions
# MAGIC   * Type Conversion Functions
# MAGIC   * CASE and WHEN
# MAGIC   * and more

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW functions

# COMMAND ----------

spark.sql("SHOW functions").show(300, false)

# COMMAND ----------

spark.catalog.listFunctions.show(300, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FUNCTION substr

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION substr").show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validating Functions
# MAGIC Let us see how we can validate Spark SQL functions.
# MAGIC
# MAGIC * Spark SQL follows MySQL style. To validate functions we can just use SELECT clause - e. g.: `SELECT current_date;`
# MAGIC * Another example - `SELECT substr('Hello World', 1, 5);`
# MAGIC * If you want to use Oracle style, you can create table by name dual and insert one record.
# MAGIC * You can also create temporary view on top of dataframe and start writing SQL Queries. We will see an example with Scala based approach. Here are the code snippets using both Scala as well as Pyspark.
# MAGIC
# MAGIC **Using Scala**
# MAGIC ```
# MAGIC val orders = spark.read.
# MAGIC     schema("order_id INT, order_date STRING, order_customer_id INT, order_status STRING").
# MAGIC     csv("/public/retail_db/orders")
# MAGIC orders.createOrReplaceTempView("orders_temp")
# MAGIC ```
# MAGIC
# MAGIC **Using Python**
# MAGIC ```
# MAGIC orders = spark.read. \
# MAGIC     schema("order_id INT, order_date STRING, order_customer_id INT, order_status STRING"). \
# MAGIC     csv("/public/retail_db/orders")
# MAGIC orders.createOrReplaceTempView("orders_temp")
# MAGIC ```

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_date AS current_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('Hello World', 1, 5) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_database()

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS dual

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE dual (dummy STRING)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO dual VALUES ('X')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_date AS current_date FROM dual

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('Hello World', 1, 5) AS result FROM dual

# COMMAND ----------

# MAGIC %md
# MAGIC * Here is how you can validate functions using Data Frame.
# MAGIC   * Create Data Frame
# MAGIC   * Create temporary view using Data Frame
# MAGIC   * Run queries using view with relevant functions

# COMMAND ----------

val orders = spark.read.
    schema("order_id INT, order_date STRING, order_customer_id INT, order_status STRING").
    csv("/public/retail_db/orders")

# COMMAND ----------

orders.createOrReplaceTempView("orders_temp")

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.*, lower(order_status) AS order_status_lower FROM orders_temp AS o LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation Functions
# MAGIC
# MAGIC We use string manipulation functions quite extensively. Here are some of the important functions which we typically use.
# MAGIC * Case Conversion - `lower`, `upper`, `initcap`
# MAGIC * Getting size of the column value - `length`
# MAGIC * Extracting Data - `substr` and `split`
# MAGIC * Trimming and Padding functions - `trim`, `rtrim`, `ltrim`, `rpad` and `lpad`
# MAGIC * Reversing strings - `reverse`
# MAGIC * Concatenating multiple strings `concat` and `concat_ws`

# COMMAND ----------

# MAGIC %md
# MAGIC ### Case Conversion and Length
# MAGIC Let us understand how to perform case conversion functions of a string and also length of a string.
# MAGIC
# MAGIC * Case Conversion Functions - `lower`, `upper`, `initcap`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT lower('hEllo wOrlD') AS lower_result,
# MAGIC     upper('hEllo wOrlD') AS upper_result,
# MAGIC     initcap('hEllo wOrlD') AS initcap_result

# COMMAND ----------

# MAGIC %md
# MAGIC * Getting length - `length`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT length('hEllo wOrlD') AS result

# COMMAND ----------

# MAGIC %md
# MAGIC Let us see how to use these functions on top of the table. We will use orders table which was loaded as part of last section.
# MAGIC
# MAGIC * order_status for some of the orders is in lower case and we will convert every thing to upper case.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql 
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_id, order_date, order_customer_id,
# MAGIC     lower(order_status) AS order_status,
# MAGIC     length(order_status) AS order_status_length
# MAGIC FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extracting Data - substr and split
# MAGIC Let us understand how to extract data from strings using `substr`/`substring` and `split`.
# MAGIC
# MAGIC * We can get syntax and symantecs of the functions using `DESCRIBE FUNCTION`
# MAGIC * We can extract first four characters from string using substr or substring.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FUNCTION substr

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FUNCTION substring

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION substring").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('2013-07-25 00:00:00.0', 1, 4) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('2013-07-25 00:00:00.0', 6, 2) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('2013-07-25 00:00:00.0', 9, 2) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT substr('2013-07-25 00:00:00.0', 12) AS result

# COMMAND ----------

# MAGIC %md
# MAGIC * Let us see how we can extract date part from order_date of orders.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_id,
# MAGIC   substr(order_date, 1, 10) AS order_date,
# MAGIC   order_customer_id,
# MAGIC   order_status
# MAGIC FROM orders

# COMMAND ----------

# MAGIC %md
# MAGIC Let us understand how to extract the information from the string where there is a delimiter.
# MAGIC * `split` converts delimited string into array.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT split('2013-07-25', '-') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT split('2013-07-25', '-')[1] AS result

# COMMAND ----------

# MAGIC %md
# MAGIC * We can use explode to convert an array into records.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT explode(split('2013-07-25', '-')) AS result

# COMMAND ----------

# MAGIC %md
# MAGIC ### Trimming and Padding Functions
# MAGIC
# MAGIC Let us understand how to trim or remove leading and/or trailing spaces in a string.
# MAGIC
# MAGIC * `ltrim` is used to remove the spaces on the left side of the string.
# MAGIC * `rtrim` is used to remove the spaces on the right side of the string.
# MAGIC * `trim` is used to remove the spaces on both sides of the string.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT ltrim('     Hello World') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT rtrim('     Hello World       ') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT length(trim('     Hello World       ')) AS result

# COMMAND ----------

# MAGIC %md
# MAGIC Let us understand how to use padding to pad characters to a string.
# MAGIC
# MAGIC * Let us assume that there are 3 fields - year, month and date which are of type integer.
# MAGIC * If we have to concatenate all the 3 fields and create a date, we might have to pad month and date with 0.
# MAGIC * `lpad` is used more often than `rpad` especially when we try to build the date from separate columns.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT 2013 AS year, 7 AS month, 25 AS myDate

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT lpad(7, 2, 0) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT lpad(10, 2, 0) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT lpad(100, 2, 0) AS result

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reverse and Concatenating multiple strings
# MAGIC
# MAGIC Let us understand how to reverse a string as well as concatenate multiple strings.
# MAGIC * We can use `reverse` to reverse a string.
# MAGIC * We can concatenate multiple strings using `concat` and `concat_ws`.
# MAGIC * `concat_ws` is typically used if we want to have the same string between all the strings that are being concatenated.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT reverse('Hello World') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT concat('Hello ', 'World') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT concat('Order Status is ', order_status) AS result
# MAGIC FROM orders LIMIT 10

# COMMAND ----------

spark.sql("""
    SELECT concat('Order Status is ', order_status) AS result
    FROM orders_part LIMIT 10
""").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM (SELECT 2013 AS year, 7 AS month, 25 AS myDate) q

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT concat(year, '-', lpad(month, 2, 0), '-',
# MAGIC               lpad(myDate, 2, 0)) AS order_date
# MAGIC FROM
# MAGIC     (SELECT 2013 AS year, 7 AS month, 25 AS myDate) q

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT concat_ws('-', year, lpad(month, 2, 0),
# MAGIC               lpad(myDate, 2, 0)) AS order_date
# MAGIC FROM
# MAGIC     (SELECT 2013 AS year, 7 AS month, 25 AS myDate) q

# COMMAND ----------

# MAGIC %md
# MAGIC ## Date Manipulation Functions
# MAGIC
# MAGIC Let us go through some of the important date manipulation functions.
# MAGIC * Getting Current Date and Timestamp
# MAGIC * Date Arithmetic such as `date_add`
# MAGIC * Getting beginning date or time using `trunc` or `date_trunc`
# MAGIC * Extracting information using `date_format` as well as calendar functions.
# MAGIC * Dealing with unix timestamp using `from_unixtime`, `to_unix_timestamp`

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting Current Date and Timestamp
# MAGIC
# MAGIC Let us understand how to get the details about current or today's date as well as current timestamp.
# MAGIC
# MAGIC * `current_date` is the function or operator which will return today's date.
# MAGIC * `current_timestamp` is the function or operator which will return current time up to milliseconds.
# MAGIC * These are not like other functions and do not use **()** at the end.
# MAGIC * These are not listed as part of `SHOW functions` and we can get help using `DESCRIBE`.
# MAGIC * There is a format associated with date and timestamp.
# MAGIC   * Date - `yyyy-MM-dd`
# MAGIC   * Timestamp - `yyyy-MM-dd HH:mm:ss.SSS`
# MAGIC * Keep in mind that a date or timestamp in Spark SQL are nothing but special strings containing values using above specified formats. We can apply all string manipulation functions on date or timestamp.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_date AS current_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_date() AS current_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp

# COMMAND ----------

spark.sql("SELECT current_timestamp AS current_timestamp").show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Date Arithmetic
# MAGIC Let us understand how to perform arithmetic on dates or timestamps.
# MAGIC
# MAGIC * `date_add` can be used to add or subtract days.
# MAGIC * `date_sub` can be used to subtract or add days.
# MAGIC * `datediff` can be used to get difference between 2 dates
# MAGIC * `add_months` can be used add months to a date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_add(current_date, 32) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_add('2018-04-15', 730) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_add('2018-04-15', -730) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_sub(current_date, 30) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT datediff('2019-03-30', '2017-12-31') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT datediff('2017-12-31', '2019-03-30') AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT add_months(current_date, 3) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT add_months('2019-01-31', 1) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT add_months('2019-05-31', 1) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT add_months(current_timestamp, 3) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_add(current_timestamp, -730) AS result

# COMMAND ----------

# MAGIC %md
# MAGIC ### Beginning Date or Time - trunc and date_trunc
# MAGIC Let us understand how to use `trunc` and `date_trunc` on dates or timestamps and get beginning date of the period.
# MAGIC
# MAGIC * We can use **MM** to get beginning date of the month.
# MAGIC * **YY** can be used to get begining date of the year.
# MAGIC * We can apply trunc either on date or timestamp, however we cannot apply it other than month or year (such an hour or day).

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DESCRIBE FUNCTION trunc

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION trunc").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT trunc(current_date, 'MM') AS beginning_date_month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT trunc('2019-01-23', 'MM') AS beginning_date_month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT trunc(current_date, 'YY') AS beginning_date_year 

# COMMAND ----------

# MAGIC %md
# MAGIC * This will not work

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT trunc(current_timestamp, 'HH') AS doesnt_work

# COMMAND ----------

# MAGIC %md
# MAGIC * While `trunc` can be used to get beginning time of a given month or year, we can get the beginning time up to Second using `date_trunc`.

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION date_trunc").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_trunc('HOUR', current_timestamp) AS hour_beginning

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extracting information using date_format
# MAGIC
# MAGIC Let us understand how to use `date_format` to extract information from date or timestamp.
# MAGIC
# MAGIC Here is how we can get date related information such as year, month, day etc from date or timestamp.

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION date_format").show(false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'yyyy') AS year

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'yy') AS year

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'MM') AS month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'dd') AS day_of_month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'DD') AS day_of_year

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'MMM') AS month_name

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'MMMM') AS month_name

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'EE') AS dayname

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'EEEE') AS dayname

# COMMAND ----------

# MAGIC %md
# MAGIC * Here is how we can get time related information such as hour, minute, seconds, milliseconds etc from timestamp.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'HH') AS hour24

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'hh') AS hour12

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'mm') AS minutes

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'ss') AS seconds

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_timestamp AS current_timestamp, 
# MAGIC     date_format(current_timestamp, 'SS') AS millis

# COMMAND ----------

# MAGIC %md
# MAGIC * Here is how we can get the information from date or timestamp in the format we require.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_format(current_timestamp, 'yyyyMM') AS current_month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_format(current_timestamp, 'yyyyMMdd') AS current_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT date_format(current_timestamp, 'yyyy/MM/dd') AS current_date

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extracting information - Calendar functions
# MAGIC
# MAGIC We can get year, month, day etc from date or timestamp using functions. There are functions such as `day`, `dayofmonth`, `month`, `weekofyear`, `year` etc available for us.

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION day").show(false)

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION dayofmonth").show(false)

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION month").show(false)

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION weekofyear").show(false)

# COMMAND ----------

spark.sql("DESCRIBE FUNCTION year").show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC * Let us see the usage of the functions such as day, dayofmonth, month, weekofyear, year etc.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT year(current_date) AS year

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT month(current_date) AS month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT weekofyear(current_date) AS weekofyear

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT day(current_date) AS day

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT dayofmonth(current_date) AS dayofmonth

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dealing with Unix Timestamp
# MAGIC
# MAGIC Let us go through the functions that can be used to deal with Unix Timestamp.
# MAGIC
# MAGIC * `from_unixtime` can be used to convert Unix epoch to regular timestamp.
# MAGIC * `unix_timestamp` or `to_unix_timestamp` can be used to convert timestamp to Unix epoch.
# MAGIC * We can get Unix epoch or Unix timestamp by running `date '+%s'` in Unix/Linux terminal
# MAGIC * We can DESCRIBE on the above functions to get details about them.
# MAGIC
# MAGIC Let us sww how we can use functions such as `from_unixtime`, `unix_timestamp` or `to_unix_timestamp` to convert between timestamp and Unix timestamp or epoch.
# MAGIC
# MAGIC * We can unix epoch in Unix/Linux terminal using `date '+%s'`

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT from_unixtime(1556662731) AS timestamp

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT to_unix_timestamp('2019-04-30 18:18:51') AS unixtime

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT from_unixtime(1556662731, 'yyyyMM') AS month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT from_unixtime(1556662731, 'yyyy-MM-dd') AS date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT from_unixtime(1556662731, 'yyyy-MM-dd HH:mm') AS timestamp

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT from_unixtime(1556662731, 'yyyy-MM-dd hh:mm') AS timestamp

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT to_unix_timestamp('20190430 18:18:51', 'yyyyMMdd') AS date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT to_unix_timestamp('20190430 18:18:51', 'yyyyMMdd HH:mm:ss') AS timestamp

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Numeric Functions
# MAGIC
# MAGIC Here are some of the numeric functions we might use quite often.
# MAGIC
# MAGIC * `abs` - always return positive number
# MAGIC * `sum`, `avg`
# MAGIC * `round` - rounds off to specified precision
# MAGIC * `ceil`, `floor` - always return integer.
# MAGIC * `greatest`
# MAGIC * `min`, `max`
# MAGIC * `rand`
# MAGIC * `pow`, `sqrt`
# MAGIC * `cumedist`, `stddev`, `variance`
# MAGIC
# MAGIC Some of the functions highlighted are aggregate functions, eg: `sum`, `avg`, `min`, `max` etc.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT abs(-10.5), abs(10)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, order_item_subtotal FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT avg(order_item_subtotal) AS order_revenue_avg FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, 
# MAGIC     avg(order_item_subtotal) AS order_revenue_avg 
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, 
# MAGIC     sum(order_item_subtotal) AS order_revenue_sum
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT
# MAGIC     round(10.58) rnd,
# MAGIC     floor(10.58) flr,
# MAGIC     ceil(10.58) cl

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT
# MAGIC     round(10.44) rnd1,
# MAGIC     round(10.44, 1) rnd1,
# MAGIC     round(10.46, 1) rnd2,
# MAGIC     floor(10.44) flr,
# MAGIC     ceil(10.44) cl

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT avg(order_item_subtotal) AS order_revenue_avg FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT round(avg(order_item_subtotal), 2) AS order_revenue_avg 
# MAGIC FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, 
# MAGIC     round(avg(order_item_subtotal), 2) AS order_revenue_avg 
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, 
# MAGIC     round(sum(order_item_subtotal), 2) AS order_revenue_sum
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT greatest(10, 11, 13, -13)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT rand() AS rand

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast(round(rand() * 1) AS int) AS random_int

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, 
# MAGIC     round(sum(order_item_subtotal), 2) AS order_revenue_sum,
# MAGIC     min(order_item_subtotal) AS order_item_subtotal_min,
# MAGIC     max(order_item_subtotal) AS order_item_subtotal_max 
# MAGIC FROM order_items
# MAGIC GROUP BY order_item_order_id
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT order_item_order_id, order_item_subtotal
# MAGIC FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT round(sum(order_item_subtotal), 2) AS order_revenue_sum,
# MAGIC     min(order_item_subtotal) AS order_item_subtotal_min,
# MAGIC     max(order_item_subtotal) AS order_item_subtotal_max 
# MAGIC FROM order_items
# MAGIC WHERE order_item_order_id = 2

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Type Conversion
# MAGIC
# MAGIC Let us understand how we can type cast to change the data type of extracted value to its original type.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT current_date AS current_date

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT split(current_date, '-')[1] AS month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast(split(current_date, '-')[1] AS INT) AS month

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast('0.04' AS FLOAT) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast('0.04' AS INT) AS zero

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast('xyz' AS INT) AS returns_null

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE EXTERNAL TABLE IF NOT EXISTS orders_single_column (
# MAGIC     s STRING
# MAGIC ) LOCATION '/user/itversity/warehouse/itversity_retail.db/orders'

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM orders_single_column LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT split(s, ',')[0] AS order_id,
# MAGIC     split(s, ',')[1] AS order_date,
# MAGIC     split(s, ',')[2] AS order_customer_id,
# MAGIC     split(s, ',')[3] AS order_status
# MAGIC FROM orders_single_column LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT cast(split(s, ',')[0] AS INT) AS order_id,
# MAGIC     cast(split(s, ',')[1] AS TIMESTAMP) AS order_date,
# MAGIC     cast(split(s, ',')[2] AS INT) AS order_customer_id,
# MAGIC     cast(split(s, ',')[3] AS STRING) AS order_status
# MAGIC FROM orders_single_column LIMIT 10

# COMMAND ----------

# MAGIC %md
# MAGIC ## Handling NULL Values
# MAGIC
# MAGIC Let us understand how to handle nulls using specific functions in Spark SQL.
# MAGIC * By default if we try to add or concatenate null to another column or expression or literal, it will return null.
# MAGIC * If we want to replace null with some default value, we can use `nvl`. For not null values, nvl returns the original expression value.
# MAGIC   * Replace commission_pct with 0 if it is null.
# MAGIC   * We can also use `coalesce` in the place of `nvl`.
# MAGIC * `coalesce` returns first not null value if we pass multiple arguments to it.
# MAGIC * `nvl2` can be used to perform one action when the value is not null and some other action when the value is null.
# MAGIC   * We want to increase commission_pct by 1 if it is not null and set commission_pct to 2 if it is null.
# MAGIC * We can also use `CASE WHEN ELSE END` for any conditional logic.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT 1 + NULL AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT concat('Hello', NULL) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT nvl(1, 0) nvl, coalesce(1, 0) AS coalesce

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT nvl(NULL, 0) nvl , coalesce(1, 0) AS coalesce

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT coalesce(NULL, NULL, 2, NULL, 3) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT nvl(NULL, NULL, 2, NULL, 3) AS result

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP TABLE IF EXISTS sales

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE IF NOT EXISTS sales(
# MAGIC     sales_person_id INT,
# MAGIC     sales_amount FLOAT,
# MAGIC     commission_pct INT
# MAGIC )

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO sales VALUES
# MAGIC     (1, 1000, 10),
# MAGIC     (2, 1500, 8),
# MAGIC     (3, 500, NULL),
# MAGIC     (4, 800, 5),
# MAGIC     (5, 250, NULL)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM sales

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     nvl(commission_pct, 0) AS commission_pct
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     coalesce(commission_pct, 0) AS commission_pct
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     round(sales_amount * commission_pct / 100, 2) AS incorrect_commission_amount
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     round(sales_amount * nvl(commission_pct, 0) / 100, 2) AS commission_amount
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     round(sales_amount * coalesce(commission_pct, 0) / 100, 2) AS commission_amount
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     nvl2(commission_pct, commission_pct + 1, 2) AS commission_pct
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     round(sales_amount * nvl2(commission_pct, commission_pct + 1, 2) / 100, 2) AS commission_amount
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     CASE WHEN commission_pct IS NULL 
# MAGIC         THEN 2
# MAGIC         ELSE commission_pct + 1
# MAGIC     END AS commission_pct
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     CASE WHEN commission_pct IS NOT NULL 
# MAGIC         THEN commission_pct + 1
# MAGIC         ELSE 2
# MAGIC     END AS commission_pct
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT s.*, 
# MAGIC     CASE WHEN commission_pct IS NULL 
# MAGIC         THEN round((sales_amount * 2 / 100), 2)
# MAGIC         ELSE round((sales_amount * (commission_pct + 1)/ 100), 2)
# MAGIC     END AS commission_amount
# MAGIC FROM sales AS s

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using CASE and WHEN
# MAGIC At times we might have to select values from multiple columns conditionally.
# MAGIC * We can use `CASE` and `WHEN` for that.
# MAGIC * Let us implement this conditional logic to come up with derived order_status.
# MAGIC   * If order_status is COMPLETE or CLOSED, set COMPLETED
# MAGIC   * If order_status have PENDING in it, then we will say PENDING
# MAGIC   * If order_status have PROCESSING or PAYMENT_REVIEW in it, then we will say PENDING
# MAGIC   * We will set all others as OTHER
# MAGIC * We can also have `ELSE` as part of `CASE` and `WHEN`.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_retail

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SHOW tables

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT DISTINCT order_status FROM orders LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.*,
# MAGIC     CASE WHEN order_status IN ('COMPLETE', 'CLOSED') THEN 'COMPLETED'
# MAGIC     END AS updated_order_status
# MAGIC FROM orders o
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.*,
# MAGIC     CASE WHEN order_status IN ('COMPLETE', 'CLOSED') THEN 'COMPLETED'
# MAGIC     ELSE order_status
# MAGIC     END AS updated_order_status
# MAGIC FROM orders o
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.*,
# MAGIC     CASE 
# MAGIC         WHEN order_status IN ('COMPLETE', 'CLOSED') THEN 'COMPLETED'
# MAGIC         WHEN order_status LIKE '%PENDING%' THEN 'PENDING'
# MAGIC         ELSE 'OTHER'
# MAGIC     END AS updated_order_status
# MAGIC FROM orders o
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT o.*,
# MAGIC     CASE 
# MAGIC         WHEN order_status IN ('COMPLETE', 'CLOSED') THEN 'COMPLETED'
# MAGIC         WHEN order_status LIKE '%PENDING%' OR order_status IN ('PROCESSING', 'PAYMENT_REVIEW')
# MAGIC             THEN 'PENDING'
# MAGIC         ELSE 'OTHER'
# MAGIC     END AS updated_order_status
# MAGIC FROM orders o
# MAGIC LIMIT 10

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT DISTINCT order_status,
# MAGIC     CASE 
# MAGIC         WHEN order_status IN ('COMPLETE', 'CLOSED') THEN 'COMPLETED'
# MAGIC         WHEN order_status LIKE '%PENDING%' OR order_status IN ('PROCESSING', 'PAYMENT_REVIEW')
# MAGIC             THEN 'PENDING'
# MAGIC         ELSE 'OTHER'
# MAGIC     END AS updated_order_status
# MAGIC FROM orders
# MAGIC ORDER BY updated_order_status

# COMMAND ----------

# MAGIC %md
# MAGIC ## Query Example - Word Count
# MAGIC
# MAGIC Let us see how we can perform word count using Spark SQL. Using word count as an example we will understand how we can come up with the solution using pre-defined functions available.
# MAGIC
# MAGIC * Create table by name lines.
# MAGIC * Insert data into the table.
# MAGIC * Split lines into array of words.
# MAGIC * Explode array of words from each line into individual records.
# MAGIC * Use group by and get the count. We cannot use `GROUP BY` directly on exploded records and hence we need to use nested sub query.

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC DROP DATABASE IF EXISTS itversity_demo CASCADE

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE DATABASE IF NOT EXISTS itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC USE itversity_demo

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC CREATE TABLE lines (s STRING)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC INSERT INTO lines VALUES
# MAGIC   ('Hello World'),
# MAGIC   ('How are you'),
# MAGIC   ('Let us perform the word count'),
# MAGIC   ('The definition of word count is'),
# MAGIC   ('to get the count of each word from this data')

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT * FROM lines

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT split(s, ' ') AS word_array FROM lines

# COMMAND ----------

spark.sql("SHOW functions").show(300, false)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT explode(split(s, ' ')) AS words FROM lines

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM (SELECT explode(split(s, ' ')) AS words FROM lines)

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT explode(split(s, ' ')) AS words, count(1) FROM lines
# MAGIC GROUP BY explode(split(s, ' '))

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT word, count(1) FROM (
# MAGIC   SELECT explode(split(s, ' ')) AS word FROM lines
# MAGIC ) q
# MAGIC GROUP BY word

# COMMAND ----------

# MAGIC %%sql
# MAGIC
# MAGIC SELECT count(1) FROM
# MAGIC (
# MAGIC     SELECT word, count(1) FROM (
# MAGIC         SELECT explode(split(s, ' ')) AS word FROM lines
# MAGIC     ) q
# MAGIC     GROUP BY word
# MAGIC )

# COMMAND ----------

