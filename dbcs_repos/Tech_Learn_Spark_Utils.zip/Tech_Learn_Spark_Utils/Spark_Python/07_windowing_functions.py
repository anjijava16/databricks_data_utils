# Databricks notebook source
# MAGIC %md
# MAGIC # Windowing Functions
# MAGIC
# MAGIC As part of this module let us get into Windowing Functions.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession. \
    builder. \
    config('spark.ui.port', '0'). \
    appName('Windowing Functions'). \
    master('yarn'). \
    getOrCreate()

# COMMAND ----------

spark.conf.set('spark.sql.shuffle.partitions', '2')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Windowing Functions
# MAGIC
# MAGIC Let us get an overview of Windowing Functions.
# MAGIC
# MAGIC  * First let us understand relevance of these functions using `employees` data set.

# COMMAND ----------

employeesPath = '/public/hr_db/employees'

# COMMAND ----------

employees = spark. \
    read. \
    format('csv'). \
    option('sep', '\t'). \
    schema('''employee_id INT, 
              first_name STRING, 
              last_name STRING, 
              email STRING,
              phone_number STRING, 
              hire_date STRING, 
              job_id STRING, 
              salary FLOAT,
              commission_pct STRING,
              manager_id STRING, 
              department_id STRING
            '''). \
    load(employeesPath)

# COMMAND ----------

from pyspark.sql.functions import col
employees. \
    select('employee_id', 
           col('department_id').cast('int').alias('department_id'), 
           'salary'
          ). \
    orderBy('department_id', 'salary'). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Let us say we want to compare individual salary with department wise salary expense.
# MAGIC * Here is one of the approach which require self join.
# MAGIC   * Compute department wise expense usig `groupBy` and `agg`.
# MAGIC   * Join with **employees** again on department_id.

# COMMAND ----------

from pyspark.sql.functions import sum, col

# COMMAND ----------

department_expense = employees. \
    groupBy('department_id'). \
    agg(sum('salary').alias('expense'))

# COMMAND ----------

department_expense.show()

# COMMAND ----------

employees. \
    select('employee_id', 'department_id', 'salary'). \
    join(department_expense, employees.department_id == department_expense.department_id). \
    orderBy(employees.department_id, col('salary')). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC  **However, using this approach is not very efficient and also overly complicated. Windowing functions actually simplify the logic and also runs efficiently**
# MAGIC  
# MAGIC Now let us get into the details related to Windowing functions.
# MAGIC  * Main package `pyspark.sql.window`
# MAGIC  * It has classes such as `Window` and `WindowSpec`
# MAGIC  * `Window` have APIs such as `partitionBy`, `orderBy` etc
# MAGIC  * These APIs (such as `partitionBy`) return `WindowSpec` object. We can pass `WindowSpec` object to over on functions such as `rank()`, `dense_rank()`, `sum()` etc
# MAGIC  * Syntax: `sum().over(spec)` where `spec = Window.partitionBy('ColumnName')`

# COMMAND ----------

# MAGIC %md
# MAGIC | Functions        | API or Function      |
# MAGIC | ------------- |:-------------:|
# MAGIC | Aggregate Functions      | <ul><li>sum</li><li>avg</li><li>min</li><li>max</li></ul> |
# MAGIC | Ranking Functions      | <ul><li>rank</li><li>dense_rank</li></ul><ul><li>percent_rank</li><li>row_number</li> <li>ntile</li></ul> |
# MAGIC | Analytic Functions      | <ul><li>cume_dist</li><li>first</li><li>last</li><li>lead</li> <li>lag</li></ul> |

# COMMAND ----------

# MAGIC %md
# MAGIC ## Aggregate Functions
# MAGIC
# MAGIC Let us see how to perform aggregations within each group while projecting the raw data that is used to perform the aggregation.
# MAGIC
# MAGIC  * We have functions such as `sum`, `avg`, `min`, `max` etc which can be used to aggregate the data.
# MAGIC  * We need to create `WindowSpec` object using `partitionBy` to get aggregations within each group.
# MAGIC  * Typically we don’t need to sort the data to perform aggregations, however if we want to perform cumulative aggregations using rowsBetween, then we have to sort the data using cumulative criteria.
# MAGIC  * Let us try to get total departure delay, minimum departure delay, maximum departure delay and average departure delay for each day for each airport. We will ignore all those flights which are departured early or ontime.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
  read. \
  parquet(airlines_path)

# COMMAND ----------

from pyspark.sql.functions import col, lit, lpad, concat

# COMMAND ----------

from pyspark.sql.functions import min, max, sum, avg

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

airlines.printSchema()

# COMMAND ----------

spec = Window. \
    partitionBy("FlightDate", "Origin")

# COMMAND ----------

airlines. \
    filter("IsDepDelayed = 'YES' and Cancelled = 0"). \
    select(concat("Year", 
                  lpad("Month", 2, "0"), 
                  lpad("DayOfMonth", 2, "0")
                 ).alias("FlightDate"),
           "Origin",
           "UniqueCarrier",
           "FlightNum",
           "CRSDepTime",
           "IsDepDelayed",
           col("DepDelay").cast("int").alias("DepDelay")
          ). \
    withColumn("DepDelayMin", min("DepDelay").over(spec)). \
    withColumn("DepDelayMax", max("DepDelay").over(spec)). \
    withColumn("DepDelaySum", sum("DepDelay").over(spec)). \
    withColumn("DepDelayAvg", avg("DepDelay").over(spec)). \
    orderBy("FlightDate", "Origin", "DepDelay"). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using rowsBetween and rangeBetween
# MAGIC
# MAGIC We can get cumulative aggregations using `rowsBetween` or `rangeBetween`.
# MAGIC
# MAGIC * We can use `rowsBetween` to include particular set of rows to perform aggregations.
# MAGIC * We can use `rangeBetween` to include particular range of values on a given column.

# COMMAND ----------

spec = Window. \
    partitionBy("FlightDate", "Origin"). \
    orderBy("CRSDepTime"). \
    rowsBetween(Window.unboundedPreceding, 0)

# COMMAND ----------

airlines. \
    filter("IsDepDelayed = 'YES' and Cancelled = 0"). \
    select(concat("Year", 
                  lpad("Month", 2, "0"), 
                  lpad("DayOfMonth", 2, "0")
                 ).alias("FlightDate"),
           "Origin",
           "UniqueCarrier",
           "FlightNum",
           "CRSDepTime",
           "IsDepDelayed",
           col("DepDelay").cast("int").alias("DepDelay")
          ). \
    withColumn("DepDelaySum", sum("DepDelay").over(spec)). \
    orderBy("FlightDate", "Origin", "CRSDepTime"). \
    show()

# COMMAND ----------

spec = Window. \
    partitionBy("FlightDate", "Origin"). \
    orderBy("CRSDepTime"). \
    rowsBetween(-3, 0)

# COMMAND ----------

airlines. \
    filter("IsDepDelayed = 'YES' and Cancelled = 0"). \
    select(concat("Year", 
                  lpad("Month", 2, "0"), 
                  lpad("DayOfMonth", 2, "0")
                 ).alias("FlightDate"),
           "Origin",
           "UniqueCarrier",
           "FlightNum",
           "CRSDepTime",
           "IsDepDelayed",
           col("DepDelay").cast("int").alias("DepDelay")
          ). \
    withColumn("DepDelaySum", sum("DepDelay").over(spec)). \
    orderBy("FlightDate", "Origin", "CRSDepTime"). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Ranking Functions
# MAGIC
# MAGIC We can use ranking functions to assign ranks to a particular record within a partition.
# MAGIC
# MAGIC * Sparse Rank - rank
# MAGIC * Dense Rank - dense_rank
# MAGIC * Assigning Row Numbers - row_number
# MAGIC * Percentage Rank - percent_rank

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks related to ranking.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

from pyspark.sql.functions import col, lit, lpad, concat
from pyspark.sql.functions import rank, dense_rank
from pyspark.sql.functions import percent_rank, row_number, round
from pyspark.sql.window import Window

# COMMAND ----------

spec = Window. \
    partitionBy("FlightDate", "Origin"). \
    orderBy(col("DepDelay").desc())

# COMMAND ----------

airlines. \
    filter("IsDepDelayed = 'YES' and Cancelled = 0"). \
    select(concat("Year", 
                  lpad("Month", 2, "0"), 
                  lpad("DayOfMonth", 2, "0")
                 ).alias("FlightDate"),
           "Origin",
           "UniqueCarrier",
           "FlightNum",
           "CRSDepTime",
           "IsDepDelayed",
           col("DepDelay").cast("int").alias("DepDelay")
          ). \
    withColumn("srank", rank().over(spec)). \
    withColumn("drank", dense_rank().over(spec)). \
    withColumn("prank", round(percent_rank().over(spec), 2)). \
    withColumn("rn", row_number().over(spec)). \
    orderBy("FlightDate", "Origin", col("DepDelay").desc()). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Analytic Functions
# MAGIC
# MAGIC We can use Analytic Functions to compare current record with previous record or next record.
# MAGIC * `lead` and `lag` are the main functions.
# MAGIC * We can also compare each of the day of one week with corresponding day of another week.
# MAGIC * `lead` and `lag` serve the same purpose. Depending up on the requirement and sorting of the data we can use either of them.
# MAGIC * Here the examples are demonstrated using `lead`. Same can be achieved using `lag` however while defining the spec we have sort the data with in window in descending order to get similar results.
# MAGIC * Also we can use `first` and `last` functions to get first or last value with in each group or partition based up on sorting criteria. They are typically used to get the details about other fields (for example, we can get employee name or id who is making highest or lowest salary with in a department).

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using LEAD

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
  read. \
  parquet(airlines_path)

# COMMAND ----------

from pyspark.sql.functions import col, lit, lpad, concat

# COMMAND ----------

from pyspark.sql.functions import lead

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

spec = Window. \
    partitionBy("FlightDate", "Origin"). \
    orderBy(col("CRSDepTime"))

# COMMAND ----------

airlines. \
    filter("IsDepDelayed = 'YES' and Cancelled = 0"). \
    select(concat("Year", 
                  lpad("Month", 2, "0"), 
                  lpad("DayOfMonth", 2, "0")
                 ).alias("FlightDate"),
           "Origin",
           "UniqueCarrier",
           "FlightNum",
           "CRSDepTime",
           "IsDepDelayed",
           col("DepDelay").cast("int").alias("DepDelay")
          ). \
    withColumn("LeadUniqueCarrier", lead("UniqueCarrier").over(spec)). \
    withColumn("LeadFlightNum", lead("FlightNum").over(spec)). \
    withColumn("LeadCRSDepTime", lead("CRSDepTime").over(spec)). \
    withColumn("LeadDepDelay", lead("DepDelay").over(spec)). \
    orderBy("FlightDate", "Origin", "CRSDepTime"). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Using LEAD with 7

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

from pyspark.sql.functions import col, lit, lpad, concat

# COMMAND ----------

from pyspark.sql.functions import sum, lead, substring

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

spec = Window. \
    partitionBy(substring("FlightDate", 1, 6), "Origin"). \
    orderBy("FlightDate", col("TotalDepDelay").desc())

# COMMAND ----------

airlines. \
    filter("""IsDepDelayed = 'YES' 
              AND Cancelled = 0
              AND concat(Year, 
                         lpad(Month, 2, '0'),
                         lpad(DayOfMonth, 2, '0')
                        ) BETWEEN 20080101 AND 20080114
              AND Origin IN ('ATL', 'DFW', 'JFK', 'LAX', 'SFO', 'ORD')
           """
          ). \
    groupBy(concat("Year", 
                   lpad("Month", 2, "0"), 
                   lpad("DayOfMonth", 2, "0")
                  ).alias("FlightDate"), 
            "Origin"
           ). \
    agg(sum(col("DepDelay").cast("int")).alias("TotalDepDelay")). \
    withColumn("LeadFlightDate", lead("FlightDate", 7).over(spec)). \
    withColumn("LeadOrigin", lead("Origin", 7).over(spec)). \
    withColumn("LeadTotalDepDelay", lead("TotalDepDelay", 7).over(spec)). \
    filter('Origin = "ORD"'). \
    orderBy("FlightDate", col("TotalDepDelay").desc()). \
    show()

# COMMAND ----------

airlines. \
    filter("""IsDepDelayed = 'YES' 
              AND Cancelled = 0
              AND concat(Year, 
                         lpad(Month, 2, '0'),
                         lpad(DayOfMonth, 2, '0')
                        ) BETWEEN 20080101 AND 20080114
              AND Origin IN ('ATL', 'DFW', 'JFK', 'LAX', 'SFO', 'ORD')
           """
          ). \
    groupBy(concat("Year", 
                   lpad("Month", 2, "0"), 
                   lpad("DayOfMonth", 2, "0")
                  ).alias("FlightDate"), 
            "Origin"
           ). \
    agg(sum(col("DepDelay").cast("int")).alias("TotalDepDelay")). \
    withColumn("LeadFlightDate", lead("FlightDate", 7).over(spec)). \
    withColumn("LeadOrigin", lead("Origin", 7).over(spec)). \
    withColumn("LeadTotalDepDelay", lead("TotalDepDelay", 7).over(spec)). \
    filter('Origin = "ORD" AND FlightDate BETWEEN 20080101 AND 20080107'). \
    orderBy("FlightDate", col("TotalDepDelay").desc()). \
    show()

# COMMAND ----------

airlines. \
    filter("""IsDepDelayed = 'YES' 
              AND Cancelled = 0
              AND concat(Year, 
                         lpad(Month, 2, '0'),
                         lpad(DayOfMonth, 2, '0')
                        ) BETWEEN 20080101 AND 20080114
              AND Origin IN ('ATL', 'DFW', 'JFK', 'LAX', 'SFO', 'ORD')
           """
          ). \
    groupBy(concat("Year", 
                   lpad("Month", 2, "0"), 
                   lpad("DayOfMonth", 2, "0")
                  ).alias("FlightDate"), 
            "Origin"
           ). \
    agg(sum(col("DepDelay").cast("int")).alias("TotalDepDelay")). \
    withColumn("LeadFlightDate", lead("FlightDate", 7).over(spec)). \
    withColumn("LeadOrigin", lead("Origin", 7).over(spec)). \
    withColumn("LeadTotalDepDelay", lead("TotalDepDelay", 7).over(spec)). \
    filter('FlightDate BETWEEN 20080101 AND 20080107'). \
    orderBy("FlightDate", col("TotalDepDelay").desc()). \
    show()

# COMMAND ----------

