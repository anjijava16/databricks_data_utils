# Databricks notebook source
# MAGIC %md
# MAGIC # Joining Data Sets
# MAGIC
# MAGIC Let us understand how to join multiple Data Sets using Spark based APIs.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Datasets for Joins
# MAGIC Let us prepare Dataset to join and get the details related to airports (origin and destination).
# MAGIC
# MAGIC * Make sure airport-codes is in HDFS.

# COMMAND ----------

# MAGIC %%sh
# MAGIC hdfs dfs -ls /public/airlines_all/airport-codes

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession. \
    builder. \
    config('spark.ui.port', '0'). \
    appName('Joining Data Sets'). \
    master('yarn'). \
    getOrCreate()

# COMMAND ----------

spark.conf.set('spark.sql.shuffle.partitions', '2')

# COMMAND ----------

# MAGIC %md
# MAGIC * Analyze the Dataset to confirm if there is header and also how the data is structured.

# COMMAND ----------

spark.read. \
    text("/public/airlines_all/airport-codes"). \
    show(truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC  * Data is tab separated.
# MAGIC  * There is header for the data set.
# MAGIC  * Dataset have 4 fields - **Country, State, City, IATA**
# MAGIC     
# MAGIC     
# MAGIC Create DataFrame airport_codes applying appropriate Schema.
# MAGIC

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       )

# COMMAND ----------

# MAGIC %md
# MAGIC * Preview and Understand the data.

# COMMAND ----------

airport_codes.show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Get schema of **airport_codes**.

# COMMAND ----------

airport_codes.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC * Preview the data
# MAGIC  * Get the count of records

# COMMAND ----------

airport_codes.count()

# COMMAND ----------

# MAGIC %md
# MAGIC    * Get the count of unique records and see if it is the same as total count.

# COMMAND ----------

airport_codes. \
    select("IATA"). \
    distinct(). \
    count()

# COMMAND ----------

# MAGIC %md
# MAGIC  * If they are not equal, analyze the data and identify IATA codes which are repeated more than once.

# COMMAND ----------

from pyspark.sql.functions import lit, count

# COMMAND ----------

duplicate_iata_count = airport_codes. \
    groupBy("IATA"). \
    agg(count(lit(1)).alias("iata_count")). \
    filter("iata_count > 1")

# COMMAND ----------

duplicate_iata_count.show()

# COMMAND ----------

# MAGIC %md
# MAGIC  * Filter out the duplicates using the most appropriate one and discard others.

# COMMAND ----------

airport_codes. \
    filter("IATA = 'Big'"). \
    show()

# COMMAND ----------

airport_codes. \
    filter("!(State = 'Hawaii' AND IATA = 'Big')"). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC  * Get number of airports (IATA Codes) for each state in the US. Sort the data in descending order by count.

# COMMAND ----------

from pyspark.sql.functions import col, lit, count

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country='USA'")

# COMMAND ----------

airport_count_per_state = airport_codes. \
    groupBy("Country", "State"). \
    agg(count(lit(1)).alias("IATACount")). \
    orderBy(col("IATACount").desc())

# COMMAND ----------

airport_count_per_state.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Joining Data Frames
# MAGIC
# MAGIC Let us understand how to join Data Frames by using some problem statements. Use 2008 January data.
# MAGIC * Get number of flights departed from each of the US airport.
# MAGIC * Get number of flights departed from each of the state.
# MAGIC * Get the list of airports in the US from which flights are not departed.
# MAGIC * Check if there are any origins in airlines data which do not have record in airport-codes.
# MAGIC * Get the total number of flights from the airports that do not contain entries in airport-codes.
# MAGIC * Get the total number of flights per airport that do not contain entries in airport-codes.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Joins
# MAGIC
# MAGIC Let us get an overview of joining Data Frames.
# MAGIC * Our data cannot be stored in one table. It will be stored in multiple tables and the tables might be related.
# MAGIC   * When it comes to transactional systems, we typically define tables based on Normalization Principles.
# MAGIC   * When it comes to data warehousing applications, we typically define tables using Dimensional Modeling.
# MAGIC   * Either of the approach data is scattered into multiple tables and relationships are defined.
# MAGIC   * Typically tables are related with one to one, one to many, many to many relationships.
# MAGIC * When we have 2 Data Sets that are related based on a common key we typically perform join.
# MAGIC * There are different types of joins.
# MAGIC   * INNER JOIN
# MAGIC   * OUTER JOIN (LEFT or RIGHT)
# MAGIC   * FULL OUTER JOIN (a LEFT OUTER JOIN b UNION a RIGHT OUTER JOIN b)
# MAGIC  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 1
# MAGIC
# MAGIC Get number of flights departed from each of the US airport.

# COMMAND ----------

from pyspark.sql.functions import col, lit, count

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airlines.show()

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show()

# COMMAND ----------

airlines.count()

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country='USA'")

# COMMAND ----------

airport_codes.count()

# COMMAND ----------

airlines. \
    join(airport_codes, col("IATA") == col("Origin")). \
    select("Year", "Month", "DayOfMonth", airport_codes["*"], "CRSDepTime"). \
    show()

# COMMAND ----------

airlines. \
    join(airport_codes, airport_codes.IATA == airlines["Origin"]). \
    select("Year", "Month", "DayOfMonth", airport_codes["*"], "CRSDepTime"). \
    show()

# COMMAND ----------

airlines.join?

# COMMAND ----------

flight_count_per_airport = airlines. \
    join(airport_codes, airport_codes.IATA == airlines.Origin). \
    groupBy("Origin"). \
    agg(count(lit(1)).alias("FlightCount")). \
    orderBy(col("FlightCount").desc())

# COMMAND ----------

flight_count_per_airport.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 2
# MAGIC
# MAGIC Get number of flights departed from each of the state.

# COMMAND ----------

from pyspark.sql.functions import col, lit, count

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country='USA'")

# COMMAND ----------

flight_count_per_state = airlines. \
    join(airport_codes, airport_codes.IATA == airlines.Origin). \
    groupBy("State"). \
    agg(count(lit(1)).alias("FlightCount")). \
    orderBy(col("FlightCount").desc())

# COMMAND ----------

flight_count_per_state.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 3
# MAGIC
# MAGIC Get the list of airports in the US from which flights are not departed.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country='USA'")

# COMMAND ----------

airport_codes.printSchema()

# COMMAND ----------

airports_not_used = airport_codes. \
    join(airlines, airport_codes.IATA == airlines.Origin, "left"). \
    select(airport_codes["*"], "Year", "Month", 
           "DayOfMonth", "Origin", "CRSDepTime"). \
    show()

# COMMAND ----------

airports_not_used = airport_codes. \
    join(airlines, airport_codes.IATA == airlines.Origin, "left"). \
    filter(airlines.Origin.isNull()). \
    select('City', 'State', 'Country', 'IATA')

# COMMAND ----------

airports_not_used = airlines. \
    join(airport_codes, airport_codes.IATA == airlines.Origin, "right"). \
    filter("Origin IS NULL"). \
    select('City', 'State', 'Country', 'IATA')

# COMMAND ----------

airports_not_used.count()

# COMMAND ----------

airport_codes.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 4
# MAGIC
# MAGIC Check if there are any origins in airlines data which do not have record in airport-codes.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big')")

# COMMAND ----------

airlines. \
    join(airport_codes, airlines.Origin == airport_codes.IATA, "left"). \
    filter("IATA IS NULL"). \
    select("Origin"). \
    distinct(). \
    show()

# COMMAND ----------

airlines. \
    join(airport_codes, airlines.Origin == airport_codes.IATA, "left"). \
    filter("IATA IS NULL"). \
    select("Origin"). \
    distinct(). \
    count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 5
# MAGIC
# MAGIC Get the total number of flights from the airports that do not contain entries in airport-codes.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big')")

# COMMAND ----------

airlines. \
    join(airport_codes, airlines.Origin == airport_codes.IATA, "left"). \
    filter("IATA IS NULL"). \
    count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 6
# MAGIC
# MAGIC Get the total number of flights per airport that do not contain entries in airport-codes.

# COMMAND ----------

airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

airlines = spark. \
    read. \
    parquet(airlines_path)

# COMMAND ----------

airport_codes_path = "/public/airlines_all/airport-codes"
airport_codes = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       ). \
    filter("!(State = 'Hawaii' AND IATA = 'Big')")

# COMMAND ----------

airlines. \
    join(airport_codes, airlines.Origin == airport_codes.IATA, "left"). \
    filter("IATA IS NULL"). \
    groupBy("Origin"). \
    count(). \
    show()

# COMMAND ----------

