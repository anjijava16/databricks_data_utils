# Databricks notebook source
# MAGIC %md
# MAGIC # Spark Metastore
# MAGIC
# MAGIC Let us understand how to interact with metastore tables using Spark based APIs.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Spark Metastore
# MAGIC
# MAGIC Let us get an overview of Spark Metastore and how we can leverage it to manage databases and tables on top of Big Data based file systems such as HDFS, s3 etc.
# MAGIC
# MAGIC * Quite often we need to deal with structured data and the most popular way of processing structured data is by using Databases, Tables and then SQL.
# MAGIC * Spark Metastore (similar to Hive Metastore) will facilitate us to manage databases and tables.
# MAGIC * Typically Metastore is setup using traditional relational database technologies such as **Oracle**, **MySQL**, **Postgres** etc.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.

# COMMAND ----------

from pyspark.sql import SparkSession

spark = SparkSession. \
    builder. \
    config('spark.ui.port', '0'). \
    appName('Spark Metastore'). \
    master('yarn'). \
    getOrCreate()

# COMMAND ----------

spark.conf.set('spark.sql.shuffle.partitions', '2')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Spark Catalog
# MAGIC
# MAGIC Let us get an overview of Spark Catalog. It is part of `SparkSession` object.
# MAGIC * We can permanently or temporarily create tables or views on top of data in a Data Frame.
# MAGIC * Metadata such as table names, column names, data types etc for these tables or views will be stored in Metastore. It is also known as catalog which is exposed as part of SparkSession object.
# MAGIC * Permanent tables can be grouped into databases in metastore. If not specified, the tables will be created in **default** database.
# MAGIC * Let us say `spark` is of type `SparkSession`. There is an attribute as part of `spark` called as catalog and it is of type pyspark.sql.catalog.Catalog.
# MAGIC * We can access catalog using `spark.catalog`.
# MAGIC * There are several methods that is part of `spark.catalog`. We will explore them in the later topics.
# MAGIC * Following are some of the tasks that can be performed using `spark.catalog` object.
# MAGIC   * Check current database and switch to different databases.
# MAGIC   * Create permanent table in metastore.
# MAGIC   * Create or drop temporary views.
# MAGIC   * Register functions.
# MAGIC * All the above tasks can be performed using SQL style commands passed to `spark.sql`.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Metastore Tables
# MAGIC
# MAGIC Data Frames can be written into Metastore Tables using APIs such as `saveAsTable` and `insertInto` available as part of write on top of objects of type Data Frame.
# MAGIC
# MAGIC * We can create a new table using Data Frame using `saveAsTable`. We can also create an empty table by using `spark.catalog.createTable` or `spark.catalog.createExternalTable`.
# MAGIC * We can also prefix the database name to write data into tables belong to a particular database. If the database is not specified then the session will be attached to default database.
# MAGIC * Databases can be created using `spark.sql("CREATE DATABASE database_name")`. We can list Databases using `spark.sql` or `spark.catalog.listDatabases()`
# MAGIC * We can use modes such as `append`, `overwrite` and `error` with `saveAsTable`. Default is error.
# MAGIC * We can use modes such as `append` and `overwrite` with `insertInto`. Default is append.
# MAGIC * When we use `saveAsTable`, following happens:
# MAGIC   * Check for table if the table already exists. By default `saveAsTable` will throw exception.
# MAGIC   * If the table does not exists the table will be created.
# MAGIC   * Data from Data Frame will be copied into the table.
# MAGIC   * We can alter the behavior by using mode. We can overwrite the existing table or we can append into it.
# MAGIC * We can list the tables using `spark.catalog.listTables` after switching to appropriate database using `spark.catalog.setCurrentDatabase`.
# MAGIC * We can also switch the database and list tables using `spark.sql`.

# COMMAND ----------

spark.catalog?

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC Let us perform few tasks to understand how to write a Data Frame into Metastore tables and also list them.
# MAGIC * Create database by name db in the metastore. We need to use `spark.sql` as there is no function to create database under `spark.catalog`.

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.sql(f"CREATE DATABASE {username}_db")

# COMMAND ----------

spark.catalog.setCurrentDatabase(f'{username}_db')

# COMMAND ----------

# MAGIC %md
# MAGIC * List the databases using both API as well as SQL approach. As we have too many databases in our environment, it might take too much time to return the results

# COMMAND ----------

spark.catalog.listDatabases()

# COMMAND ----------

# MAGIC %md
# MAGIC * Create a Data Frame which contain one column by name **dummy** and one row with value **X**.

# COMMAND ----------

l = [("X", )]
df = spark.createDataFrame(l, schema="dummy STRING")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC * Create a table by name dual for the above Data Frame in the database created. 

# COMMAND ----------

df.write.saveAsTable("dual")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

spark.read.table("dual").show()

# COMMAND ----------

# MAGIC %md
# MAGIC * Let us drop the table **dual** and then database **db**. We need to use `spark.sql` as `spark.catalog` does not have API to drop the tables or databases.

# COMMAND ----------

spark.sql("DROP TABLE dual")

# COMMAND ----------

spark.sql(f"DROP DATABASE {username}_db")

# COMMAND ----------

# We can use CASCADE to drop database along with tables.
spark.sql(f"DROP DATABASE {username}_db CASCADE")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define Schema for Tables
# MAGIC
# MAGIC When we want to create a table using `spark.catalog.createTable` or using `spark.catalog.createExternalTable`, we need to specify Schema.
# MAGIC
# MAGIC * Schema can be inferred or we can pass schema using `StructType` object while creating the table..
# MAGIC * `StructType` takes list of objects of type `StructField`.
# MAGIC * `StructField` is built using column name and data type. All the data types are available under `pyspark.sql.types`.
# MAGIC * We need to pass table name and schema for `spark.catalog.createTable`.
# MAGIC * We have to pass path along with name and schema for `spark.catalog.createExternalTable`.
# MAGIC * We can use source to define file format along with applicable options. For example, if we want to create a table for CSV, then source will be csv and we can pass applicable options for CSV such as sep, header etc.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform tasks to create empty table using `spark.catalog.createTable` or using `spark.catalog.createExternalTable`.
# MAGIC
# MAGIC * Create database **hr_db** and table **employees** with following fields. Let us create Database first and then we will see how to create table.
# MAGIC   * employee_id of type Integer
# MAGIC   * first_name of type String
# MAGIC   * last_name of type String
# MAGIC   * salary of type Float
# MAGIC   * nationality of type String

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {username}_hr_db")

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_hr_db")

# COMMAND ----------

spark.catalog.createTable?

# COMMAND ----------

# MAGIC %md
# MAGIC * Build StructType object using StructField list.

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, \
    IntegerType, StringType, FloatType

# COMMAND ----------

employeesSchema = StructType([
    StructField("employee_id", IntegerType()),
    StructField("first_name", StringType()),
    StructField("last_name", StringType()),
    StructField("salary", FloatType()),
    StructField("nationality", StringType())
])

# COMMAND ----------

spark.sql('DROP TABLE employees')

# COMMAND ----------

# MAGIC %md
# MAGIC * Create table by passing StructType object as schema.

# COMMAND ----------

spark.catalog.createTable("employees", schema=employeesSchema)

# COMMAND ----------

# MAGIC %md
# MAGIC * List the tables from database created.

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

spark.catalog.listColumns('employees')

# COMMAND ----------

spark.sql('DESCRIBE FORMATTED employees').show(100, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC * Create database by name **{username}_airlines** and create external table for **airport-codes.txt**.
# MAGIC   * Data have header
# MAGIC   * Fields in each record are delimited by a tab character.
# MAGIC   * We can pass options such as sep, header, inferSchema etc to define the schema.
# MAGIC

# COMMAND ----------

spark.catalog.createExternalTable?

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {username}_airlines")

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_airlines")

# COMMAND ----------

# MAGIC %md
# MAGIC * To create external table, we need to have write permissions over the path which we want to use.
# MAGIC * As we have only read permissions on **/public/airlines_all/airport-codes** we cannot use that path while creating external table.
# MAGIC * Let us copy the data to **/user/`whoami`/airlines_all/airport-codes**

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -mkdir -p /user/`whoami`/airlines_all
# MAGIC hdfs dfs -cp -f /public/airlines_all/airport-codes /user/`whoami`/airlines_all
# MAGIC hdfs dfs -ls /user/`whoami`/airlines_all/airport-codes

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -tail /user/`whoami`/airlines_all/airport-codes/airport-codes-na.txt

# COMMAND ----------

import getpass
username = getpass.getuser()

airport_codes_path = f'/user/{username}/airlines_all/airport-codes'

# COMMAND ----------

spark.sql('DROP TABLE airport_codes')

# COMMAND ----------

spark.catalog. \
    createExternalTable("airport_codes",
                        path=airport_codes_path,
                        source="csv",
                        sep="\t",
                        header="true",
                        inferSchema="true"
                       )

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

spark.read.table("airport_codes").show()

# COMMAND ----------

spark.sql('DESCRIBE FORMATTED airport_codes').show(100, False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Inserting into Existing Tables
# MAGIC
# MAGIC Let us understand how we can insert data into existing tables using `insertInto`.
# MAGIC
# MAGIC * We can use modes such as `append` and `overwrite` with `insertInto`. Default is `append`.
# MAGIC * When we use `insertInto`, following happens:
# MAGIC   * If the table does not exist, `insertInto` will throw an exception.
# MAGIC   * If the table exists, by default data will be appended.
# MAGIC   * We can alter the behavior by using keyword argument overwrite. It is by default False, we can pass True to replace existing data.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to understand how to write a Data Frame into existing tables in the Metastore.
# MAGIC
# MAGIC * Make sure hr_db database and employees table in hr_db are created.

# COMMAND ----------

spark.catalog.listDatabases()

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_hr_db")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC Use employees Data Frame and insert data into the employees table in hr_db database. Make sure existing data is overwritten.

# COMMAND ----------

employees = [(1, "Scott", "Tiger", 1000.0, "united states"),
             (2, "Henry", "Ford", 1250.0, "India"),
             (3, "Nick", "Junior", 750.0, "united KINGDOM"),
             (4, "Bill", "Gomes", 1500.0, "AUSTRALIA")
            ]

# COMMAND ----------

employeesDF = spark.createDataFrame(employees,
    schema="""employee_id INT, first_name STRING, last_name STRING,
              salary FLOAT, nationality STRING
           """
)

# COMMAND ----------

employeesDF.write.insertInto("employees", overwrite=True)

# COMMAND ----------

employeesDF.write.mode('overwrite').insertInto("employees")

# COMMAND ----------

spark.read.table("employees").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reading and Processing Tables
# MAGIC
# MAGIC Let us see how we can read tables using functions such as `spark.read.table` and process data using Data Frame APIs.
# MAGIC
# MAGIC * Using Data Frame APIs - `spark.read.table("table_name")`.
# MAGIC * We can also prefix the database name to read tables belong to a particular database.
# MAGIC * When we read the table, it will result in a Data Frame.
# MAGIC * Once Data Frame is created we can use functions such as `filter` or `where`, `groupBy`, `sort` or `orderBy` to process the data in the Data Frame.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC Let us see how we can create a table using data in a file and then read into a Data Frame.
# MAGIC
# MAGIC * Create Database for **airlines** data.

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {username}_airlines")

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_airlines")

# COMMAND ----------

# MAGIC %md
# MAGIC * Create table by name **airport-codes** for file **airport-codes.txt**. The file contains header and each field in each row is delimited by a tab character.

# COMMAND ----------

airport_codes_path = f"/user/{username}/airlines_all/airport-codes"

# COMMAND ----------

spark.sql(f'DROP TABLE {username}_airlines.airport_codes')

# COMMAND ----------

airport_codes_df = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       )

# COMMAND ----------

airport_codes_df.write.saveAsTable(f"{username}_airlines.airport_codes")

# COMMAND ----------

# MAGIC %md
# MAGIC * Read data from table and get number of airports by state.

# COMMAND ----------

airport_codes = spark.read.table("airport_codes")

# COMMAND ----------

type(airport_codes)

# COMMAND ----------

spark.sql('DESCRIBE FORMATTED airport_codes').show(100, False)

# COMMAND ----------

airport_codes. \
    groupBy("state"). \
    count(). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Partitioned Tables
# MAGIC
# MAGIC We can also create partitioned tables as part of Spark Metastore Tables.
# MAGIC
# MAGIC * There are some challenges in creating partitioned tables directly using `spark.catalog.createTable`.
# MAGIC * But if the directories are similar to partitioned tables with data, we should be able to create partitioned tables. They are typically external tables.
# MAGIC * Let us create partitioned table for `orders` by `order_month`.

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.sql(f'CREATE DATABASE IF NOT EXISTS {username}_retail')

# COMMAND ----------

spark.catalog.setCurrentDatabase(f'{username}_retail')

# COMMAND ----------

orders_path = '/public/retail_db/orders'

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -ls /public/retail_db/orders

# COMMAND ----------

from pyspark.sql.functions import date_format

# COMMAND ----------

spark.sql('DROP TABLE orders_part')

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -ls /user/`whoami`/retail_db/orders_part

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -rm -R /user/`whoami`/retail_db/orders_part

# COMMAND ----------

spark. \
    read. \
    csv(orders_path,
        schema='''order_id INT, order_date DATE,
                  order_customer_id INT, order_status STRING
               '''
       ). \
    withColumn('order_month', date_format('order_date', 'yyyyMM')). \
    write. \
    partitionBy('order_month'). \
    parquet(f'/user/{username}/retail_db/orders_part')

# COMMAND ----------

# MAGIC %%sh
# MAGIC
# MAGIC hdfs dfs -ls -R /user/`whoami`/retail_db/orders_part

# COMMAND ----------

spark. \
    read. \
    parquet(f'/user/{username}/retail_db/orders_part/order_month=201308'). \
    show()

# COMMAND ----------

spark. \
    read. \
    parquet(f'/user/{username}/retail_db/orders_part'). \
    show()

# COMMAND ----------

spark. \
    catalog. \
    createTable('orders_part',
                path=f'/user/{username}/retail_db/orders_part',
                source='parquet'
               )

# COMMAND ----------

spark.catalog.recoverPartitions('orders_part')

# COMMAND ----------

spark.read.table('orders_part').show()

# COMMAND ----------

spark.sql('SELECT order_month, count(1) FROM orders_part GROUP BY order_month').show()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating Temp Views
# MAGIC
# MAGIC So far we spoke about permanent metastore tables. Now let us understand how to create temporary views using a Data Frame.
# MAGIC
# MAGIC * We can create temporary view for a Data Frame using `createTempView` or `createOrReplaceTempView`.
# MAGIC * `createOrReplaceTempView` will replace existing view, if it already exists.
# MAGIC * While tables in Metastore are permanent, views are temporary.
# MAGIC * Once the application exits, temporary views will be deleted or flushed out.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to create temporary view and process the data using the temporary view.
# MAGIC
# MAGIC * Create temporary view by name **airport_codes_v** for file **airport-codes.txt**. The file contains header and each field in each row is delimited by a tab character.

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_airlines")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

airport_codes_path = f"/public/airlines_all/airport-codes"

# COMMAND ----------

airport_codes_df = spark. \
    read. \
    csv(airport_codes_path,
        sep="\t",
        header=True,
        inferSchema=True
       )

# COMMAND ----------

airport_codes_df.createTempView("airport_codes_v")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC * Read data from view and get number of airports by state.

# COMMAND ----------

airport_codes = spark.read.table("airport_codes_v")

# COMMAND ----------

airport_codes. \
    groupBy("state"). \
    count(). \
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC * List the tables in the metastore and views.

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_airlines")

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using Spark SQL
# MAGIC
# MAGIC Let us understand how we can use Spark SQL to process data in Metastore Tables and Temporary Views.
# MAGIC
# MAGIC * Once tables are created in metastore or temporary views are created, we can run queries against the tables to perform all standard transformations.

# COMMAND ----------

import getpass
username = getpass.getuser()

# COMMAND ----------

spark.catalog.setCurrentDatabase(f"{username}_airlines")

# COMMAND ----------

# MAGIC %md
# MAGIC * Here are some of the transformations which can be performed.
# MAGIC   * Row Level Transformations using functions in SELECT clause.
# MAGIC   * Filtering using WHERE clause
# MAGIC   * Aggregations using GROUP BY and aggregate functions.
# MAGIC   * Sorting using ORDER BY or SORT BY

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform some tasks to understand how to process data using Spark SQL using Metastore Tables or Temporary Views.
# MAGIC * Make sure table or view created for airport-codes. We can use the table or view created in the previous step.

# COMMAND ----------

spark.catalog.listTables()

# COMMAND ----------

# MAGIC %md
# MAGIC * Write a query to get number of airports per state in the US. 
# MAGIC   * Get only those states which have more than 10 airports.
# MAGIC   * Make sure data is sorted in descending order by number of airports.

# COMMAND ----------

spark. \
    sql("""SELECT state, count(1) AS airport_cnt
           FROM airport_codes_v
           GROUP BY state
               HAVING count(1) >= 10
           ORDER BY airport_cnt DESC
        """). \
  show()

# COMMAND ----------

airport_count = spark. \
    sql("""SELECT state, count(1) AS airport_cnt
           FROM airport_codes_v
           GROUP BY state
               HAVING count(1) >= 10
        """)

# COMMAND ----------

from matplotlib import pyplot as plt

airport_count_dict = dict(airport_count.collect())

# COMMAND ----------

states = list(airport_count_dict.keys())
states

# COMMAND ----------

airport_counts = list(airport_count_dict.values())
airport_counts

# COMMAND ----------

plt.plot(states, airport_counts)
plt.xlabel('States')
plt.ylabel('Airport Counts')
plt.show()

# COMMAND ----------

