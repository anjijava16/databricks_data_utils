# Databricks notebook source
# MAGIC %md
# MAGIC # Getting Started
# MAGIC
# MAGIC ## Platforms to Practice
# MAGIC
# MAGIC Let us understand different platforms we can leverage to practice Apache Spark using Python.
# MAGIC
# MAGIC * Local Setup
# MAGIC * Databricks Platform
# MAGIC * Setting up your own cluster
# MAGIC * Cloud based labs
# MAGIC
# MAGIC
# MAGIC ## Setup Spark Locally - Ubuntu
# MAGIC
# MAGIC Let us setup Spark Locally on Ubuntu.
# MAGIC
# MAGIC * Install latest version of Anaconda
# MAGIC * Make sure Jupyter Notebook is setup and validated.
# MAGIC * Setup Spark and Validate.
# MAGIC * Setup Environment Variables to integrate Pyspark with Jupyter Notebook.
# MAGIC * Launch Jupyter Notebook using <mark> pyspark </mark> command.
# MAGIC * Setup PyCharm (IDE) for application development.
# MAGIC
# MAGIC
# MAGIC ## Setup Spark Locally - Mac
# MAGIC
# MAGIC ### Let us setup Spark Locally on Ubuntu.
# MAGIC
# MAGIC * Install latest version of Anaconda
# MAGIC * Make sure Jupyter Notebook is setup and validated.
# MAGIC * Setup Spark and Validate.
# MAGIC * Setup Environment Variables to integrate Pyspark with Jupyter Notebook.
# MAGIC * Launch Jupyter Notebook using <mark> pyspark </mark> command.
# MAGIC * Setup PyCharm (IDE) for application development.
# MAGIC
# MAGIC
# MAGIC ## Signing up for ITVersity Labs
# MAGIC
# MAGIC * 
# MAGIC
# MAGIC
# MAGIC ## Using ITVersity Labs
# MAGIC
# MAGIC Let us understand how to submit the Spark Jobs in ITVersity Labs.
# MAGIC
# MAGIC * As we are using Python we can also use the help command to get the documentation - for example <mark> help(spark.read.csv)</mark>
# MAGIC
# MAGIC
# MAGIC ## Interacting with File Systems
# MAGIC
# MAGIC Let us understand how to interact with file system using %fs command from Databricks Notebook.
# MAGIC
# MAGIC * We can access datasets using %fs magic command in Databricks notebook
# MAGIC * By default, we will see files under dbfs
# MAGIC * We can list the files using ls command - e. g.: <mark> (%fs ls)</mark>
# MAGIC * Databricks provides lot of datasets for free under databricks-datasets
# MAGIC * If the cluster is integrated with AWS or Azure Blob we can access files by specifying the appropriate protocol (e.g.: s3:// for s3)
# MAGIC * List of commands available under %fs
# MAGIC
# MAGIC  * Copying files or directories <mark>-cp</mark>
# MAGIC  * Moving files or directories <mark>- mv </mark>
# MAGIC  * Creating directories <mark> - mkdirs </mark> 
# MAGIC  * Deleting files and directories <mark> - rm </mark>
# MAGIC  * We can copy or delete directories recursively using <mark> -r</mark> or <mark>--recursive</mark>
# MAGIC
# MAGIC ## Getting File Metadata
# MAGIC
# MAGIC Let us review the source location to get number of files and the size of the data we are going to process.
# MAGIC
# MAGIC * Location of airlines data dbfs:/databricks-datasets/airlines
# MAGIC * We can get first 1000 files using %fs ls dbfs:/databricks-datasets/airlines
# MAGIC * Location contain 1919 Files, however we will not be able to see all the details using %fs command.
# MAGIC * Databricks File System commands does not have capability to understand metadata of files such as size in details.
# MAGIC * When Spark Cluster is started, it will create 2 objects - spark and sc
# MAGIC * sc is of type SparkContext and spark is of type SparkSession
# MAGIC * Spark uses HDFS APIs to interact with the file system and we can access HDFS APIs using sc._jsc and sc._jvm to get file metadata.
# MAGIC
# MAGIC
# MAGIC * Here are the steps to get the file metadata.
# MAGIC  
# MAGIC  * Get Hadoop Configuration using <mark> sc._jsc.hadoopConfiguration()</mark> - let's say <mark>conf</mark>
# MAGIC   * We can pass conf to <mark> sc._jvm.org.apache.hadoop.fs.FileSystem.</mark> get to get FileSystem object - let's say <mark>fs</mark>
# MAGIC   * We can build <mark> path</mark>  object by passing the path as string to <mark>sc._jvm.org.apache.hadoop.fs.Path</mark>
# MAGIC   * We can invoke <mark>listStatus</mark> on top of fs by passing path which will return an array of FileStatus objects - let's say files.  
# MAGIC   * Each <mark>FileStatus</mark> object have all the metadata of each file.
# MAGIC   * We can use <mark>len</mark> on files to get number of files.
# MAGIC   * We can use <mark>getLen</mark> on each <mark>FileStatus</mark> object to get the size of each file. 
# MAGIC   Cumulative size of all files can be achieved using <mark>sum(map(lambda file: file.getLen(), files))</mark>
# MAGIC   
# MAGIC   Let us first get list of files 
# MAGIC   
# MAGIC   
# MAGIC     
# MAGIC
# MAGIC
# MAGIC   
# MAGIC

# COMMAND ----------

# MAGIC %fs ls dbfs:/databricks-datasets/airlines

# COMMAND ----------

# MAGIC %md
# MAGIC Here is the consolidated script to get number of files and cumulative size of all files in a given folder.

# COMMAND ----------

conf = sc._jsc.hadoopConfiguration()
fs = sc._jvm.org.apache.hadoop.fs.FileSystem.get(conf)
path = sc._jvm.org.apache.hadoop.fs.Path("dbfs:/databricks-datasets/airlines")

files = fs.listStatus(path)
sum(map(lambda file: file.getLen(), files))/1024/1024/1024