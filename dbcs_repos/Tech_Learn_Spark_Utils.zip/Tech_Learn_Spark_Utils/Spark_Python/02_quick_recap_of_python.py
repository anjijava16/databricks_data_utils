# Databricks notebook source
# MAGIC %md
# MAGIC # Quick Recap of Python
# MAGIC
# MAGIC Let us quickly recap of some of the core programming concepts of Python before we get into Spark.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Engineering Life Cycle
# MAGIC
# MAGIC Let us first understand the Data Engineering Life Cycle. We typically read the data, process it by applying business rules and write the data back to different targets
# MAGIC * Read the data from different sources.
# MAGIC   * Files
# MAGIC   * Databases
# MAGIC   * Mainframes
# MAGIC   * APIs
# MAGIC * Processing the data
# MAGIC   * Row Level Transformations
# MAGIC   * Aggregations
# MAGIC   * Sorting
# MAGIC   * Ranking
# MAGIC   * Joining multiple data sets
# MAGIC * Write data to different targets.
# MAGIC   * Files
# MAGIC   * Databases
# MAGIC   * Mainframes
# MAGIC   * APIs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Python CLI or Jupyter Notebook
# MAGIC
# MAGIC We can use Python CLI or Jupyter Notebook to explore APIs.
# MAGIC
# MAGIC * We can launch Python CLI using `python` command.
# MAGIC * We can launch the Jupyter Notebook using the `jupyter notebook` command.
# MAGIC * A web service will be started on port number 8888 by default.
# MAGIC * We can go to the browser and connect to the web server using IP address and port number.
# MAGIC * We should be able to explore code in interactive fashion.
# MAGIC * We can issue magic commands such as %%sh to run shell commands, %%md to document using markdown etc.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform these tasks to just recollect how to use Python CLI or Jupyter Notebook.
# MAGIC * Create variables i and j assigning 10 and 20.5 respectively.

# COMMAND ----------

i = 10
j = 20.5

# COMMAND ----------

# MAGIC %md
# MAGIC * Add the values and assign it to res.

# COMMAND ----------

res = i + j
print(str(res))

# COMMAND ----------

# MAGIC %md
# MAGIC * Get the type of i, j and res.

# COMMAND ----------

type(i)

# COMMAND ----------

type(j)

# COMMAND ----------

type(res)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get the help on int.

# COMMAND ----------

help(int)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get the help on startswith that is available on str.

# COMMAND ----------

help(str.startswith)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Basic Programming Constructs
# MAGIC
# MAGIC Let us recollect some of the basic programming constructs of Python.
# MAGIC * Comparison Operations (==, !=, <, >, <=, >=, etc) 
# MAGIC   * All the comparison operators return a True or False (Boolean value)
# MAGIC * Conditionals (if) 
# MAGIC   * We typically use comparison operators as part of conditionals.
# MAGIC * Loops (for) 
# MAGIC   * We can iterate through collection using <mark>for i in l</mark> where l is a standard collection such as list or set.
# MAGIC   * Python provides special function called as <mark>range</mark> which will return a collection of integers between the given range. It excludes the upper bound value.
# MAGIC * In Python, scope is defined by indentation.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC  
# MAGIC Let us perform few tasks to quickly recap basic programming constructs of Python.
# MAGIC  * Get all the odd numbers between 1 and 15.
# MAGIC  

# COMMAND ----------

list(range(1, 16, 2))

# COMMAND ----------

# MAGIC %md
# MAGIC * Print all those numbers which are divisible by 3 from the above list.

# COMMAND ----------

for i in list(range(1, 16, 2)):
    if(i%3 == 0): print(i)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Developing Functions
# MAGIC
# MAGIC Let us understand how to develop functions using Python as programming language.
# MAGIC * Function starts with <mark>def</mark> followed by function name.
# MAGIC * Parameters can be of different types.
# MAGIC     * Required
# MAGIC     * Keyword
# MAGIC     * Variable Number
# MAGIC     * Functions
# MAGIC * Functions which take another function as an argument is called higher order functions.
# MAGIC
# MAGIC ### Tasks
# MAGIC
# MAGIC  Let us perform few tasks to understand how to develop functions in Python.   
# MAGIC  
# MAGIC  * Sum of integers between lower bound and upper bound using formula.
# MAGIC
# MAGIC

# COMMAND ----------

def sumOfN(n):
    return int((n * (n + 1)) / 2)

sumOfN(10)

# COMMAND ----------

def sumOfIntegers(lb, ub):
    return sumOfN(ub) - sumOfN(lb -1)

sumOfIntegers(5, 10)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of integers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfIntegers(lb, ub):
    total = 0
    for e in range(lb, ub + 1):
        total += e
    return total

sumOfIntegers(1, 10)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of squares of integers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfSquares(lb, ub):
    total = 0
    for e in range(lb, ub + 1):
        total += e * e
    return total

sumOfSquares(2, 4)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of the even numbers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfEvens(lb, ub):
    total = 0
    for e in range(lb, ub + 1):
        total += e if e%2==0 else 0
    return total

sumOfEvens(2, 4)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lambda Functions
# MAGIC
# MAGIC Let us recap details related to lambda functions.
# MAGIC
# MAGIC * We can develop functions with out names. They are called Lambda Functions and also known as Anonymous Functions.
# MAGIC * We typically use them to pass as arguments to higher order functions which takes functions as arguments
# MAGIC     

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks related to lambda functions.
# MAGIC     
# MAGIC * Create a generic function mySum which is supposed to perform arithmetic using integers within a range.
# MAGIC     
# MAGIC     * It takes 3 arguments - lb, ub and f.
# MAGIC     * Function f should be invoked inside the function on each element within the range.
# MAGIC
# MAGIC     

# COMMAND ----------

def mySum(lb, ub, f):
    total = 0
    for e in range(lb, ub + 1):
        total += f(e)
    return total

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of integers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, lambda i: i)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of squares of integers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, lambda i: i * i)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of the even numbers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, lambda i: i if i%2 == 0 else 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Collections and Tuples
# MAGIC
# MAGIC Let's quickly recap about Collections and Tuples in Python. We will primarily talk about collections and tuples that comes as part of Python standard library such as <mark>list</mark>, <mark>set</mark>,<mark> dict</mark> and <mark>tuple.</mark>
# MAGIC
# MAGIC * Group of elements with length and index - <mark>list</mark>
# MAGIC * Group of unique elements - <mark>set</mark>
# MAGIC * Group of key value pairs - <mark>dict</mark>
# MAGIC * While list, set and dict contain group of homogeneous elements, tuple contains group of heterogeneous elements.
# MAGIC * We can consider list, set and dict as a table in a database and tuple as a row or record in a given table.
# MAGIC * Typically we create list of tuples or set of tuples and dict is nothing but collection of tuples with 2 elements and key is unique.
# MAGIC * We typically use Map Reduce APIs to process the data in collections. There are also some pre-defined functions such as <mark>len</mark>, <mark>sum</mark>,<mark> min</mark>,<mark> max</mark> etc for aggregating data in collections.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to quickly recap details about Collections and Tuples in Python. We will also quickly recap about Map Reduce APIs.
# MAGIC
# MAGIC * Create a collection of orders by reading data from a file.

# COMMAND ----------

# MAGIC %%sh
# MAGIC ls -ltr /data/retail_db/orders/part-00000

# COMMAND ----------

orders_path = "/data/retail_db/orders/part-00000"
orders = open(orders_path). \
    read(). \
    splitlines()

# COMMAND ----------

# MAGIC %md
# MAGIC * Get all unique order statuses. Make sure data is sorted in alphabetical order.

# COMMAND ----------

sorted(set(map(lambda o: o.split(",")[3], orders)))

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of all unique dates.

# COMMAND ----------

len(list(map(lambda o: o.split(",")[1], orders)))

# COMMAND ----------

# MAGIC %md
# MAGIC * Sort the data in orders in ascending order by order_customer_id and then order_date.

# COMMAND ----------

sorted(orders, key=lambda k: (int(k.split(",")[2]), k.split(",")[1]))

# COMMAND ----------

# MAGIC %md
# MAGIC * Create a collection of order_items by reading data from a file.

# COMMAND ----------

order_items_path = "/data/retail_db/order_items/part-00000"
order_items = open(order_items_path). \
    read(). \
    splitlines()

# COMMAND ----------

# MAGIC %md
# MAGIC * Get revenue for a given order_item_order_id.

# COMMAND ----------

def get_order_revenue(order_items, order_id):
    order_items_filtered = filter(lambda oi: 
                                  int(oi.split(",")[1]) == 2, 
                                  order_items
                                 )
    order_items_map = map(lambda oi: 
                          float(oi.split(",")[4]), 
                          order_items_filtered
                         )
    return round(sum(order_items_map), 2)

get_order_revenue(order_items, 2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Pandas Data Frames
# MAGIC
# MAGIC While collections are typically the group of objects or tuples or simple strings, we need to parse them to further process the data. This process is tedious at times.
# MAGIC  * With Data Frames we can define the structure.
# MAGIC  * Data Frame is nothing but group of rows where each row have multiple attributes with names.
# MAGIC  * Data Frame is similar to a Database Table or Spreadsheet with Header.
# MAGIC  * Pandas provide rich and simple functions to convert data in files into Data Frames and process them
# MAGIC  * Data can be read from files into Data Frame using functions such as read_csv.
# MAGIC  * We can perform all standard operations on Data Frames.
# MAGIC     * Projection or Selection     
# MAGIC     * Filtering     
# MAGIC     * Aggregations     
# MAGIC     * Joins     
# MAGIC     * Sorting

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to recap the usage of Pandas Data Frames.
# MAGIC     
# MAGIC  * Read order items data from the location on your system. In mine it is /data/retail_db/order_items/part-00000. Use the information below to define schema.
# MAGIC  * It has 6 fields with the below names in the same order as specified below.
# MAGIC  * order_item_id
# MAGIC  * order_item_order_id
# MAGIC  * order_item_product_id
# MAGIC  * order_item_quantity
# MAGIC  * order_item_subtotal
# MAGIC  * order_item_product_price

# COMMAND ----------

import pandas as pd
order_items_path = "/data/retail_db/order_items/part-00000"
order_items = pd. \
    read_csv(order_items_path,
             names=["order_item_id", "order_item_order_id",
                    "order_item_product_id", "order_item_quantity",
                    "order_item_subtotal", "order_item_product_price"
                   ]
            )

# COMMAND ----------

# MAGIC %md
# MAGIC * Project order_item_order_id and order_item_subtotal

# COMMAND ----------

order_items[["order_item_id", "order_item_subtotal"]]

# COMMAND ----------

# MAGIC %md
# MAGIC * Filter for order_item_order_id 2

# COMMAND ----------

order_items.query("order_item_order_id == 2")

# COMMAND ----------

# MAGIC %md
# MAGIC * Compute revenue for order_item_order_id 2

# COMMAND ----------

order_items. \
    query("order_item_order_id == 2")["order_item_subtotal"]. \
    sum()

# COMMAND ----------

# MAGIC %md
# MAGIC * Get number of items and revenue for each order id. Give alias to the order revenue as **revenue**.

# COMMAND ----------

order_items. \
    groupby("order_item_order_id")["order_item_subtotal"]. \
    sum()

# COMMAND ----------

order_items. \
    groupby("order_item_order_id")["order_item_subtotal"]. \
    agg(['sum', 'count']). \
    rename(columns={'sum': 'revenue'})

# COMMAND ----------

# MAGIC %md
# MAGIC ## Limitations of Pandas
# MAGIC
# MAGIC We can use Pandas for data processing. It provides rich APIs to read data from different sources, process the data and then write it to different targets.
# MAGIC
# MAGIC * Pandas works well for light weight data processing.
# MAGIC * Pandas is typically single threaded, which means only one process take care of processing the data.
# MAGIC * As data volume grows, the processing time might grow exponentially and also run into resource contention.
# MAGIC * It is not trivial to use distributed processing using Pandas APIs. We will end up struggling with multi threading rather than business logic.
# MAGIC * There are Distributed Computing Frameworks such as Hadoop Map Reduce, Spark etc to take care of data processing at scale on multi node Hadoop or Spark Clusters.
# MAGIC * Both Hadoop Map Reduce and Spark comes with Distributed Computing Frameworks as well as APIs.
# MAGIC
# MAGIC **Pandas is typically used for light weight Data Processing and Spark is used for Data Processing at Scale.**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Development Life Cycle
# MAGIC
# MAGIC Let us understand the development life cycle. We typically use IDEs such as PyCharm to develop Python based applications.
# MAGIC
# MAGIC * Create Project - retail
# MAGIC * Choose the interpreter 3.x
# MAGIC * Make sure plugins such as pandas are installed.
# MAGIC * Create config.py script for externalizing run time parameters such as input path, output path etc.
# MAGIC * Create app folder for the source code.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us develop a simple application to understand end to end development life cycle.
# MAGIC
# MAGIC * Read the data from order_items
# MAGIC * Get revenue for each order id
# MAGIC * Save the output which contain order id and revenue to a file.
# MAGIC
# MAGIC Click [here](https://github.com/dgadiraju/python-retail/tree/v1.0) for the complete code for the above tasks.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercises
# MAGIC
# MAGIC Let us perform few exercises to understand how to process the data. We will use LinkedIn data to perform some basic data processing using Python.
# MAGIC
# MAGIC * Get LinkedIn archive.
# MAGIC   * Go to https://linkedin.com
# MAGIC   * Me on top -> Settings & Privacy
# MAGIC   * Then go to "How LinkedIn users your data" -> Getting a copy of your data
# MAGIC   * Register and download. You will get a link as part of the email.
# MAGIC * Data contain multiple CSV files. We will limit the analysis to **Contacts.csv** and **Connections.csv**.
# MAGIC * Get the number of **contacts** with out email ids.
# MAGIC * Get the number of **contacts** from each source.
# MAGIC * Get the number of **connections** with each title.
# MAGIC * Get the number of **connections** from each company.
# MAGIC * Get the number of **contacts** for each month in the year 2018.
# MAGIC * Use Postgres or MySQL as databases (you can setup in your laptop) and write connections data to the database

# COMMAND ----------

