# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Horovod Lab
# MAGIC
# MAGIC In this notebook, we are going to take the Boston Dataset that we were working with earlier, but change it to train across the cluster, instead of just on the driver.
# MAGIC
# MAGIC Let's start by reading in the data, and converting it to a Spark DataFrame.

# COMMAND ----------

import pandas as pd
from pyspark.ml.feature import VectorAssembler
from pyspark.sql.functions import *
from tensorflow import keras 

(x_train, y_train), (x_test, y_test) = keras.datasets.boston_housing.load_data()

pdTrain = pd.concat([pd.DataFrame(x_train), pd.DataFrame(y_train, columns=["label"])], axis=1)
pdTest = pd.concat([pd.DataFrame(x_test), pd.DataFrame(y_test, columns=["label"])], axis=1)

trainDF = spark.createDataFrame(pdTrain)
testDF = spark.createDataFrame(pdTest)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Types
# MAGIC
# MAGIC There are a few limitations with the current implementation of Horovod. One of them is that the datatypes have to be of float type, and for inference, it needs to be an array type instead of a Vector. We have already done those transformations for you below.

# COMMAND ----------

trainDF = trainDF.select([col(c).cast("float") for c in trainDF.columns])
testDF = testDF.select([col(c).cast("float") for c in testDF.columns]) 
# Must to train on float datatype (if use VectorAssembler, automatically does the conversion), but label needs to be converted too

vec = VectorAssembler(inputCols=trainDF.columns[:-1], outputCol="features")
trainDF = (vec.transform(trainDF)
           .select("features", "label")
           .withColumn("isVal", when(rand() > 0.8, True).otherwise(False)))

# If want inference to work, must use Array instead of Vector type
testDF = testDF.select(array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12").alias("features"), "label") 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Model_fn
# MAGIC
# MAGIC Create the model_fn below. You have 2 options:
# MAGIC * Write the model_fn directly in Tensorflow
# MAGIC * Use a pre-made estimator from Tensorflow, and extract the model_fn
# MAGIC
# MAGIC Your model should be a regression model, with 50 and 20 hidden units. They should use `relu` as the activation function.

# COMMAND ----------

from sparkdl.estimators.horovod_estimator.estimator import HorovodEstimator

help(HorovodEstimator)

# COMMAND ----------

# ANSWER

import horovod.tensorflow as hvd  
import tensorflow as tf

tf.set_random_seed(seed=42)

def model_fn(features, labels, mode, params, config):
    feat_cols = [tf.feature_column.numeric_column(key="features", shape=(13,))]
    regressor = tf.estimator.DNNRegressor(hidden_units=[50, 20],
                                          feature_columns=feat_cols,
                                          optimizer=hvd.DistributedOptimizer(tf.train.AdamOptimizer(.001)))
    estimator_spec = regressor.model_fn(features, labels, mode, config)
    export_outputs = estimator_spec.export_outputs
    if export_outputs is not None:
        export_outputs[tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY] = export_outputs["predict"]
    return tf.estimator.EstimatorSpec(mode=mode, loss=estimator_spec.loss, train_op=estimator_spec.train_op,
                                      export_outputs=export_outputs, training_hooks=estimator_spec.training_hooks, predictions=estimator_spec.predictions)
  
  
# NOT RECOMMENDED BY ENGINEERING! USE AT YOUR OWN RISK.
# def model_fn(features, labels, mode, params, config):
#     model = keras.models.Sequential()
#     features["features_input"] = tf.reshape(features["features_input"], [-1, 13]) # Explicitly specify dimensions
    
#     model.add(keras.layers.Dense(50, input_dim=13, activation="relu", name="features"))
#     model.add(keras.layers.Dense(20, activation="relu"))
#     model.add(keras.layers.Dense(1, name="prediction"))
    
#     optimizer = horovod.tensorflow.DistributedOptimizer(tf.train.AdamOptimizer(learning_rate=0.001))
#     model.compile(optimizer=optimizer, loss='mse', metric=["mse"])
#     # Convert Keras model to a tf.estimator, then apply the resulting estimator's model function to our data
#     # We have to create the keras model & perform the conversion to tf.estimator within model_fn as tf_est.model_fn is not picklable
#     tf_est = tf.keras.estimator.model_to_estimator(keras_model=model)
#     return tf_est.model_fn(features, labels, mode, params)

# COMMAND ----------

# MAGIC %md
# MAGIC ## HorovodEstimator
# MAGIC
# MAGIC Create a HorovodEstimator. You need to specify `modelFn`, `featureMapping`, `modelDir` `labelCol`, `batchSize`, `maxSteps`, `isValidationCol`, and you can optionally specify         `saveCheckpointsSecs`.
# MAGIC
# MAGIC Set `batchSize`=64, and `maxSteps`=100 to start off with.

# COMMAND ----------

# Create Model Directory
import time
model_dir = "/tmp/horovodDemo/" + str(int(time.time())) # Have to use local path
print(model_dir)

# COMMAND ----------

# ANSWER

est = HorovodEstimator(modelFn=model_fn,
                       featureMapping={"features":"features"},
                       modelDir=model_dir,
                       labelCol="label",
                       batchSize=64,
                       maxSteps=100,
                       isValidationCol="isVal",                       
                       saveCheckpointsSecs=30)

# COMMAND ----------

transformer = est.fit(trainDF)

# COMMAND ----------

res = transformer.transform(testDF)
display(res)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract Predictions and Evaluate

# COMMAND ----------

from pyspark.sql.types import FloatType

def _getPrediction(v): # Need to get element out of list to do RMSE below
  return float(v[0])
getPrediction = udf(_getPrediction, FloatType())

predDF = res.select(getPrediction("predictions").alias("prediction"), "label")
display(predDF)

# COMMAND ----------

from pyspark.ml.evaluation import RegressionEvaluator

regEval = RegressionEvaluator(predictionCol='prediction', labelCol='label', metricName='mse')

regEval.evaluate(predDF)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Improve
# MAGIC
# MAGIC Go back and modify the model_fn, or the HorovodEstimator parameters to reduce your MSE!

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2018 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>