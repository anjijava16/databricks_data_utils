// Databricks notebook source
// MAGIC %md # Course: Airlift-Data-Science
// MAGIC * Version 1.0.0
// MAGIC * Built 2018-10-30 23:38:43 UTC
// MAGIC
// MAGIC Copyright © 2018 Databricks, Inc.