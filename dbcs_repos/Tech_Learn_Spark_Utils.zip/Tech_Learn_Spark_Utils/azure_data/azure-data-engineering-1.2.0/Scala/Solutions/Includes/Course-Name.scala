// Databricks notebook source
// MAGIC
// MAGIC %python
// MAGIC course_name = "Azure Integrations"