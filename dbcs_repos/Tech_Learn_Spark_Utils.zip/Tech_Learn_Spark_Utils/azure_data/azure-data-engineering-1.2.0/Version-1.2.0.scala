// Databricks notebook source
// MAGIC
// MAGIC %md # Course: azure-data-engineering
// MAGIC * Version 1.2.0
// MAGIC * Built 2019-03-11 23:04:21 UTC
// MAGIC
// MAGIC Copyright \u00a9 2019 Databricks, Inc.