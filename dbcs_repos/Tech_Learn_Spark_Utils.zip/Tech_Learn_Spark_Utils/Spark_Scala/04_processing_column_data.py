# Databricks notebook source
# MAGIC %md
# MAGIC # Processing Column Data
# MAGIC
# MAGIC As part of this module we will explore the functions available under `org.apache.spark.sql.functions` to derive new values from existing column values with in a Data Frame.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Introduction to Pre-defined Functions
# MAGIC
# MAGIC We typically process data in the columns using functions in `org.apache.spark.sql.functions`. Let us understand details about these functions in detail as part of this module.
# MAGIC * Let us recap about Functions or APIs to process Data Frames.
# MAGIC   * Projection - `select` or `withColumn`
# MAGIC   * Filtering - `filter` or `where`
# MAGIC   * Grouping data by key and perform aggregations - `groupBy`
# MAGIC   * Sorting data - `sort` or `orderBy` 
# MAGIC * We can pass column names or literals or expressions to all the Data Frame APIs.
# MAGIC * Expressions include arithmetic operations, transformations using functions from `org.apache.spark.sql.functions`.
# MAGIC * There are approximately 300 functions under `org.apache.spark.sql.functions`.
# MAGIC * We will talk about some of the important functions used for String Manipulation, Date Manipulation etc.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    appName("Processing Column Data").
    master("yarn").
    getOrCreate

# COMMAND ----------

spark

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Dummy Data Frame
# MAGIC Let us go ahead and create dummy data from to explore functions.

# COMMAND ----------

val l = List("X")

# COMMAND ----------

// Oracle dual (view)
// dual - dummy CHAR(1)
// "X" - One record

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC Once Data Frame is created, we can use to understand how to use functions. For example, to get current date, we can run `df.select(current_date()).show()`.
# MAGIC
# MAGIC It is similar to Oracle Query `SELECT sysdate FROM dual`

# COMMAND ----------

val l = List("X")
val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC Here is another example of creating Data Frame using collection of employees. We will be using this Data Frame to explore all the important functions to process column data in detail.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

employees.size

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Categories of Functions
# MAGIC
# MAGIC There are approximately 300 functions under org.apache.spark.sql.functions. At a higher level they can be grouped into a few categories.
# MAGIC * String Manipulation Functions
# MAGIC   * Case Conversion - `lower`,  `upper`
# MAGIC   * Getting Length -  `length`
# MAGIC   * Extracting substrings - `substring`, `split`
# MAGIC   * Trimming - `trim`, `ltrim`, `rtrim`
# MAGIC   * Padding - `lpad`, `rpad`
# MAGIC   * Concatenating string - `concat`
# MAGIC * Date Manipulation Functions
# MAGIC   * Getting current date and time - `current_date`, `current_timestamp`
# MAGIC   * Date Arithmetic - `date_add`, `date_sub`, `datediff`, `months_between`, `add_months`, `next_day`
# MAGIC   * Beginning and Ending Date or Time - `last_day`, `trunc`, `date_trunc`
# MAGIC   * Formatting Date - `date_format`
# MAGIC   * Extracting Information - `dayofyear`, `dayofmonth`, `dayofweek`, `year`, `month`
# MAGIC * Aggregate Functions
# MAGIC   * `count`, `countDistinct`
# MAGIC   * `sum`, `avg`
# MAGIC   * `min`, `max`
# MAGIC * Other Functions - We will explore depending on the use cases.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Special Functions - col and lit
# MAGIC
# MAGIC Let us understand special functions such as col and lit.
# MAGIC
# MAGIC * First let us create Data Frame for demo purposes.

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------

# MAGIC %md
# MAGIC * For Data Frame APIs such as `select`, `groupBy`, `orderBy` etc we can pass column names as strings.
# MAGIC

# COMMAND ----------

// to use operators such as $ in place of functions like col


# COMMAND ----------



# COMMAND ----------

// Alternative using col function
// $ is shorthand operator for col from implicits


# COMMAND ----------

// Alternative by passing column names as strings.


# COMMAND ----------

// We have to pass all the column names as strings or column type (using col or $)
// This will not work


# COMMAND ----------

# MAGIC %md
# MAGIC * If there are no transformations on any column in any function then we should be able to pass all column names as strings.
# MAGIC * If not we need to pass all columns as type column by using col function or its shorthand operator $.

# COMMAND ----------

// Passing columns as part of groupBy

# COMMAND ----------

// Passing columns as part of orderBy or sort

# COMMAND ----------

# MAGIC %md
# MAGIC * However, if we want to apply any transformation using functions then passing column names as strings to some of the functions will not suffice. We have to pass them as column type. 

# COMMAND ----------

import org.apache.spark.sql.functions.upper

# COMMAND ----------

//This code fails as upper is not valid function on string
employeesDF.
    select(upper("first_name")).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC * `col` is the function which will convert column name from string type to **Column** type. We can also refer column names as **Column** type using Data Frame name.
# MAGIC

# COMMAND ----------



# COMMAND ----------

// Using col and upper


# COMMAND ----------

// Alternate using $ and upper


# COMMAND ----------

// Using as part of groupBy


# COMMAND ----------

// Using as part of orderBy


# COMMAND ----------

// Alternative - we can also refer column names using Data Frame like this


# COMMAND ----------

# MAGIC %md
# MAGIC * Sometimes, we want to add a literal to the column values. For example, we might want to concatenate first_name and last_name with separated by comma and space in between.

# COMMAND ----------

// Below approaches fail.

# COMMAND ----------

import org.apache.spark.sql.functions.concat

# COMMAND ----------

employeesDF.
    select(concat($"first_name", ", ", $"last_name")).
    show()

# COMMAND ----------

// Same as above
employeesDF.
    select(concat(col("first_name"), ", ", col("last_name"))).
    show

# COMMAND ----------

// Referring columns using Data Frame
employeesDF.
    select(concat(employeesDF("first_name"), ", ", employeesDF("last_name"))).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC * If we pass the literals directly in the form of string or numeric type, then it will fail. We have to convert literals to column type by using `lit` function.
# MAGIC

# COMMAND ----------

// Using lit to use literals to derive new expressions

# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - Case Conversion and Length
# MAGIC Let us check the functions which can convert the case of the column values which are of type string and also get the length.
# MAGIC * Convert all the alphabetic characters in a string to **uppercase** - `upper`
# MAGIC * Convert all the alphabetic characters in a string to **lowercase** - `lower`
# MAGIC * Convert first character in a string to **uppercase** - `initcap`
# MAGIC * Get **number of characters in a string** - `length`
# MAGIC * All the 4 functions take column type argument.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform tasks to understand the behavior of case conversion functions and length.
# MAGIC
# MAGIC * Use employees data and create a Data Frame.
# MAGIC * Apply all 4 functions on **nationality** and see the results.

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - substring
# MAGIC
# MAGIC Let us understand how we can extract substrings using function  `substring`.
# MAGIC * If we are processing **fixed length columns** then we use `substring` to extract the information.
# MAGIC * Here are some of the examples for **fixed length columns** and the use cases for which we typically extract information..
# MAGIC  * 9 Digit Social Security Number. We typically extract last 4 digits and provide it to the tele verification applications..
# MAGIC  * 16 Digit Credit Card Number. We typically use first 4 digit number to identify Credit Card Provider and last 4 digits for the purpose of tele verification.
# MAGIC  * Data coming from MainFrames systems are quite often fixed length. We might have to extract the information and store in multiple columns.
# MAGIC * `substring` function takes 3 arguments, **column**, **position**, **length**. We can also provide position from the end by passing negative value.
# MAGIC

# COMMAND ----------

val s = "Hello World"

# COMMAND ----------

s.substring(0, 5)

# COMMAND ----------

s.substring(1, 4)

# COMMAND ----------

val l = List("X")

# COMMAND ----------

val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to extract information from fixed length strings.
# MAGIC * Create a list for employees with name, ssn and phone_number.
# MAGIC * SSN Format **3 2 4** - Fixed Length with 9 digits
# MAGIC * Phone Number Format - Country Code is variable and remaining phone number have 10 digits:
# MAGIC   * Country Code - one to 3 digits
# MAGIC   * Area Code - 3 digits
# MAGIC   * Phone Number Prefix - 3 digits
# MAGIC   * Phone Number Remaining - 4 digits
# MAGIC   * All the 4 parts are separated by spaces
# MAGIC * Create a Dataframe with column names name, ssn and phone_number
# MAGIC * Extract last 4 digits from the phone number.
# MAGIC * Extract last 4 digits from SSN.

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - split
# MAGIC Let us understand how we can extract substrings using  `split`.
# MAGIC * If we are processing **variable length columns** with **delimiter** then we use `split` to extract the information.
# MAGIC * Here are some of the examples for **variable length columns** and the use cases for which we typically extract information.
# MAGIC   * Address where we store House Number, Street Name, City, State and Zip Code comma separated. We might want to extract City and State for demographics reports.
# MAGIC * `split` takes 2 arguments, **column** and **delimiter**.
# MAGIC * `split` convert each string into array and we can access the elements using index.

# COMMAND ----------

val l = List("X")

# COMMAND ----------

val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Most of the problems can be solved either by using `substring` or `split`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC Let us perform few tasks to extract information from fixed length strings as well as delimited variable length strings.
# MAGIC * Create a list for employees with name, ssn and phone_number.
# MAGIC * SSN Format **3 2 4** - Fixed Length with 9 digits
# MAGIC * Phone Number Format - Country Code is variable and remaining phone number have 10 digits:
# MAGIC   * Country Code - one to 3 digits
# MAGIC   * Area Code - 3 digits
# MAGIC   * Phone Number Prefix - 3 digits
# MAGIC   * Phone Number Remaining - 4 digits
# MAGIC   * All the 4 parts are separated by spaces
# MAGIC * Create a Dataframe with column names name, ssn and phone_number
# MAGIC * Extract area code and last 4 digits from the phone number.
# MAGIC * Extract last 4 digits from SSN.

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - Concatenating of Strings
# MAGIC Let us understand how to concatenate strings using `concat` function.
# MAGIC * We can pass a variable number of strings to `concat` function.
# MAGIC * It will return one string concatenating all the strings.
# MAGIC * If we have to concatenate literal in between then we have to use `lit` function.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to understand more about 
# MAGIC `concat` function.
# MAGIC * Let’s create a Data Frame and explore `concat` function.

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------

employeesDF.show

# COMMAND ----------

# MAGIC %md
# MAGIC * Create a new column by name **full_name** concatenating **first_name** and **last_name**.

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Improvise by adding a **comma followed by a space** in between **first_name** and **last_name**.
# MAGIC

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - Padding
# MAGIC Let us understand how to pad characters at the beginning or at the end of strings.
# MAGIC * We typically pad characters to build fixed length values or records.
# MAGIC * Fixed length values or records are extensively used in Mainframes based systems.
# MAGIC * Length of each and every field in fixed length records is predetermined and if the value of the field is less than the predetermined length then we pad with a standard character.
# MAGIC * In terms of numeric fields we pad with zero on the leading or left side. For non numeric fields, we pad with some standard character on leading or trailing side.
# MAGIC * We use `lpad` to pad a string with a specific character on leading or left side and `rpad` to pad on trailing or right side.
# MAGIC * Both lpad and rpad, take 3 arguments - column or expression, desired length and the character need to be padded.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform simple tasks to understand the syntax of `lpad` or `rpad`.
# MAGIC * Create a Dataframe with single value and single column.
# MAGIC * Apply `lpad` to pad with - to Hello to make it 10 characters.

# COMMAND ----------

val l = List("X")

# COMMAND ----------

val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform the task to understand how to use pad functions to convert our data into fixed length records.
# MAGIC
# MAGIC * Let’s take the **employees** Dataframe

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, 
                      "united states", "+1 123 456 7890", "123 45 6789"
                     ),
                     (2, "Henry", "Ford", 1250.0, 
                      "India", "+91 234 567 8901", "456 78 9123"
                     ),
                     (3, "Nick", "Junior", 750.0, 
                      "united KINGDOM", "+44 111 111 1111", "222 33 4444"
                     ),
                     (4, "Bill", "Gomes", 1500.0, 
                      "AUSTRALIA", "+61 987 654 3210", "789 12 6118"
                     )
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", "first_name",
         "last_name", "salary",
         "nationality", "phone_number",
         "ssn"
        )

# COMMAND ----------

# MAGIC %md
# MAGIC * Use **pad** functions to convert each of the field into fixed length and concatenate. Here are the details for each of the fields.
# MAGIC   * Length of the employee_id should be 5 characters and should be padded with zero.
# MAGIC   * Length of first_name and last_name should be 10 characters and should be padded with - on the right side.
# MAGIC   * Length of salary should be 10 characters and should be padded with zero.
# MAGIC   * Length of the nationality should be 15 characters and should be padded with - on the right side.
# MAGIC   * Length of the phone_number should be 17 characters and should be padded with - on the right side.
# MAGIC   * Length of the ssn can be left as is. It is 11 characters.
# MAGIC * Create a new Dataframe **empFixedDF** with column name **employee**. Preview the data by disabling truncate.
# MAGIC

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## String Manipulation - Trimming
# MAGIC Let us understand how to trim unwanted leading and trailing characters around a string.
# MAGIC * We typically use trimming to remove unnecessary characters from fixed length records.
# MAGIC * Fixed length records are extensively used in Mainframes and we might have to process it using Spark.
# MAGIC * As part of processing we might want to remove leading or trailing characters such as 0 in case of numeric types and space or some standard character in case of alphanumeric types.
# MAGIC * As of now Spark trim functions take the column as argument and remove leading or trailing spaces.
# MAGIC * Trim spaces towards left - `ltrim`
# MAGIC * Trim spaces towards right - `rtrim`
# MAGIC * Trim spaces on both sides - `trim`

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us understand how to use trim functions to remove spaces on left or right or both.
# MAGIC * Create a Dataframe with one column and one record.
# MAGIC * Apply trim functions to trim spaces.

# COMMAND ----------

import org.apache.spark.sql.functions.{ltrim, rtrim, trim}

# COMMAND ----------

val l = List("   Hello.    ")

# COMMAND ----------

val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Date and Time - Overview
# MAGIC Let us get an overview about Date and Time using available functions.
# MAGIC * We can use `current_date` to get today’s server date. 
# MAGIC   * Date will be returned using **yyyy-MM-dd** format.
# MAGIC * We can use `current_timestamp` to get current server time. 
# MAGIC   * Timestamp will be returned using **yyyy-MM-dd HH:mm:ss:SSS** format.
# MAGIC   * Hours will be by default in 24 hour format.
# MAGIC

# COMMAND ----------

val l = List("X")

# COMMAND ----------

val df = l.toDF("dummy")

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Date and Time - Arithmetic
# MAGIC Let us perform Date and Time Arithmetic using relevant functions.
# MAGIC * Adding days to a date or timestamp - `date_add`
# MAGIC * Subtracting days from a date or timestamp - `date_sub`
# MAGIC * Getting difference between 2 dates or timestamps - `datediff`
# MAGIC * Getting a number of months between 2 dates or timestamps - `months_between`
# MAGIC * Adding months to a date or timestamp - `add_months`
# MAGIC * Getting next day from a given date - `next_day`
# MAGIC * All the functions are self explanatory. We can apply these on standard date or timestamp. All the functions return date even when applied on timestamp field.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform some tasks related to date arithmetic.
# MAGIC * Get help on each and every function first and understand what all arguments need to be passed.
# MAGIC * Create a Dataframe by name datetimesDF with columns date and time.

# COMMAND ----------

val datetimes = List(("2014-02-28", "2014-02-28 10:00:00.123"),
                     ("2016-02-29", "2016-02-29 08:08:08.999"),
                     ("2017-10-31", "2017-12-31 11:59:59.123"),
                     ("2019-11-30", "2019-08-31 00:00:00.000")
                    )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Add 10 days to both date and time values.
# MAGIC * Subtract 10 days from both date and time values.
# MAGIC * Get the difference between current_date and date values as well as current_timestamp and time values.
# MAGIC * Get the number of months between current_date and date values as well as current_timestamp and time values.
# MAGIC * Add 3 months to both date values as well as time values.
# MAGIC

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Date and Time - trunc and date_trunc
# MAGIC In Data Warehousing we quite often run to date reports such as week to date, month to date, year to date etc.
# MAGIC * We can use `trunc` or `date_trunc` for the same to get the beginning date of the week, month, current year etc by passing date or timestamp to it.
# MAGIC * We can use `trunc` to get beginning date of the month or year by passing date or timestamp to it - for example `trunc(current_date(), "MM")` will give the first of the current month.
# MAGIC * We can use `date_trunc` to get beginning date of the month or year as well as beginning time of the day or hour by passing timestamp to it.
# MAGIC   * Get beginning date based on month - `date_trunc("MM", current_timestamp())`
# MAGIC   * Get beginning time based on day - `date_trunc("DAY", current_timestamp())`

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to understand trunc and date_trunc in detail.
# MAGIC * Create a Dataframe by name datetimesDF with columns date and time.

# COMMAND ----------

val datetimes = List(("2014-02-28", "2014-02-28 10:00:00.123"),
                     ("2016-02-29", "2016-02-29 08:08:08.999"),
                     ("2017-10-31", "2017-12-31 11:59:59.123"),
                     ("2019-11-30", "2019-08-31 00:00:00.000")
                    )

# COMMAND ----------

val datetimesDF = datetimes.toDF("date", "time")

# COMMAND ----------

datetimesDF.show(truncate=false)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get beginning month date using date field and beginning year date using time field.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get beginning hour time using date and time field.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Date and Time - Extracting Information
# MAGIC
# MAGIC Let us understand how to extract information from dates or times using functions.
# MAGIC
# MAGIC * We can use date_format to extract the required information in a desired format from date or timestamp.
# MAGIC * There are also specific functions to extract year, month, day with in a week, a day with in a month, day with in a year etc.
# MAGIC
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to extract the information we need from date or timestamp.
# MAGIC
# MAGIC * Create a Dataframe by name datetimesDF with columns date and time.
# MAGIC

# COMMAND ----------

val datetimes = List(("2014-02-28", "2014-02-28 10:00:00.123"),
                     ("2016-02-29", "2016-02-29 08:08:08.999"),
                     ("2017-10-31", "2017-12-31 11:59:59.123"),
                     ("2019-11-30", "2019-08-31 00:00:00.000")
                    )

# COMMAND ----------

val datetimesDF = datetimes.toDF("date", "time")

# COMMAND ----------

datetimesDF.show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get year from fields date and time.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get one or two digit month from fields date and time.
# MAGIC

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get year and month in yyyyMM format from date and time.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get day with in a week, a day with in a month and day within a year from date and time.
# MAGIC

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get the information from time in yyyyMMddHHmmss format.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Dealing with Unix Timestamp
# MAGIC
# MAGIC Let us understand how to deal with Unix Timestamp in Spark.
# MAGIC
# MAGIC * It is an integer and started from January 1st 1970 Midnight UTC.
# MAGIC * Beginning time is also known as epoch and is incremented by 1 every second.
# MAGIC * We can convert Unix Timestamp to regular date or timestamp and vice versa.
# MAGIC * We can use `unix_timestamp` to convert regular date or timestamp to a unix timestamp value. For example `unix_timestamp(lit("2019-11-19 00:00:00"))`
# MAGIC * We can use `from_unixtime` to convert unix timestamp to regular date or timestamp. For example `from_unixtime(lit(1574101800))`
# MAGIC * We can also pass format to both the functions. 

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to understand how to deal with Unix Timestamp.
# MAGIC
# MAGIC *   Create a Dataframe by name datetimesDF with columns dateid, date and time.

# COMMAND ----------

val datetimes = List((20140228, "2014-02-28", "2014-02-28 10:00:00.123"),
                     (20160229, "2016-02-29", "2016-02-29 08:08:08.999"),
                     (20171031, "2017-10-31", "2017-12-31 11:59:59.123"),
                     (20191130, "2019-11-30", "2019-08-31 00:00:00.000")
                    )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get unix timestamp for dateid, date and time.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Create a Dataframe by name unixtimesDF with one column unixtime using 4 values. You can use the unix timestamp generated for time column in previous task.

# COMMAND ----------

val unixtimes = List(1393561800,
                     1456713488,
                     1514701799,
                     1567189800
                    )

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC * Get date in yyyyMMdd format and also complete timestamp.

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC As part of this module we have gone through list of functions that can be applied on top of columns for row level transformations.
# MAGIC
# MAGIC * There are approximately 300 pre-defined functions.
# MAGIC * Functions can be broadly categorized into String Manipulation Functions, Date Manipulation Functions, Numeric Functions etc.
# MAGIC * Typically when we read data from source, we get data in the form of strings and we need to apply functions to apply standardization rules, data type conversion, transformation rules etc.
# MAGIC * Most of these functions can be used while projection using `select`, `selectExpr`, `withColumn` etc as well as part of `filter` or `where`, `groupBy`, `orderBy` or `sort` etc.
# MAGIC * For `selectExpr` we need to use the functions using SQL Style syntax.
# MAGIC * There are special functions such as `col` and `lit`. `col` is used to pass column names as column type for some of the functions while `lit` is used to pass literals as values as part of expressions (eg: `concat($"first_name", lit(", "), $"last_name")`).