# Databricks notebook source
# MAGIC %md
# MAGIC # Basic Transformations
# MAGIC
# MAGIC ## Overview of Basic Transformations
# MAGIC
# MAGIC Let us define problem statements to learn more about Data Frame APIs. We will try to cover filtering, aggregations and sorting as part of solutions for these problem statements.
# MAGIC * Get total number of flights as well as number of flights which are delayed in departure and number of flights delayed in arrival. 
# MAGIC   * Output should contain 3 columns - **FlightCount**, **DepDelayedCount**, **ArrDelayedCount**
# MAGIC * Get number of flights which are delayed in departure and number of flights delayed in arrival for each day along with number of flights departed for each day. 
# MAGIC   * Output should contain 4 columns - **FlightDate**, **FlightCount**, **DepDelayedCount**, **ArrDelayedCount**
# MAGIC   * **FlightDate** should be of **YYYY-MM-dd** format.
# MAGIC   * Data should be **sorted** in ascending order by **flightDate**
# MAGIC * Get all the flights which are departed late but arrived early (**IsArrDelayed is NO**).
# MAGIC   * Output should contain - **FlightCRSDepTime**, **UniqueCarrier**, **FlightNum**, **Origin**, **Dest**, **DepDelay**, **ArrDelay**
# MAGIC   * **FlightCRSDepTime** need to be computed using **Year**, **Month**, **DayOfMonth**, **CRSDepTime**
# MAGIC   * **FlightCRSDepTime** should be displayed using **YYYY-MM-dd HH:mm** format.
# MAGIC   * Output should be sorted by **FlightCRSDepTime** and then by the difference between **DepDelay** and **ArrDelay**
# MAGIC   * Also get the count of such flights

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.

# COMMAND ----------

import org.apache.spark.sql.SparkSession

# COMMAND ----------

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    appName("Basic Transformations").
    master("yarn").
    getOrCreate

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Filtering
# MAGIC Let us understand few important details related to filtering before we get into the solution
# MAGIC * Filtering can be done either by using `filter` or `where`. These are like synonyms to each other.
# MAGIC * When it comes to the condition, we can either pass it in **SQL Style** or **Data Frame Style**.
# MAGIC * Example for SQL Style - `airlines.filter("IsArrDelayed = "YES"").show() or airlines.where("IsArrDelayed = "YES"").show()`
# MAGIC * Example for Data Frame Style - `airlines.filter(airlines["IsArrDelayed"] == "YES").show()` or `airlines.filter(airlines.IsArrDelayed == "YES").show()`. We can also use where instead of filter.
# MAGIC * Here are the other operations we can perform to filter the data - `!=`, `>`, `<`, `>=`, `<=`, `LIKE`, `BETWEEN` with `AND`
# MAGIC * If we have to validate against multiple columns then we need to use boolean operations such as `AND` and `OR`.
# MAGIC * If we have to compare each column value with multiple values then we can use the `IN` operator.
# MAGIC     

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform some tasks to understand filtering in detail. Solve all the problems by passing  conditions using both SQL Style as well as API Style.
# MAGIC
# MAGIC * Read the data for the month of 2008 January.

# COMMAND ----------

val airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlines_path)

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of flights which are departed late at origin and reach destination early or on time.
# MAGIC

# COMMAND ----------

airlines.
    filter("IsDepDelayed = 'YES' AND IsArrDelayed = 'NO'").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * API Style

# COMMAND ----------

import org.apache.spark.sql.functions.col

# COMMAND ----------

airlines.
    filter(col("IsDepDelayed") === "YES" and
           col("IsArrDelayed") === "NO"
          ).
    count

# COMMAND ----------

airlines.
    filter(airlines("IsDepDelayed") === "YES" and
           airlines("IsArrDelayed") === "NO"
          ).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of flights which are departed late from origin by more than 60 minutes.
# MAGIC

# COMMAND ----------

airlines.
    filter("DepDelay > 60").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC * API Style

# COMMAND ----------

import org.apache.spark.sql.functions.col

# COMMAND ----------

airlines.
    filter(col("DepDelay") > 60).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of flights which are departed early or on time but arrive late by at least 15 minutes.
# MAGIC

# COMMAND ----------

airlines.
    filter("IsDepDelayed = 'NO' AND ArrDelay >= 15").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * API Style

# COMMAND ----------

import org.apache.spark.sql.functions. col

# COMMAND ----------

airlines.
    filter(col("IsDepDelayed") === "NO" and col("ArrDelay") >= 15).
    count()

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of flights departed from following major airports - ORD, DFW, ATL, LAX, SFO.

# COMMAND ----------

airlines.count

# COMMAND ----------

airlines.
    filter("Origin IN ('ORD', 'DFW', 'ATL', 'LAX', 'SFO')").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * API Style

# COMMAND ----------

import org.apache.spark.sql.functions.col

# COMMAND ----------

airlines.
    filter(col("Origin").isin("ORD", "DFW", "ATL", "LAX", "SFO")).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Add a column FlightDate by using Year, Month and DayOfMonth. Format should be **yyyyMMdd**.
# MAGIC

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

# COMMAND ----------

airlines.
    withColumn("FlightDate",
                concat(col("Year"),
                       lpad(col("Month"), 2, "0"),
                       lpad(col("DayOfMonth"), 2, "0")
                      )
              ).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of flights departed late between 2008 January 1st to January 9th using FlightDate.
# MAGIC

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

# COMMAND ----------

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter("IsDepDelayed = 'YES' AND FlightDate LIKE '2008010%'").
    count

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

# COMMAND ----------

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter("""
           IsDepDelayed = "YES" AND 
           FlightDate BETWEEN 20080101 AND 20080109
          """).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * API Style

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

# COMMAND ----------

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter(col("IsDepDelayed") === "YES" and 
           (col("FlightDate") like ("2008010%"))
          ).
    count

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter(col("IsDepDelayed") === "YES" and 
           (col("FlightDate") between ("20080101", "20080109"))
          ).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Get number of flights departed late on Sundays.

# COMMAND ----------

val l = List("X")
val df = l.toDF("dummy")

# COMMAND ----------

import org.apache.spark.sql.functions.current_date

# COMMAND ----------

df.select(current_date).show

# COMMAND ----------

import org.apache.spark.sql.functions.date_format

# COMMAND ----------

df.select(current_date, date_format(current_date, "EE")).show

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad}

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter("""
           IsDepDelayed = "YES" AND 
           date_format(to_date(FlightDate, "yyyyMMdd"), "EEEE") = "Sunday"
           """).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * API Style

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

import org.apache.spark.sql.functions.{col, concat, lpad, date_format, to_date}

airlines.
    withColumn("FlightDate",
               concat(col("Year"),
                      lpad(col("Month"), 2, "0"),
                      lpad(col("DayOfMonth"), 2, "0")
                     )
              ).
    filter(col("IsDepDelayed") === "YES" and
           date_format(
               to_date($"FlightDate", "yyyyMMdd"), "EEEE"
           ) === "Sunday"
          ).
    count

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Aggregations
# MAGIC
# MAGIC Let us go through the details related to aggregation using Spark.
# MAGIC
# MAGIC * We can perform total aggregations directly on Dataframe or we can perform aggregations after grouping by a key(s).
# MAGIC * Here are the APIs which we typically use to group the data using a key.
# MAGIC   * groupBy
# MAGIC   * rollup
# MAGIC   * cube
# MAGIC * Here are the functions which we typically use to perform aggregations.
# MAGIC   * count
# MAGIC   * sum, avg
# MAGIC   * min, max
# MAGIC * If we want to provide aliases to the aggregated fields then we have to use `agg` after `groupBy`.
# MAGIC * Let us get the count of flights for each day for the month of 200801.

# COMMAND ----------

val airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlines_path)

# COMMAND ----------

import org.apache.spark.sql.functions.{concat, lpad, count, lit}

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

airlines.
    groupBy(concat($"year",
                   lpad($"Month", 2, "0"),
                   lpad($"DayOfMonth", 2, "0")
                  ).alias("FlightDate")
           ).
    agg(count(lit(1)).alias("FlightCount")).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Sorting
# MAGIC
# MAGIC Let us understand how to sort the data in a Data Frame.
# MAGIC * We can use `orderBy` or `sort` to sort the data.
# MAGIC * We can perform composite sorting by passing multiple columns or expressions.
# MAGIC * By default data is sorted in ascending order, we can change it to descending by applying `desc()` function on the column or expression.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 1
# MAGIC Get total number of flights as well as number of flights which are delayed in departure and number of flights delayed in arrival. 
# MAGIC * Output should contain 3 columns - **FlightCount**, **DepDelayedCount**, **ArrDelayedCount**
# MAGIC
# MAGIC ### Reading airlines data

# COMMAND ----------

val airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlines_path)

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get flights with delayed arrival

# COMMAND ----------

// SQL Style
airlines.filter("IsArrDelayed = 'YES'").show

# COMMAND ----------

// Data Frame Style
airlines.filter(airlines("IsArrDelayed") === "YES").show

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

airlines.filter($"IsArrDelayed" === "YES").show

# COMMAND ----------

# MAGIC %md
# MAGIC ### Get delayed counts

# COMMAND ----------

// Departure Delayed Count
airlines.
    filter(airlines("IsDepDelayed") === "YES").
    count

# COMMAND ----------

// Arrival Delayed Count
airlines.
    filter(airlines("IsArrDelayed") === "YES").
    count()

# COMMAND ----------

airlines.
    filter("IsDepDelayed = 'YES' OR IsArrDelayed = 'YES'").
    select("Year", "Month", "DayOfMonth", 
           "FlightNum", "IsDepDelayed", "IsArrDelayed"
          ).
    show

# COMMAND ----------

// Both Departure Delayed and Arrival Delayed
import org.apache.spark.sql.functions.{col, lit, count, sum, expr}

# COMMAND ----------

airlines.
    agg(count(lit(1)).alias("FlightCount"),
        sum(expr("CASE WHEN IsDepDelayed = 'YES' THEN 1 ELSE 0 END")).alias("DepDelayedCount"),
        sum(expr("CASE WHEN IsArrDelayed = 'YES' THEN 1 ELSE 0 END")).alias("ArrDelayedCount")
       ).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 2
# MAGIC
# MAGIC Get number of flights which are delayed in departure and number of flights delayed in arrival for each day along with number of flights departed for each day. 
# MAGIC
# MAGIC * Output should contain 4 columns - **FlightDate**, **FlightCount**, **DepDelayedCount**, **ArrDelayedCount**
# MAGIC * **FlightDate** should be of **YYYY-MM-dd** format.
# MAGIC *   Data should be **sorted** in ascending order by **flightDate**
# MAGIC
# MAGIC ### Grouping Data by Flight Date
# MAGIC

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat, lpad}

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

# MAGIC %md
# MAGIC * Example of `groupBy`. It should follow with `agg`. **If you run the below code, it will throw exception.**

# COMMAND ----------

airlines.
  groupBy(concat($"Year", lit("-"), 
                 lpad($"Month", 2, "0"), lit("-"), 
                 lpad($"DayOfMonth", 2, "0")).
          alias("FlightDate"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting Counts by FlightDate

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat, lpad, count}

airlines.
    groupBy(concat($"Year", lit("-"), 
                   lpad($"Month", 2, "0"), lit("-"), 
                   lpad($"DayOfMonth", 2, "0")).
            alias("FlightDate")).
    agg(count(lit(1)).alias("FlightCount")).
    show(31)

# COMMAND ----------

// Alternative to get the count with out using agg
// We will not be able to provide alias for aggregated fields
import org.apache.spark.sql.functions.{lit, concat, lpad}

# COMMAND ----------

airlines.
    groupBy(concat($"Year", lit("-"), 
                   lpad($"Month", 2, "0"), lit("-"), 
                   lpad($"DayOfMonth", 2, "0")).
            alias("FlightDate")).
    count.
    show(31)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting total as well as delayed counts for each day

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat, lpad, count, sum, expr}

# COMMAND ----------

airlines.
    groupBy(concat($"Year", lit("-"), 
                   lpad($"Month", 2, "0"), lit("-"), 
                   lpad($"DayOfMonth", 2, "0")).
            alias("FlightDate")).
    agg(count(lit(1)).alias("FlightCount"),
        sum(expr("CASE WHEN IsDepDelayed = 'YES' THEN 1 ELSE 0 END")).alias("DepDelayedCount"),
        sum(expr("CASE WHEN IsArrDelayed = 'YES' THEN 1 ELSE 0 END")).alias("ArrDelayedCount")
       ).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sorting Data By FlightDate

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat, lpad, sum, expr}

# COMMAND ----------

airlines.
    groupBy(concat($"Year", lit("-"), 
                   lpad($"Month", 2, "0"), lit("-"), 
                   lpad($"DayOfMonth", 2, "0")).
            alias("FlightDate")).
    agg(count(lit(1)).alias("FlightCount"),
        sum(expr("CASE WHEN IsDepDelayed = 'YES' THEN 1 ELSE 0 END")).alias("DepDelayedCount"),
        sum(expr("CASE WHEN IsArrDelayed = 'YES' THEN 1 ELSE 0 END")).alias("ArrDelayedCount")
       ).
    orderBy("FlightDate").
    show(31)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sorting Data in descending order by count

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat, lpad, sum, expr, col}

# COMMAND ----------

airlines.
    groupBy(concat($"Year", lit("-"), 
                   lpad($"Month", 2, "0"), lit("-"), 
                   lpad($"DayOfMonth", 2, "0")).
            alias("FlightDate")).
    agg(count(lit(1)).alias("FlightCount"),
        sum(expr("CASE WHEN IsDepDelayed = 'YES' THEN 1 ELSE 0 END")).alias("DepDelayedCount"),
        sum(expr("CASE WHEN IsArrDelayed = 'YES' THEN 1 ELSE 0 END")).alias("ArrDelayedCount")
       ).
    orderBy(col("FlightCount").desc).
    show(31)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 3
# MAGIC Get all the flights which are departed late but arrived early (**IsArrDelayed is NO**).
# MAGIC * Output should contain - **FlightCRSDepTime**, **UniqueCarrier**, **FlightNum**, **Origin**, **Dest**, **DepDelay**, **ArrDelay**
# MAGIC * **FlightCRSDepTime** need to be computed using **Year**, **Month**, **DayOfMonth**, **CRSDepTime**
# MAGIC * **FlightCRSDepTime** should be displayed using **YYYY-MM-dd HH:mm** format.
# MAGIC * Output should be sorted by **FlightCRSDepTime** and then by the difference between **DepDelay** and **ArrDelay**
# MAGIC * Also get the count of such flights
# MAGIC

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "CRSDepTime").show()

# COMMAND ----------

l = [(2008, 1, 23, 700),
     (2008, 1, 10, 1855),
    ]

# COMMAND ----------

df = spark.createDataFrame(l, "Year INT, Month INT, DayOfMonth INT, DepTime INT")
df.show()

# COMMAND ----------

import org.apache.spark.sql.functions. substring
df.select(substring(col("DepTime"), -2, 2)).
    show()

# COMMAND ----------

df.select("DepTime", date_format(lpad("DepTime", 4, "0"), "HH:mm")).show()

# COMMAND ----------

help(substring)

# COMMAND ----------

df.select(substring(col("DepTime"), 1, length(col("DepTime").cast("string")))).
    show()

# COMMAND ----------

import org.apache.spark.sql.functions. lit, col, concat, lpad, sum, expr

flightsFiltered = airlines.
    filter("IsDepDelayed = "YES" AND IsArrDelayed = "NO"").
    select(concat("Year", lit("-"), 
                  lpad("Month", 2, "0"), lit("-"), 
                  lpad("DayOfMonth", 2, "0"), lit(" "),
                  lpad("CRSDepTime", 4, "0")
                 ).alias("FlightCRSDepTime"),
           "UniqueCarrier", "FlightNum", "Origin", 
           "Dest", "DepDelay", "ArrDelay"
          ).
    orderBy("FlightCRSDepTime", col("DepDelay") - col("ArrDelay")).
    show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting Count

# COMMAND ----------

import org.apache.spark.sql.functions. lit, col, concat, lpad, sum, expr

flightsFiltered = airlines.
    filter("IsDepDelayed = "YES" AND IsArrDelayed = "NO"").
    select(concat("Year", lit("-"), 
                  lpad("Month", 2, "0"), lit("-"), 
                  lpad("DayOfMonth", 2, "0"), lit(" "),
                  lpad("CRSDepTime", 4, "0")
                 ).alias("FlightCRSDepTime"),
           "UniqueCarrier", "FlightNum", "Origin", 
           "Dest", "DepDelay", "ArrDelay"
          ).
    count()

flightsFiltered

# COMMAND ----------

