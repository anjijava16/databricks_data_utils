# Databricks notebook source
# MAGIC %md
# MAGIC # Data Processing - Overview
# MAGIC
# MAGIC ## Pre-requisites and Module Introduction
# MAGIC
# MAGIC Let us understand prerequisites before getting into the module.
# MAGIC * Good understanding of Data Processing using Python.
# MAGIC * Data Processing Life Cycle
# MAGIC   * Reading Data from files
# MAGIC   * Processing Data using APIs
# MAGIC   * Writing Processed Data back to files
# MAGIC * We can also use Databases as sources and sinks. It will be covered at a later point in time.
# MAGIC * We can also read data in streaming fashion which is out of the scope of this course.
# MAGIC
# MAGIC
# MAGIC We will get an overview of the Data Processing Life Cycle by the end of the module.
# MAGIC * Read airlines data from the file.
# MAGIC * Preview the schema and data to understand the characteristics of the data.
# MAGIC * Get an overview of Data Frame APIs as well as functions used to process the data.
# MAGIC * Check if there are any duplicates in the data.
# MAGIC * Get an overview of how to write data in Data Frames to Files using File Formats such as Parquet using Compression.
# MAGIC * Reorganize the data by month with different file format and using partitioning strategy.
# MAGIC * We will deep dive into Data Frame APIs to process the data in subsequent modules.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start Spark Context using SparkSession.
# MAGIC
# MAGIC * `SparkSession` is a class that is part of `pyspark.sql` package.
# MAGIC * It is a wrapper on top of Spark Context.
# MAGIC * When Spark application is submitted using `spark-submit` or `spark-shell` or `pyspark`, a web service called as Spark Context will be started.
# MAGIC * Spark Context maintains the context of all the jobs that are submitted until it is killed.
# MAGIC * `SparkSession` is nothing but wrapper on top of Spark Context.
# MAGIC * We need to first create SparkSession object with any name. But typically we use `spark`. Once it is created, several APIs will be exposed including `read`.
# MAGIC * We need to at least set Application Name and also specify the execution mode in which Spark Context should run while creating `SparkSession` object.
# MAGIC * We can use `appName` to specify name for the application and `master` to specify the execution mode.
# MAGIC * Below is the sample code snippet which will start the Spark Session object for us.

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "12903").
    appName("Data Processing - Overview").
    master("yarn").
    getOrCreate

# COMMAND ----------

spark

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Spark read APIs
# MAGIC
# MAGIC Let us get the overview of Spark read APIs to read files of different formats.
# MAGIC
# MAGIC * `spark` has a bunch of APIs to read data from files of different formats.
# MAGIC * All APIs are exposed under `spark.read`
# MAGIC   * `text` - to read single column data from text files as well as reading each of the whole text file as one record.
# MAGIC   * `csv`- to read text files with delimiters. Default is a comma, but we can use other delimiters as well.
# MAGIC   * `json` - to read data from JSON files
# MAGIC   * `orc` - to read data from ORC files
# MAGIC   * `parquet` - to read data from Parquet files.
# MAGIC   * We can also read data from other file formats by plugging in and by using `spark.read.format`
# MAGIC * We can also pass options based on the file formats.
# MAGIC   * `inferSchema` - to infer the data types of the columns based on the data.
# MAGIC   * `header` - to use header to get the column names in case of text files.
# MAGIC   * `schema` - to explicitly specify the schema.
# MAGIC * We can get the help on APIs like `spark.read.csv` using `help(spark.read.csv)`.
# MAGIC * Reading delimited data from text files.

# COMMAND ----------

spark.
    read.
    schema("""order_id INT, 
              order_date STRING, 
              order_customer_id INT, 
              order_status STRING
           """
          ).
    csv("/public/retail_db/orders").
    show

# COMMAND ----------

# MAGIC %md
# MAGIC * Reading JSON data from text files. We can infer schema from the data as each JSON object contain both column name and value.
# MAGIC * Example for JSON
# MAGIC
# MAGIC ```
# MAGIC { "order_id": 1, "order_date": "2013-07-25 00:00:00.0", "order_customer_id": 12345, "order_status": "COMPLETE" }
# MAGIC ```

# COMMAND ----------

spark.
    read.
    json("/public/retail_db_json/orders").
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Understand airlines data
# MAGIC Let us read one of the files and understand more about the data to determine right API with right options to process data later.
# MAGIC * Our airlines data is in text file format.
# MAGIC * We can use `spark.read.text` on one of the files to preview the data and understand the following
# MAGIC   * Whether header is present in files or not.
# MAGIC   * Field Delimiter that is being used.
# MAGIC * Once we determine details about header and field delimiter we can use `spark.read.csv` with appropriate options to read the data.

# COMMAND ----------

val airlines = spark.read.
    text("/public/airlines_all/airlines/part-00000")

# COMMAND ----------

airlines.show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC * Data have header and each field is delimited by a comma.
# MAGIC
# MAGIC ## Inferring Schema
# MAGIC
# MAGIC Let us understand how we can quickly get schema using one file and apply on other files.
# MAGIC * We can pass the file name pattern to `spark.read.csv` and read all the data in files under **hdfs://public/airlines_all/airlines** into Data Frame.
# MAGIC * We can use options such as `header` and `inferSchema` to assign names and data types.
# MAGIC * However `inferSchema` will end up going through the entire data to assign schema. We can use samplingRatio to process fraction of data and then infer the schema.
# MAGIC * In case if the data in all the files have similar structure, we should be able to get the schema using one file and then apply it on others.
# MAGIC * In our airlines data schema is consistent across all the files and hence we should be able to get the schema by going through one file and apply on the entire dataset.

# COMMAND ----------

val airlines_part_00000 = spark.
    read.
    option("header", "true").
    option("inferSchema", "true").
    csv("/public/airlines_all/airlines/part-00000")

# COMMAND ----------

airlines_part_00000.show(false)

# COMMAND ----------

airlines_part_00000.printSchema

# COMMAND ----------

val airlines_schema = spark.
    read.
    option("header", "true").
    option("inferSchema", "true").
    csv("/public/airlines_all/airlines/part-00000").
    schema

# COMMAND ----------

val airlines = spark.
    read.
    option("header", "true").
    schema(airlines_schema).
    csv("/public/airlines_all/airlines/part*")

# COMMAND ----------

airlines.count

# COMMAND ----------

# MAGIC %md
# MAGIC ## Previewing airlines data
# MAGIC Let us preview the airlines data to understand more about it.
# MAGIC * As we have too many files, we will just process one file and preview the data.
# MAGIC * File Name: **hdfs://public/airlines_all/airlines/part-00000**
# MAGIC * `spark.read.csv` will create a variable of type Data Frame.
# MAGIC
# MAGIC

# COMMAND ----------

val airlines_schema = spark.
    read.
    option("header", "true").
    option("inferSchema", "true").
    csv("/public/airlines_all/airlines/part-00000").
    schema

# COMMAND ----------

val airlines = spark.
    read.
    option("header", "true").
    schema(airlines_schema).
    csv("/public/airlines_all/airlines/part*")

# COMMAND ----------

# MAGIC %md
# MAGIC A Data Frame will have structure or schema.
# MAGIC
# MAGIC * We can print the schema using `airlines.printSchema()`
# MAGIC * We can preview the data using `airlines.show()`. By default it shows 20 records and some of the column values might be truncated for readability purpose.
# MAGIC * We can review the details of show by using `help(airlines.show)`
# MAGIC * We can pass custom number of records and say `truncate=False` to show complete information of all the records requested. It will facilitate us to preview all columns with desired number of records.
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

airlines.show(100, false)

# COMMAND ----------

# MAGIC %md
# MAGIC * We can get the number of records or rows in a Data Frame using `airlines.count()`
# MAGIC * In Databricks Notebook, we can use `display` to preview the data using Visualization feature
# MAGIC * We can perform all kinds of standard transformations on our data. We need to have good knowledge of functions on Data Frames as well as functions on columns to apply all standard transformations.
# MAGIC * Let us also validate if there are duplicates in our data, if yes we will remove duplicates while reorganizing the data later.
# MAGIC

# COMMAND ----------

val airlines_schema = spark.
    read.
    option("header", "true").
    option("inferSchema", "true").
    csv("/public/airlines_all/airlines/part-00000").
    schema

# COMMAND ----------

val airlines = spark.
    read.
    option("header", "true").
    schema(airlines_schema).
    csv("/public/airlines_all/airlines/part*")

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

airlines.show

# COMMAND ----------

airlines.show(100, false)

# COMMAND ----------

airlines.count

# COMMAND ----------

airlines.distinct.count

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Data Frame APIs
# MAGIC
# MAGIC Let us get an overview of Data Frame APIs to process data in Data Frames.
# MAGIC * Row Level Transformations or Projection of Data can be done using `select`, `selectExpr`, `withColumn`, `drop` on Data Frame.
# MAGIC * We typically apply functions from `pyspark.sql.functions` on columns using `select` and `withColumn`
# MAGIC * Filtering is typically done either by using `filter` or `where` on Data Frame.
# MAGIC * We can pass the condition to `filter` or `where` either by using SQL Style or Programming Language Style.
# MAGIC * Global Aggregations can be performed directly on the Data Frame.
# MAGIC * By Key or Grouping Aggregations are typically performed using `groupBy` and then aggregate functions using `agg`
# MAGIC * We can sort the data in Data Frame using `sort` or `orderBy`
# MAGIC * We will talk about Window Functions later. We can use use Window Functions for some advanced Aggregations and Ranking.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us understand how to project the data using different options such as `select`, `selectExpr`, `withColumn`, `drop.`
# MAGIC
# MAGIC * Create Dataframe **employees** using Collection

# COMMAND ----------

val employees = List((1, "Scott", "Tiger", 1000.0, "united states"),
                     (2, "Henry", "Ford", 1250.0, "India"),
                     (3, "Nick", "Junior", 750.0, "united KINGDOM"),
                     (4, "Bill", "Gomes", 1500.0, "AUSTRALIA")
                    )

# COMMAND ----------

val employeesDF = employees.
    toDF("employee_id", 
         "first_name", 
         "last_name", 
         "salary", 
         "nationality"
        )

# COMMAND ----------

employeesDF.printSchema

# COMMAND ----------

employeesDF.show

# COMMAND ----------

# MAGIC %md
# MAGIC * Project employee first name and last name.
# MAGIC

# COMMAND ----------

employeesDF.
    select("first_name", "last_name").
    show

# COMMAND ----------

# MAGIC %md
# MAGIC * Project all the fields except for Nationality

# COMMAND ----------

employeesDF.
    drop("nationality").
    show

# COMMAND ----------

# MAGIC %md
# MAGIC **We will explore most of the APIs to process data in Data Frames as we get into the data processing at a later point in time**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Functions
# MAGIC
# MAGIC Let us get an overview of different functions that are available to process data in columns.
# MAGIC * While Data Frame APIs work on the Data Frame, at times we might want to apply functions on column values.
# MAGIC * Functions to process column values are available under `pyspark.sql.functions`. These are typically used in select or withColumn on top of Data Frame.
# MAGIC * There are approximately 300 pre-defined functions available for us.
# MAGIC * Some of the important functions can be broadly categorized into String Manipulation, Date Manipulation, Numeric Functions and Aggregate Functions.
# MAGIC * String Manipulation Functions
# MAGIC   * Concatenating Strings - `concat`
# MAGIC   * Getting Length - `length`
# MAGIC   * Trimming Strings - `trim`,` rtrim`, `ltrim`
# MAGIC   * Padding Strings - `lpad`, `rpad`
# MAGIC   * Extracting Strings - `split`, `substring`
# MAGIC * Date Manipulation Functions
# MAGIC   * Date Arithmetic - `date_add`, `date_sub`, `datediff`, `add_months`
# MAGIC   * Date Extraction - `dayofmonth`, `month`, `year`
# MAGIC   * Get beginning period - `trunc`, `date_trunc`
# MAGIC * Numeric Functions - `abs`, `greatest`
# MAGIC * Aggregate Functions - `sum`, `min`, `max`

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC Let us perform a task to understand how functions are typically used.
# MAGIC
# MAGIC * Project full name by concatenating first name and last name along with other fields excluding first name and last name.

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, concat}

employeesDF.
    withColumn("full_name", concat($"first_name", lit(", "), $"last_name")).
    drop("first_name", "last_name").
    show

# COMMAND ----------

employeesDF.
    select($"employee_id",
           concat($"first_name", lit(", "), $"last_name").alias("full_name"),
           $"salary",
           $"nationality"
          ).
    show

# COMMAND ----------

employeesDF.
    selectExpr("employee_id",
               "concat(first_name, ', ', last_name) AS full_name",
               "salary",
               "nationality"
              ).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC **We will explore most of the functions as we get into the data processing at a later point in time**

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Spark Write APIs
# MAGIC
# MAGIC Let us understand how we can write Data Frames to different file formats.
# MAGIC * All the batch write APIs are grouped under write which is exposed to Data Frame objects.
# MAGIC * All APIs are exposed under spark.read
# MAGIC   * `text` - to write single column data to text files.
# MAGIC   * `csv` - to write to text files with delimiters. Default is a comma, but we can use other delimiters as well.
# MAGIC   * `json` - to write data to JSON files
# MAGIC   * `orc` - to write data to ORC files
# MAGIC   * `parquet` - to write data to Parquet files.
# MAGIC * We can also write data to other file formats by plugging in and by using `write.format`, for example **avro**
# MAGIC * We can use options based on the type using which we are writing the Data Frame to.
# MAGIC   * `compression` - Compression codec (`gzip`, `snappy` etc)
# MAGIC   * `sep` - to specify delimiters while writing into text files using **csv**
# MAGIC * We can `overwrite` the directories or `append` to existing directories using `mode`
# MAGIC * Create copy of orders data in **parquet** file format with no compression. If the folder already exists overwrite it. Target Location: **/user/[YOUR_USER_NAME]/retail_db/orders**
# MAGIC * When you pass options, if there are typos then options will be ignored rather than failing. Be careful and make sure that output is validated.
# MAGIC * By default the number of files in the output directory is equal to number of tasks that are used to process the data in the last stage. However, we might want to control number of files so that we don"t run into too many small files issue.
# MAGIC * We can control number of files by using `coalesce`. It has to be invoked on top of Data Frame before invoking `write`.

# COMMAND ----------

val orders = spark.
    read.
    schema("""order_id INT, 
              order_date STRING, 
              order_customer_id INT, 
              order_status STRING
           """
          ).
    csv("/public/retail_db/orders")

# COMMAND ----------

val username = System.getProperty("user.name")

orders.
    write.
    mode("overwrite").
    option("compression", "none").
    parquet(s"/user/${username}/retail_db/orders")

# COMMAND ----------

// Alternative approach - using format
val username = System.getProperty("user.name")

orders.
    write.
    mode("overwrite").
    option("compression", "none").
    format("parquet").
    save(s"/user/${username}/retail_db/orders")

# COMMAND ----------

import sys.process._

val username = System.getProperty("user.name")

s"hdfs dfs -ls /user/${username}/retail_db/orders" !

// File extension should not contain compression algorithms such as snappy.

# COMMAND ----------

# MAGIC %md
# MAGIC * Read order_items data from **/public/retail_db_json/order_items** and write it to pipe delimited files with gzip compression. Target Location: **/user/[YOUR_USER_NAME]/retail_db/order_items**. Make sure to validate.
# MAGIC * Ignore the error if the target location already exists. Also make sure to write into only one file. We can use `coalesce` for it. 
# MAGIC
# MAGIC **`coalesce` will be covered in detail at a later point in time**

# COMMAND ----------

val order_items = spark.
    read.
    json("/public/retail_db_json/order_items")

# COMMAND ----------

// Using format

val username = System.getProperty("user.name")

order_items.
    coalesce(1).
    write.
    mode("ignore").
    option("compression", "gzip").
    option("sep", "|").
    format("csv").
    save(s"/user/${username}/retail_db/order_items")

# COMMAND ----------

import sys.process._

val username = System.getProperty("user.name")

s"hdfs dfs -ls /user/${username}/retail_db/order_items" !

# COMMAND ----------

# MAGIC %md
# MAGIC ## Reorganizing airlines data
# MAGIC
# MAGIC Let us reorganize our airlines data to fewer files where data is compressed and also partitioned by Month.
# MAGIC * We have ~1920 files of ~64MB Size.
# MAGIC * Data is in the range of 1987 October and 2008 December (255 months)
# MAGIC * By default it uses ~1920 threads to process the data and it might end up with too many small files. We can avoid that by using repartition and then partition by the month.
# MAGIC * Here are the steps we are going to follow to partition by flight month and save the data to /user/[YOUR_USER_NAME]/airlines.
# MAGIC   * Read one file first and get the schema.
# MAGIC   * Read the entire data by applying the schema from the previous step.
# MAGIC   * Add additional column flightmonth using withColumn by using lpad on month column and concat functions. We need to do this as the month in our data set is of type integer and we want to pad with 0 for months till september to format it into YYYYMM.
# MAGIC   * Repartition the data into 255 based on the number of months using flightmonth
# MAGIC   * Partition the data by partitionBy while writing the data to the target location.
# MAGIC   * We will use parquet file format which will automatically compresses data using Snappy algorithm.
# MAGIC  
# MAGIC **This process will take time, once it is done we will review the target location to which data is copied by partitioning using month**

# COMMAND ----------

spark.stop

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.dynamicAllocation.enabled", "false").
    config("spark.executor.instances", 40).
    appName("Data Processing - Overview").
    master("yarn").
    getOrCreate

# COMMAND ----------

spark

# COMMAND ----------

import org.apache.spark.sql.functions. {concat, lpad}

val airlines_schema = spark.read.
    option("header", "true").
    option("inferSchema", "true").
    csv("/public/airlines_all/airlines/part-00000").
    schema

# COMMAND ----------

val airlines = spark.
    read.
    option("header", "true").
    schema(airlines_schema).
    csv("/public/airlines_all/airlines/part*")

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

airlines.show

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "255")

# COMMAND ----------

val username = System.getProperty("user.name")

airlines.
    distinct.
    withColumn("flightmonth", concat($"year", lpad($"month", 2, "0"))).
    repartition(255, $"flightmonth").
    write.
    mode("overwrite").
    partitionBy("flightmonth").
    format("parquet").
    save(s"/user/${username}/airlines-part")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Previewing reorganized data
# MAGIC Let us preview the data using reorganized data.
# MAGIC * We will use new location going forward - **/public/airlines_all/airlines-part**. Data is already copied into that location.
# MAGIC * We have partitioned data by month and stored in that location.
# MAGIC * Instead of using complete data set we will read the data from one partition **/public/airlines_all/airlines-part/flightmonth=200801**
# MAGIC * First let us create a DataFrame object by using `spark.read.parquet("/public/airlines_all/airlines-part/flightmonth=200801")` - let"s say airlines. 
# MAGIC * We can get the schema of the DataFrame using `airlines.printSchema()`
# MAGIC * Use `airlines.show()` or `airlines.show(100, truncate=False)`  to preview the data.
# MAGIC * We can also use `display(airlines)` to get airlines data in tabular format as part of Databricks Notebook.
# MAGIC * We can also use `airlines.describe().show()` to get some statistics about the Data Frame and `airlines.count()` to get the number of records in the DataFrame.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Analyze and Understand Data
# MAGIC Let us analyze and understand more about the data in detail using data of 2008 January.
# MAGIC * First let us read the data for the month of 2008 January.

# COMMAND ----------

val airlines_path = "/public/airlines_all/airlines-part/flightmonth=200801"

val airlines = spark.
    read.
    parquet(airlines_path)

# COMMAND ----------

airlines.count

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC * Get number of records - `airlines.count()`
# MAGIC * Go through the list of columns and understand the purpose of them.
# MAGIC   * Year
# MAGIC   * Month
# MAGIC   * DayOfMonth
# MAGIC   * CRSDepTime - Scheduled Departure Time
# MAGIC   * DepTime - Actual Departure Time.
# MAGIC   * DepDelay - Departure Delay in Minutes
# MAGIC   * CRSArrTime - Scheduled Arrival Time
# MAGIC   * ArrTime - Actual Arrival Time.
# MAGIC   * ArrDelay - Arrival Delay in Minutes.
# MAGIC   * UniqueCarrier - Carrier or Airlines
# MAGIC   * FlightNum - Flight Number
# MAGIC   * Distance - Distance between Origin and Destination
# MAGIC   * IsDepDelayed - this is set to yes for those flights where departure is delayed.
# MAGIC   * IsArrDelayed -- this is set to yes for those flights where arrival is delayed.
# MAGIC * Get number of unique origins

# COMMAND ----------

airlines.
    select("Origin").
    distinct.
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Get number of unique destinations

# COMMAND ----------

airlines.
    select("Dest").
    distinct.
    count

# COMMAND ----------

# MAGIC %md
# MAGIC * Get all unique carriers

# COMMAND ----------

airlines.
    select("UniqueCarrier").
    distinct.
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC Let us recap about key takeaways from this module.
# MAGIC * APIs to read the data from files into Data Frame.
# MAGIC * Previewing Schema and the data in Data Frame.
# MAGIC * Overview of Data Frame APIs and Functions
# MAGIC * Writing data from Data Frame into Files
# MAGIC * Reorganizing the airlines data by month
# MAGIC * Simple APIs to analyze the data.
# MAGIC Now it is time for us to deep dive into APIs to perform all the standard transformations as part of Data Processing.
# MAGIC