# Databricks notebook source
# MAGIC %md
# MAGIC # Getting Started
# MAGIC
# MAGIC ## Platforms to Practice
# MAGIC
# MAGIC Let us understand different platforms we can leverage to practice Apache Spark using Python.
# MAGIC
# MAGIC * Local Setup
# MAGIC * Databricks Platform
# MAGIC * Setting up your own cluster
# MAGIC * Cloud based labs
# MAGIC
# MAGIC
# MAGIC ## Setup Spark Locally - Ubuntu
# MAGIC
# MAGIC Let us setup Spark Locally on Ubuntu.
# MAGIC
# MAGIC * Install latest version of Anaconda
# MAGIC * Make sure Jupyter Notebook is setup and validated.
# MAGIC * Setup Spark and Validate.
# MAGIC * Setup Environment Variables to integrate Pyspark with Jupyter Notebook.
# MAGIC * Launch Jupyter Notebook using ` pyspark ` command.
# MAGIC * Setup PyCharm (IDE) for application development.
# MAGIC
# MAGIC
# MAGIC ## Setup Spark Locally - Mac
# MAGIC
# MAGIC ### Let us setup Spark Locally on Ubuntu.
# MAGIC
# MAGIC * Install latest version of Anaconda
# MAGIC * Make sure Jupyter Notebook is setup and validated.
# MAGIC * Setup Spark and Validate.
# MAGIC * Setup Environment Variables to integrate Pyspark with Jupyter Notebook.
# MAGIC * Launch Jupyter Notebook using ` pyspark ` command.
# MAGIC * Setup PyCharm (IDE) for application development.
# MAGIC
# MAGIC
# MAGIC ## Signing up for ITVersity Labs
# MAGIC
# MAGIC * 
# MAGIC
# MAGIC
# MAGIC ## Using ITVersity Labs
# MAGIC
# MAGIC Let us understand how to submit the Spark Jobs in ITVersity Labs.
# MAGIC
# MAGIC * As we are using Python we can also use the help command to get the documentation - for example ` help(spark.read.csv)`
# MAGIC
# MAGIC
# MAGIC ## Interacting with File Systems
# MAGIC
# MAGIC Let us understand how to interact with file system using %fs command from Databricks Notebook.
# MAGIC
# MAGIC * We can access datasets using %fs magic command in Databricks notebook
# MAGIC * By default, we will see files under dbfs
# MAGIC * We can list the files using ls command - e. g.: ` (%fs ls)`
# MAGIC * Databricks provides lot of datasets for free under databricks-datasets
# MAGIC * If the cluster is integrated with AWS or Azure Blob we can access files by specifying the appropriate protocol (e.g.: s3:// for s3)
# MAGIC * List of commands available under %fs
# MAGIC   * Copying files or directories `-cp`
# MAGIC   * Moving files or directories `- mv `
# MAGIC   * Creating directories ` - mkdirs ` 
# MAGIC   * Deleting files and directories ` - rm `
# MAGIC   * We can copy or delete directories recursively using ` -r` or `--recursive`

# COMMAND ----------

# MAGIC %md
# MAGIC ## Getting File Metadata
# MAGIC
# MAGIC Let us review the source location to get number of files and the size of the data we are going to process.
# MAGIC
# MAGIC * Location of airlines data dbfs:/databricks-datasets/airlines
# MAGIC * We can get first 1000 files using %fs ls dbfs:/databricks-datasets/airlines
# MAGIC * Location contain 1919 Files, however we will not be able to see all the details using %fs command.
# MAGIC * Databricks File System commands does not have capability to understand metadata of files such as size in details.
# MAGIC * When Spark Cluster is started, it will create 2 objects - spark and sc
# MAGIC * sc is of type SparkContext and spark is of type SparkSession
# MAGIC * Spark uses HDFS APIs to interact with the file system and we can access HDFS APIs using sc._jsc and sc._jvm to get file metadata.
# MAGIC * Here are the steps to get the file metadata. 
# MAGIC   * Get Hadoop Configuration using ` sc._jsc.hadoopConfiguration()` - let"s say `conf`
# MAGIC   * We can pass conf to ` sc._jvm.org.apache.hadoop.fs.FileSystem.` get to get FileSystem object - let"s say `fs`
# MAGIC   * We can build ` path`  object by passing the path as string to `sc._jvm.org.apache.hadoop.fs.Path`
# MAGIC   * We can invoke `listStatus` on top of fs by passing path which will return an array of FileStatus objects - let"s say files.  
# MAGIC   * Each `FileStatus` object have all the metadata of each file.
# MAGIC   * We can use `len` on files to get number of files.
# MAGIC   * We can use `getLen` on each `FileStatus` object to get the size of each file. 
# MAGIC   * Cumulative size of all files can be achieved using `sum(map(lambda file: file.getLen(), files))` 
# MAGIC * Let us first get list of files 

# COMMAND ----------

# MAGIC %fs ls dbfs:/databricks-datasets/airlines

# COMMAND ----------

# MAGIC %md
# MAGIC Here is the consolidated script to get number of files and cumulative size of all files in a given folder.

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    appName("Getting Started").
    master("yarn").
    getOrCreate

# COMMAND ----------

val conf = spark.sparkContext.hadoopConfiguration

# COMMAND ----------

import org.apache.hadoop.fs.FileSystem
val fs = FileSystem.get(conf)

# COMMAND ----------

import org.apache.hadoop.fs.Path
val path = new Path("/public/airlines_all/airlines")

# COMMAND ----------

val files = fs.listStatus(path)

# COMMAND ----------

files.map(file => file.getLen).sum/1024/1024/1024