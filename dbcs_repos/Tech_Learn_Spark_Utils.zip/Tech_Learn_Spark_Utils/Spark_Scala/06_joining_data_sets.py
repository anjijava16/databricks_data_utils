# Databricks notebook source
# MAGIC %md
# MAGIC # Joining Data Sets
# MAGIC
# MAGIC Let us understand how to join multiple Data Sets using Spark based APIs.
# MAGIC * Prepare Datasets for Joins
# MAGIC * Starting Spark Context
# MAGIC * Analyze Datasets for Joins
# MAGIC * Problem Statements
# MAGIC * Overview of Joins
# MAGIC * Solutions - Problem 1
# MAGIC * Solutions - Problem 2
# MAGIC * Solutions - Problem 3
# MAGIC * Solutions - Problem 4
# MAGIC * Solutions - Problem 5
# MAGIC * Solutions - Problem 6

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prepare Datasets for Joins
# MAGIC Let us prepare datasets to join.
# MAGIC
# MAGIC * Make sure airport-codes is in HDFS.
# MAGIC * We will also use airlines data for the month of January 2008. We have used that data set in the past as well.

# COMMAND ----------

import sys.process._

"hdfs dfs -ls /public/airlines_all"!

# COMMAND ----------

import sys.process._

"hdfs dfs -ls /public/airlines_all/airport-codes"!

# COMMAND ----------

import sys.process._

"hdfs dfs -ls /public/airlines_all/airlines-part/flightmonth=200801"!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Starting Spark Context
# MAGIC
# MAGIC Let us start spark context for this Notebook so that we can execute the code provided.
# MAGIC
# MAGIC If you want to use terminal for the practice, here is the command to use.
# MAGIC
# MAGIC ```
# MAGIC spark2-shell \
# MAGIC   --master yarn \
# MAGIC   --name "Joining Data Sets" \
# MAGIC   --conf spark.ui.port=0
# MAGIC ```

# COMMAND ----------

import org.apache.spark.sql.SparkSession

val spark = SparkSession.
    builder.
    config("spark.ui.port", "0").
    appName("Joining Data Sets").
    master("yarn").
    getOrCreate()

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "2")

# COMMAND ----------

import spark.implicits._

# COMMAND ----------

# MAGIC %md
# MAGIC ## Analyze Datasets for Joins
# MAGIC
# MAGIC Let us analyze data sets that are going to be used for joins.
# MAGIC * We will use January 2008 airlines data which have all relevant flight details.
# MAGIC * Let us read and review the airlines data quickly

# COMMAND ----------

val airlines = spark.
    read.
    parquet("/public/airlines_all/airlines-part/flightmonth=200801")

# COMMAND ----------

airlines.printSchema

# COMMAND ----------

airlines.show

# COMMAND ----------

# MAGIC %md
# MAGIC * We will be using another data set to get details about airports. Details include information such as State, City etc for a given airport code.
# MAGIC * Let us analyze the Dataset to confirm if there is header and also how the data is structured.

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

spark.
    read.
    text(airportCodesPath).
    show(false)

# COMMAND ----------

# MAGIC %md
# MAGIC  * Data is tab separated.
# MAGIC  * There is header for the data set.
# MAGIC  * Dataset have 4 fields - **Country, State, City, IATA**
# MAGIC     
# MAGIC     
# MAGIC Create DataFrame airport_codes applying appropriate Schema.
# MAGIC

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

val airportCodes = spark.
    read.
    option("sep", "\t").
    option("header", true).
    option("inferSchema", true).
    csv(airportCodesPath)

# COMMAND ----------

# MAGIC %md
# MAGIC * Preview and Understand the data.

# COMMAND ----------

airportCodes.show

# COMMAND ----------

# MAGIC %md
# MAGIC * Get schema of **airport_codes**.

# COMMAND ----------

airportCodes.printSchema

# COMMAND ----------

# MAGIC %md
# MAGIC * Get the count of records

# COMMAND ----------

airportCodes.count

# COMMAND ----------

# MAGIC %md
# MAGIC    * Get the count of unique records and see if it is the same as total count.

# COMMAND ----------

airportCodes.
    select("IATA").
    distinct.
    count

# COMMAND ----------

# MAGIC %md
# MAGIC  * If they are not equal, analyze the data and identify IATA codes which are repeated more than once.

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, count}

# COMMAND ----------

val duplicateIATACount = airportCodes.
    groupBy("IATA").
    agg(count(lit(1)).alias("iata_count")).
    filter("iata_count > 1")

# COMMAND ----------

duplicateIATACount.show

# COMMAND ----------

# MAGIC %md
# MAGIC  * Filter out the duplicates using the most appropriate one and discard others.

# COMMAND ----------

airportCodes.
    filter("IATA = 'Big'").
    show

# COMMAND ----------

airportCodes.
    filter("!(State = 'Hawaii' AND IATA = 'Big')").
    show

# COMMAND ----------

airportCodes.
    filter("!(State = 'Hawaii' AND IATA = 'Big')").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC  * Get number of airports (IATA Codes) for each state in the US. Sort the data in descending order by count.

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

val airportCodes = spark.
    read.
    option("sep", "\t").
    option("header", true).
    option("inferSchema", true).
    csv(airportCodesPath).
    filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")

# COMMAND ----------

airportCodes.count

# COMMAND ----------

import org.apache.spark.sql.functions.{count, col, lit}

# COMMAND ----------

val airportCountByState = airportCodes.
    groupBy("Country", "State").
    agg(count(lit(1)).alias("IATACount")).
    orderBy(col("IATACount").desc)

# COMMAND ----------

airportCountByState.show(51)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Problem Statements
# MAGIC
# MAGIC Let us understand how to join Data Frames by using some problem statements. We will use 2008 January airlines data along with Airport Codes.
# MAGIC
# MAGIC * Get number of flights departed from each of the US airport.
# MAGIC * Get number of flights departed from each of the state.
# MAGIC * Get the list of airports in the US from which flights are not departed.
# MAGIC * Check if there are any origins in airlines data which do not have record in airport-codes.
# MAGIC * Get the total number of flights from the airports that do not contain entries in airport-codes.
# MAGIC * Get the total number of flights per airport that do not contain entries in airport-codes.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Joins
# MAGIC
# MAGIC Let us get an overview of joining Data Frames.
# MAGIC * Our data cannot be stored in one table. It will be stored in multiple tables and the tables might be related.
# MAGIC   * When it comes to transactional systems, we typically define tables based on Normalization Principles.
# MAGIC   * When it comes to data warehousing applications, we typically define tables using Dimensional Modeling.
# MAGIC   * Either of the approach data is scattered into multiple tables and relationships are defined.
# MAGIC   * Typically tables are related with one to one, one to many, many to many relationships.
# MAGIC * When we have 2 Data Sets that are related based on a common key we typically perform join.
# MAGIC * There are different types of joins.
# MAGIC   * INNER JOIN
# MAGIC   * OUTER JOIN (LEFT or RIGHT)
# MAGIC   * FULL OUTER JOIN (a LEFT OUTER JOIN b UNION a RIGHT OUTER JOIN b)
# MAGIC  

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 1
# MAGIC
# MAGIC Get number of flights departed from each of the US airport in the month of 2008 January.
# MAGIC
# MAGIC * We have to use airport codes to determine US airport.
# MAGIC * We need to use airlines data to get departure details.
# MAGIC * To solve this problem we have to perform inner join.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.count

# COMMAND ----------

import org.apache.spark.sql.functions.{col, lit, count}

# COMMAND ----------

airlines.
    join(airportCodes, airportCodes("IATA") === airlines("Origin")).
    select(col("Year"), col("Month"), col("DayOfMonth"), airportCodes("*"), col("CRSDepTime")).
    show

# COMMAND ----------

airlines.
    join(airportCodes, airportCodes("IATA") === airlines("Origin")).
    groupBy("Origin").
    agg(count(lit(1)).alias("FlightCount")).
    orderBy(col("FlightCount").desc).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 2
# MAGIC
# MAGIC Get number of flights departed from each of the US state in the month of 2008 January.
# MAGIC
# MAGIC * We have to use airport codes to determine state of each of the US airport.
# MAGIC * We need to use airlines data to get departure details.
# MAGIC * To solve this problem we have to perform inner join.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.count

# COMMAND ----------

import org.apache.spark.sql.functions.{col, lit, count}

# COMMAND ----------

airlines.
    join(airportCodes, col("IATA") === col("Origin"), "inner").
    groupBy("State").
    agg(count(lit(1)).alias("FlightCount")).
    orderBy(col("FlightCount").desc).
    show

# COMMAND ----------

airportCodes.filter("State IS NULL").show

# COMMAND ----------

airportCodes.filter(col("State") isNull).show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 3
# MAGIC
# MAGIC Get the list of airports in the US from which flights are not departed in the month of 2008 January.
# MAGIC
# MAGIC * This is an example for outer join.
# MAGIC * We need to get those airports which are in airport codes but not in 2008 January airlines data set.
# MAGIC * Based on the side of the airport codes data set, we can say left or right. We will be using airport codes as the driving data set and hence we will use left outer join.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.count

# COMMAND ----------

import org.apache.spark.sql.functions.col

# COMMAND ----------

airportCodes.
    join(airlines, col("IATA") === col("Origin"), "left").
    filter("Origin IS NULL").
    select(airportCodes("*"), col("Origin")).
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 4
# MAGIC
# MAGIC Check if there are any origins in airlines data which do not have correpsonding records in airport-codes.
# MAGIC
# MAGIC * This is an example for outer join.
# MAGIC * We need to get those airports which are in Origin field in January 2008 airlines data set but not in airport-codes.
# MAGIC * Based on the side of the airlines data set, we can say left or right. We will be using airlines as the driving data set and hence we will use left outer join.
# MAGIC * We will also apply distinct on Origin before performing left outer join.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.show

# COMMAND ----------

airportCodes.count

# COMMAND ----------

airlines.
    select("Origin").
    distinct.
    show

# COMMAND ----------

airlines.
    select("Origin").
    distinct.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    show

# COMMAND ----------

airlines.
    select("Origin").
    distinct.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    filter("IATA IS NULL").
    show

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 5
# MAGIC
# MAGIC Get the total number of flights departed from the airports in January 2008 that do not contain entries in airport-codes.
# MAGIC
# MAGIC * This is an example for outer join.
# MAGIC * We need to get number of flights from the 2008 January airlines data which do not have entries in airport-codes.
# MAGIC * Based on the side of the airlines data set, we can say left or right. We will be using airlines as the driving data set and hence we will use left outer join.
# MAGIC * We will be peforming join first and then we will aggregate to get number of flights from the concerned airports.
# MAGIC * In this case will get total number of flights.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.show

# COMMAND ----------

airportCodes.count

# COMMAND ----------

airlines.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    filter("IATA IS NULL").
    select(airlines("Year"), airlines("Month"), airlines("DayOfMonth"), 
           airlines("Origin"), airlines("Dest"), airlines("CRSDepTime"), 
           airportCodes("*")
          ).
    show

# COMMAND ----------

airlines.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    filter("IATA IS NULL").
    count

# COMMAND ----------

# MAGIC %md
# MAGIC ## Solutions - Problem 6
# MAGIC
# MAGIC Get the total number of flights per airport that do not contain entries in airport-codes.
# MAGIC
# MAGIC * This is an example for outer join.
# MAGIC * We need to get number of flights from the 2008 January airlines data which do not have entries in airport-codes.
# MAGIC * Based on the side of the airlines data set, we can say left or right. We will be using airlines as the driving data set and hence we will use left outer join.
# MAGIC * We will be peforming join first and then we will aggregate to get number of flights from the concerned airports per airport.
# MAGIC * In this case will get total number of flights per airport.

# COMMAND ----------

val airlinesPath = "/public/airlines_all/airlines-part/flightmonth=200801"

# COMMAND ----------

val airlines = spark.
    read.
    parquet(airlinesPath)

# COMMAND ----------

airlines.select("Year", "Month", "DayOfMonth", "Origin", "Dest", "CRSDepTime").show

# COMMAND ----------

airlines.count

# COMMAND ----------

val airportCodesPath = "/public/airlines_all/airport-codes"

# COMMAND ----------

def getValidAirportCodes(airportCodesPath: String) = {
    val airportCodes = spark.
        read.
        option("sep", "\t").
        option("header", true).
        option("inferSchema", true).
        csv(airportCodesPath).
        filter("!(State = 'Hawaii' AND IATA = 'Big') AND Country = 'USA'")
    airportCodes
}

# COMMAND ----------

val airportCodes = getValidAirportCodes(airportCodesPath)

# COMMAND ----------

airportCodes.show 

# COMMAND ----------

airportCodes.count

# COMMAND ----------

airlines.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    filter("IATA IS NULL").
    select(airlines("Year"), airlines("Month"), airlines("DayOfMonth"), 
           airlines("Origin"), airlines("Dest"), airlines("CRSDepTime"), 
           airportCodes("*")
          ).
    show

# COMMAND ----------

import org.apache.spark.sql.functions.{lit, count}

# COMMAND ----------

airlines.
    join(airportCodes, airlines("Origin") === airportCodes("IATA"), "left").
    filter("IATA IS NULL").
    groupBy("Origin").
    agg(count(lit(1)).alias("FlightCount")).
    orderBy($"FlightCount".desc).
    show

# COMMAND ----------

