# Databricks notebook source
# MAGIC %md
# MAGIC # Quick Recap of Scala
# MAGIC
# MAGIC Let us quickly recap of some of the core programming concepts of Python before we get into Spark.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data Engineering Life Cycle
# MAGIC
# MAGIC Let us first understand the Data Engineering Life Cycle. We typically read the data, process it by applying business rules and write the data back to different targets
# MAGIC * Read the data from different sources.
# MAGIC   * Files
# MAGIC   * Databases
# MAGIC   * Mainframes
# MAGIC   * APIs
# MAGIC * Processing the data
# MAGIC   * Row Level Transformations
# MAGIC   * Aggregations
# MAGIC   * Sorting
# MAGIC   * Ranking
# MAGIC   * Joining multiple data sets
# MAGIC * Write data to different targets.
# MAGIC   * Files
# MAGIC   * Databases
# MAGIC   * Mainframes
# MAGIC   * APIs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Python CLI or Jupyter Notebook
# MAGIC
# MAGIC We can use Python CLI or Jupyter Notebook to explore APIs.
# MAGIC
# MAGIC * We can launch Python CLI using `python` command.
# MAGIC * We can launch the Jupyter Notebook using the `jupyter notebook` command.
# MAGIC * A web service will be started on port number 8888 by default.
# MAGIC * We can go to the browser and connect to the web server using IP address and port number.
# MAGIC * We should be able to explore code in interactive fashion.
# MAGIC * We can issue magic commands such as %%sh to run shell commands, %%md to document using markdown etc.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform these tasks to just recollect how to use Python CLI or Jupyter Notebook.
# MAGIC * Create variables i and j assigning 10 and 20.5 respectively.

# COMMAND ----------

val i = 10
val j = 20.5

# COMMAND ----------

# MAGIC %md
# MAGIC * Add the values and assign it to res.

# COMMAND ----------

val res = i + j

# COMMAND ----------

println(res)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get the type of i, j and res.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Basic Programming Constructs
# MAGIC
# MAGIC Let us recollect some of the basic programming constructs of Python.
# MAGIC * Comparison Operations (==, !=, <, >, <=, >=, etc) 
# MAGIC   * All the comparison operators return a True or False (Boolean value)
# MAGIC * Conditionals (if) 
# MAGIC   * We typically use comparison operators as part of conditionals.
# MAGIC * Loops (for) 
# MAGIC   * We can iterate through collection using `for i in l` where l is a standard collection such as list or set.
# MAGIC   * Python provides special function called as `range` which will return a collection of integers between the given range. It excludes the upper bound value.
# MAGIC * In Python, scope is defined by indentation.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC  
# MAGIC Let us perform few tasks to quickly recap basic programming constructs of Python.
# MAGIC  * Get all the odd numbers between 1 and 15.
# MAGIC  

# COMMAND ----------

(1 to 15 by 2)

# COMMAND ----------

# MAGIC %md
# MAGIC * Print all those numbers which are divisible by 3 from the above list.

# COMMAND ----------

for (i <- (1 to 15 by 2))
    if(i%3 == 0) println(i)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Developing Functions
# MAGIC
# MAGIC Let us understand how to develop functions using Python as programming language.
# MAGIC * Function starts with `def` followed by function name.
# MAGIC * Parameters can be of different types.
# MAGIC     * Required
# MAGIC     * Keyword
# MAGIC     * Variable Number
# MAGIC     * Functions
# MAGIC * Functions which take another function as an argument is called higher order functions.
# MAGIC
# MAGIC ### Tasks
# MAGIC
# MAGIC  Let us perform few tasks to understand how to develop functions in Python.   
# MAGIC  
# MAGIC  * Sum of integers between lower bound and upper bound using formula.
# MAGIC
# MAGIC

# COMMAND ----------

def sumOfN(n: Int) =
    (n * (n + 1)) / 2

# COMMAND ----------

sumOfN(10)

# COMMAND ----------

def sumOfIntegers(lb: Int, ub: Int) =
    sumOfN(ub) - sumOfN(lb - 1)

# COMMAND ----------

sumOfIntegers(5, 10)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of integers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfIntegers(lb: Int, ub: Int) = {
    var total = 0
    for (e <- (lb to ub))
        total += e
    total
}

# COMMAND ----------


sumOfIntegers(1, 10)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of squares of integers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfSquares(lb: Int, ub: Int) = {
    var total = 0
    for (e <- (lb to ub))
        total += e * e
    total
}

# COMMAND ----------

sumOfSquares(2, 4)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of the even numbers between lower bound and upper bound using loops.

# COMMAND ----------

def sumOfEvens(lb: Int, ub: Int) = {
    var total = 0
    for (e <- (lb to ub))
        total += e * e
    total
}

# COMMAND ----------

sumOfEvens(2, 4)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lambda Functions
# MAGIC
# MAGIC Let us recap details related to lambda functions.
# MAGIC
# MAGIC * We can develop functions with out names. They are called Lambda Functions and also known as Anonymous Functions.
# MAGIC * We typically use them to pass as arguments to higher order functions which takes functions as arguments
# MAGIC     

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks related to lambda functions.
# MAGIC     
# MAGIC * Create a generic function mySum which is supposed to perform arithmetic using integers within a range.   
# MAGIC     * It takes 3 arguments - lb, ub and f.
# MAGIC     * Function f should be invoked inside the function on each element within the range.
# MAGIC
# MAGIC     

# COMMAND ----------

def mySum(lb: Int, ub: Int, f: Int => Int) = {
    var total = 0
    for (e <- (lb to ub))
        total += f(e)
    total    
}

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of integers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, i => i)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of squares of integers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, i => i * i)

# COMMAND ----------

# MAGIC %md
# MAGIC * Sum of the even numbers between lower bound and upper bound using mySum.

# COMMAND ----------

mySum(2, 4, i => if(i%2 == 0) i else 0)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview of Collections and Tuples
# MAGIC
# MAGIC Let"s quickly recap about Collections and Tuples in Python. We will primarily talk about collections and tuples that comes as part of Python standard library such as `list`, `set`,` dict` and `tuple.`
# MAGIC
# MAGIC * Group of elements with length and index - `list`
# MAGIC * Group of unique elements - `set`
# MAGIC * Group of key value pairs - `dict`
# MAGIC * While list, set and dict contain group of homogeneous elements, tuple contains group of heterogeneous elements.
# MAGIC * We can consider list, set and dict as a table in a database and tuple as a row or record in a given table.
# MAGIC * Typically we create list of tuples or set of tuples and dict is nothing but collection of tuples with 2 elements and key is unique.
# MAGIC * We typically use Map Reduce APIs to process the data in collections. There are also some pre-defined functions such as `len`, `sum`,` min`,` max` etc for aggregating data in collections.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us perform few tasks to quickly recap details about Collections and Tuples in Python. We will also quickly recap about Map Reduce APIs.
# MAGIC
# MAGIC * Create a collection of orders by reading data from a file.

# COMMAND ----------

import sys.process._

# COMMAND ----------

"ls -ltr /data/retail_db/orders/part-00000"!

# COMMAND ----------

val ordersPath = "/data/retail_db/orders/part-00000"

# COMMAND ----------

import scala.io.Source

# COMMAND ----------

val orders = Source.fromFile(ordersPath).
    getLines

# COMMAND ----------

# MAGIC %md
# MAGIC * Get all unique order statuses. Make sure data is sorted in alphabetical order.

# COMMAND ----------

val ordersPath = "/data/retail_db/orders/part-00000"

import scala.io.Source
val orders = Source.fromFile(ordersPath).
    getLines

orders.
    map(order => order.split(",")(3)).
    toSet.
    toList.
    sorted.
    foreach(println)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get count of all unique dates.

# COMMAND ----------

val ordersPath = "/data/retail_db/orders/part-00000"

import scala.io.Source
val orders = Source.fromFile(ordersPath).
    getLines

orders.
    map(order => order.split(",")(1)).
    toSet.
    toList.
    sorted

# COMMAND ----------

# MAGIC %md
# MAGIC * Sort the data in orders in ascending order by order_customer_id and then order_date.

# COMMAND ----------

val ordersPath = "/data/retail_db/orders/part-00000"

import scala.io.Source
val orders = Source.fromFile(ordersPath).
    getLines

orders.
    toList.
    sortBy(k => {
        val a = k.split(",")
        (a(2).toInt, a(1))
    }).
    take(20).
    foreach(println)

# COMMAND ----------

# MAGIC %md
# MAGIC * Create a collection of order_items by reading data from a file.

# COMMAND ----------

val orderItemsPath = "/data/retail_db/order_items/part-00000"

import scala.io.Source
val orderItems = Source.fromFile(orderItemsPath).
    getLines.
    toList
orderItems.take(10).foreach(println)

# COMMAND ----------

# MAGIC %md
# MAGIC * Get revenue for a given order_item_order_id.

# COMMAND ----------

def getOrderRevenue(orderItems: List[String], orderId: Int) = {   
    val orderItemsFiltered = orderItems.
        filter(orderItem => orderItem.split(",")(1).toInt == orderId)
    val orderItemsMap = orderItemsFiltered.
        map(orderItem => orderItem.split(",")(4).toFloat)
    orderItemsMap.sum
}

# COMMAND ----------

val orderItemsPath = "/data/retail_db/order_items/part-00000"

import scala.io.Source
val orderItems = Source.fromFile(orderItemsPath).
    getLines.
    toList

# COMMAND ----------

print(getOrderRevenue(orderItems, 2))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Development Life Cycle
# MAGIC
# MAGIC Let us understand the development life cycle. We typically use IDEs such as PyCharm to develop Python based applications.
# MAGIC
# MAGIC * Create Project - retail
# MAGIC * Choose the interpreter 3.x
# MAGIC * Make sure plugins such as pandas are installed.
# MAGIC * Create config.py script for externalizing run time parameters such as input path, output path etc.
# MAGIC * Create app folder for the source code.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tasks
# MAGIC
# MAGIC Let us develop a simple application to understand end to end development life cycle.
# MAGIC
# MAGIC * Read the data from order_items
# MAGIC * Get revenue for each order id
# MAGIC * Save the output which contain order id and revenue to a file.
# MAGIC
# MAGIC Click [here](https://github.com/dgadiraju/python-retail/tree/v1.0) for the complete code for the above tasks.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercises
# MAGIC
# MAGIC Let us perform few exercises to understand how to process the data. We will use LinkedIn data to perform some basic data processing using Python.
# MAGIC
# MAGIC * Get LinkedIn archive.
# MAGIC   * Go to https://linkedin.com
# MAGIC   * Me on top -> Settings & Privacy
# MAGIC   * Then go to "How LinkedIn users your data" -> Getting a copy of your data
# MAGIC   * Register and download. You will get a link as part of the email.
# MAGIC * Data contain multiple CSV files. We will limit the analysis to **Contacts.csv** and **Connections.csv**.
# MAGIC * Get the number of **contacts** with out email ids.
# MAGIC * Get the number of **contacts** from each source.
# MAGIC * Get the number of **connections** with each title.
# MAGIC * Get the number of **connections** from each company.
# MAGIC * Get the number of **contacts** for each month in the year 2018.
# MAGIC * Use Postgres or MySQL as databases (you can setup in your laptop) and write connections data to the database

# COMMAND ----------

