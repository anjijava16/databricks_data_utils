# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC #Evaluating Risk for Loan Approvals
# MAGIC
# MAGIC ## we'll use a simple model - start with GLM
# MAGIC
# MAGIC ## Business Value
# MAGIC
# MAGIC Being able to accurately assess the risk of a loan application can save a lender the cost of holding too many risky assets. Rather than a credit score or credit history which tracks how reliable borrowers are, we will generate a score of how profitable a loan will be compared to other loans in the past. The combination of credit scores, credit history, and profitability score will help increase the bottom line for financial institution.
# MAGIC
# MAGIC Having a interporable model that a loan officer can use before performing a full underwriting can provide immediate estimate and response for the borrower and a informative view for the lender.
# MAGIC
# MAGIC In this notebook we're playing the role of a Data Scientist and building an elementary model which our Dev Ops team will publish.
# MAGIC
# MAGIC <a href="https://ibb.co/cuQYr6"><img src="https://preview.ibb.co/jNxPym/Image.png" alt="Image" border="0"></a>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ###Goal Of Machine Learning vs Traditional Software Development
# MAGIC <div><img src="https://pages.databricks.com/rs/094-YMS-629/images/mlflowneed.png" width="850"></div>
# MAGIC
# MAGIC ###MLflow Components
# MAGIC
# MAGIC <div><img src="https://pages.databricks.com/rs/094-YMS-629/images/mlflowcomponents.png" width="850"></div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Tracking Experiments with MLflow
# MAGIC
# MAGIC Over the course of the machine learning lifecycle, data scientists test many different models from various libraries with different hyperparemeters.  Tracking these various results poses an organizational challenge.  In brief, storing experiements, results, models, supplementary artifacts, and code creates significant challenges in the machine learning lifecycle.
# MAGIC
# MAGIC MLflow Tracking is a logging API specific for machine learning and agnostic to libraries and environments that do the training.  It is organized around the concept of **runs**, which are executions of data science code.  Runs are aggregated into **experiments** where many runs can be a part of a given experiment and an MLflow server can host many experiments.
# MAGIC
# MAGIC Each run can record the following information:
# MAGIC
# MAGIC - **Parameters:** Key-value pairs of input parameters such as the number of trees in a random forest model
# MAGIC - **Metrics:** Evaluation metrics such as RMSE or Area Under the ROC Curve
# MAGIC - **Artifacts:** Arbitrary output files in any format.  This can include images, pickled models, and data files
# MAGIC - **Source:** The code that originally ran the experiement
# MAGIC
# MAGIC MLflow tracking also serves as a **model registry** so tracked models can easily be stored and, as necessary, deployed into production.
# MAGIC
# MAGIC Experiments can be tracked using libraries in Python, R, and Java as well as by using the CLI and REST calls.
# MAGIC
# MAGIC <div><img src="https://pages.databricks.com/rs/094-YMS-629/images/mlflow-tracking.png" style="height: 300px; margin: 20px"/></div>
# MAGIC <div><img src="https://pages.databricks.com/rs/094-YMS-629/images/3 - Unify data and ML across the full lifecycle.png" width="950"></div>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## The Data
# MAGIC
# MAGIC The data used is public data from Lending Club. It includes all funded loans from 2012 to 2017. Each loan includes applicant information provided by the applicant as well as the current loan status (Current, Late, Fully Paid, etc.) and latest payment information. For a full view of the data please view the data dictionary available [here](https://resources.lendingclub.com/LCDataDictionary.xlsx).
# MAGIC
# MAGIC https://www.kaggle.com/wendykan/lending-club-loan-data

# COMMAND ----------

# MAGIC %md ### Databricks MLflow Integration
# MAGIC Managed MLFlow tracking server is available in community edition, the model registry is not.
# MAGIC This notebook will walk you through creating a model, track with MLFlow and **show** you how to register it with the registry when not in Community Edition
# MAGIC
# MAGIC Automated MLFlow tracking for Hyper-parameter tuning demo:
# MAGIC - Where we use features in this notebook that aren't available in community edition, we'll just leave the markdown or comment them out
# MAGIC - here we've seperated out the deployment of the model to AWS, but a data scientist could deploy the model if they had the correct access to AWS
# MAGIC

# COMMAND ----------

# DBTITLE 1,Ensure we're running at the correct runtime
# Imports
from pyspark.ml import Pipeline
from pyspark.ml.classification import DecisionTreeClassifier, DecisionTreeClassificationModel
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder, TrainValidationSplit

import mlflow,pyspark
import mlflow.mleap
import os

mlf_ver = mlflow.__version__
mlf_max_ver = (1,11,0)

mlf_ver_i = tuple(map(int, mlf_ver.split(".")))

assert mlf_ver_i <= mlf_max_ver, f"Current MLFlow Version {mlf_ver}. Must at most {mlf_max_ver}. Please use a cluster with max runtime 6.3ML"

print(f"MLFlow Version:{mlflow.__version__}\n" +\
      f"Pyspark Version:{pyspark.__version__}")

os.environ["MLFLOW_AUTODETECT_EXPERIMENT_ID"] = 'true'
spark.conf.set("spark.databricks.mlflow.trackMLlib.enabled", "true")
#restart or detach&retach cluster if you get attribute conf  error ; since we change the contextname below.
if spark.conf.get("spark.databricks.mlflow.trackMLlib.enabled")=='true' : print('Autotracking MLLib with MLFlow is on')



# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # Data Engineering
# MAGIC - clean up the features for modelling
# MAGIC - review the feature characteristics
# MAGIC - add additional features we may wish to include in our model
# MAGIC - choose your databsename,deltatable location path ,registeredmodelname uniquely with a Thumbrule your firstname followed by (four random digits)zzzz_ml_devday example : naseer0814_ml_devday  do  a find replace using the edit menu of the notebook above find and replace naseer0814 to your desired uniquename using the thumb rule above.

# COMMAND ----------

# MAGIC %sql 
# MAGIC CREATE DATABASE IF NOT EXISTS naseer0814_ml_devday;

# COMMAND ----------

# MAGIC %sql
# MAGIC Use naseer0814_ml_devday;

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE DATABASE naseer0814_ml_devday;

# COMMAND ----------

# DBTITLE 1,Import Data
# Configure location of loanstats_2012_2017.parquet
lspq_path = "/databricks-datasets/samples/lending_club/parquet/"

# Read loanstats_2012_2017.parquet
data = spark.read.parquet(lspq_path)

# Reduce the amount of data (to run on DBCE)
(loan_stats_ce, loan_stats_rest) = data.randomSplit([0.005, 0.995], seed=123)

# Select only the columns needed
loan_stats_ce = loan_stats_ce.select("loan_status", "int_rate", "revol_util", "issue_d", "earliest_cr_line", "emp_length", "verification_status", "total_pymnt", "loan_amnt", "grade", "annual_inc", "dti", "addr_state", "term", "home_ownership", "purpose", "application_type", "delinq_2yrs", "total_acc")

# Print out number of loans
print(str(loan_stats_ce.count()) + " loans opened by Lending Club...")

# COMMAND ----------

# DBTITLE 1,Filter Data and Fix Schema
from pyspark.sql.functions import *

print("------------------------------------------------------------------------------------------------")
print("Create bad loan label, this will include charged off, defaulted, and late repayments on loans...")
loan_stats_ce = loan_stats_ce.filter(loan_stats_ce.loan_status.isin(["Default", "Charged Off", "Fully Paid"]))\
                       .withColumn("bad_loan", (~(loan_stats_ce.loan_status == "Fully Paid")).cast("string"))


print("------------------------------------------------------------------------------------------------")
print("Turning string interest rate and revoling util columns into numeric columns...")
loan_stats_ce = loan_stats_ce.withColumn('int_rate', regexp_replace('int_rate', '%', '').cast('float')) \
                       .withColumn('revol_util', regexp_replace('revol_util', '%', '').cast('float')) \
                       .withColumn('issue_year',  substring(loan_stats_ce.issue_d, 5, 4).cast('double') ) \
                       .withColumn('earliest_year', substring(loan_stats_ce.earliest_cr_line, 5, 4).cast('double'))
loan_stats_ce = loan_stats_ce.withColumn('credit_length_in_years', (loan_stats_ce.issue_year - loan_stats_ce.earliest_year))


print("------------------------------------------------------------------------------------------------")
print("Converting emp_length column into numeric...")
loan_stats_ce = loan_stats_ce.withColumn('emp_length', trim(regexp_replace(loan_stats_ce.emp_length, "([ ]*+[a-zA-Z].*)|(n/a)", "") ))
loan_stats_ce = loan_stats_ce.withColumn('emp_length', trim(regexp_replace(loan_stats_ce.emp_length, "< 1", "0") ))
loan_stats_ce = loan_stats_ce.withColumn('emp_length', trim(regexp_replace(loan_stats_ce.emp_length, "10\\+", "10") ).cast('float'))

# COMMAND ----------

# MAGIC %md ## ![Delta Lake Tiny Logo](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) Easily Copy Parquet to Delta Lake format
# MAGIC With Delta Lake, you can easily transform your Parquet data into Delta Lake format. In this instance we'll create a second copy rather than create in place. We can use the versioning feature.

# COMMAND ----------


# Configure Path and temp view name
DELTALAKE_GOLD_PATH = ('/ml/naseer0814_ml_devday/loan_stats.delta')

#tviewname = dbutils.widgets.get('tviewname')

# Remove table if it exists
dbutils.fs.rm(DELTALAKE_GOLD_PATH, recurse=True)

# Save table as Delta Lake
loan_stats_ce.write.format("delta").mode("overwrite").save(DELTALAKE_GOLD_PATH)

# Re-read as Delta Lake
loan_stats = spark.read.format("delta").load(DELTALAKE_GOLD_PATH)

# Create temp table
loan_stats.createOrReplaceTempView("loan_stats")

# Review data
display(loan_stats)

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC -- Creating a new parquet table
# MAGIC DROP TABLE IF EXISTS loan_stats_delta;
# MAGIC
# MAGIC CREATE TABLE loan_stats_delta
# MAGIC   USING DELTA
# MAGIC   LOCATION '/ml/naseer0814_ml_devday/loan_stats.delta'

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE EXTENDED loan_stats_delta;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from loan_stats_delta;

# COMMAND ----------

dbutils.fs.ls(DELTALAKE_GOLD_PATH)

# COMMAND ----------

# MAGIC %md 
# MAGIC Get a sense of the distribution of some of out features, for example we can see that loan amount is slightly positively skewed for loan_grade, so have a slight imbalance across the classes.

# COMMAND ----------

# DBTITLE 1,Assert Allocation
display(loan_stats)

# COMMAND ----------

# MAGIC %md
# MAGIC ##![Delta Lake Logo Tiny](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) Full DML Support
# MAGIC
# MAGIC Delta Lake supports standard DML including UPDATE, DELETE and MERGE INTO providing developers more controls to manage large datasets.

# COMMAND ----------

# MAGIC %sql 
# MAGIC -- Creating a new parquet table
# MAGIC DROP TABLE IF EXISTS loan_stats_pq;
# MAGIC
# MAGIC CREATE TABLE loan_stats_pq
# MAGIC USING parquet
# MAGIC AS SELECT * FROM loan_stats;
# MAGIC
# MAGIC -- View Parquet table
# MAGIC SELECT * FROM loan_stats_pq;
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Attempting to run `UPDATE` on the Parquet table
# MAGIC UPDATE loan_stats_pq  SET int_rate = 12 WHERE int_rate >11 and int_rate <13

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Running `UPDATE` on the Delta Lake table for rounding of the intrest rate
# MAGIC --UPDATE delta.`/ml/loan_stats.delta` SET int_rate = 12 WHERE int_rate >11 and int_rate <13
# MAGIC UPDATE loan_stats_delta  SET int_rate = 12 WHERE int_rate >11 and int_rate <13
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from loan_stats_delta

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Running `DELETE` on the Delta Lake table
# MAGIC DELETE FROM loan_stats_delta WHERE addr_state = 'IA'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from loan_stats_delta WHERE addr_state = 'IA'

# COMMAND ----------

# MAGIC %md
# MAGIC ##![Delta Lake Logo Tiny](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) Schema Evolution
# MAGIC With the `mergeSchema` option, you can evolve your Delta Lake table schema. Imagine that we decide to add two additional features:

# COMMAND ----------

# DBTITLE 1,Adding two additional features, so updates the schema of the table
print("------------------------------------------------------------------------------------------------")
print("Map multiple levels into one factor level for verification_status...")
loan_stats = loan_stats.withColumn('verification_status', trim(regexp_replace(loan_stats.verification_status, 'Source Verified', 'Verified')))

print("------------------------------------------------------------------------------------------------")
print("Calculate the total amount of money earned or lost per loan...")
loan_stats = loan_stats.withColumn('net', round( loan_stats.total_pymnt - loan_stats.loan_amnt, 2))

# COMMAND ----------

# DBTITLE 1,Now intentionally overwrite the schema
# Add the mergeSchema option
loan_stats.write.option("mergeSchema","true").format("delta").mode("overwrite").save(DELTALAKE_GOLD_PATH)

# COMMAND ----------

# MAGIC %sql 
# MAGIC select * from loan_stats_delta

# COMMAND ----------

# MAGIC %md ### ![Delta Lake Tiny Logo](https://pages.databricks.com/rs/094-YMS-629/images/delta-lake-tiny-logo.png) Review Delta Lake Table History
# MAGIC All the transactions for this table are stored within this table including the initial set of insertions, update, delete, merge, and inserts with schema modification.
# MAGIC
# MAGIC You can read more on versioning [here](https://databricks.com/blog/2019/02/04/introducing-delta-time-travel-for-large-scale-data-lakes.html)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY loan_stats_delta
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select verification_status,net from loan_stats_delta version as of 2 limit 3
# MAGIC

# COMMAND ----------

# DBTITLE 1,Feature Distribution and Correlations
# note the positively skewed distribution
display(loan_stats)

# COMMAND ----------

# DBTITLE 1,Loans Per State
# map display is just another nice visualisation - we can see that most of our loans are in California
display(loan_stats.groupBy("addr_state").agg((count(col("annual_inc"))).alias("ratio")))

# COMMAND ----------

# DBTITLE 1,Asset Allocation
display(loan_stats)
# display(loan_stats.groupBy("bad_loan", "grade").agg((sum(col("net"))).alias("sum_net")))

# COMMAND ----------

# DBTITLE 1,Display our engineered columns/features - note the cleaned up numerics and categoricals
display(loan_stats.select("net","verification_status","int_rate", "revol_util", "issue_year", "earliest_year", "bad_loan", "credit_length_in_years", "emp_length"))

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC # First iteration over the model
# MAGIC
# MAGIC Acknowledging our data skew, we're ready to take a look at our first model
# MAGIC Logistic Regression is a staple in classification (although assumes a normal distribution - we're making several leaps here in the interest of showing the tooling)

# COMMAND ----------

# DBTITLE 1,Set Response and Predictor Variables
# again, for expediancy, we're splitting on date - and caching
print("------------------------------------------------------------------------------------------------")
print("Setting variables to predict bad loans")
myY = "bad_loan"
categoricals = ["term", "home_ownership", "purpose", "addr_state",
                "verification_status","application_type"]
numerics = ["loan_amnt","emp_length", "annual_inc","dti",
            "delinq_2yrs","revol_util","total_acc",
            "credit_length_in_years"]
myX = categoricals + numerics

loan_stats2 = loan_stats.select(myX + [myY, "int_rate", "net", "issue_year"])

# note the use of cache here: if using a delta optimised instance this isn't required
# we'll accept that splitting on date isn't best practice
train = loan_stats2.filter(loan_stats2.issue_year <= 2015)
valid = loan_stats2.filter(loan_stats2.issue_year > 2015)

train.count(), valid.count()

# COMMAND ----------

display(train) # intrigingly the distribution is less skewed
# display(valid) # seems more positively skewed

# COMMAND ----------

# MAGIC %md
# MAGIC ### Logistic Regression Notes
# MAGIC * We will be using the Apache Spark pre-installed GLM and GBTClassifier models in this noteboook
# MAGIC * **GLM** is in reference to *generalized linear models*; the Apache Spark *logistic regression* model is a special case of a [generalized linear model](https://spark.apache.org/docs/2.2.0/ml-classification-regression.html#logistic-regression)
# MAGIC * We will also use BinaryClassificationEvaluator, CrossValidator, and ParamGridBuilder to tune our models.
# MAGIC * References to max F1 threshold (i.e. F_1 score or F-score or F-measure) is the measure of our logistic regression model's accuracy; more information can be found at [F1 score](https://en.wikipedia.org/wiki/F1_score).
# MAGIC * **GBTClassifier** is in reference to *gradient boosted tree classifier* which is a popular classification and regression method using ensembles of decision trees; more information can be found at [Gradiant Boosted Tree Classifier](https://spark.apache.org/docs/2.2.0/ml-classification-regression.html#gradient-boosted-tree-classifier)
# MAGIC * In a subsequent notebook, we will be using the XGBoost, an optimized distributed gradient boosting library.  
# MAGIC   * Underneath the covers, we will be using *XGBoost4J-Spark* - a project aiming to seamlessly integrate XGBoost and Apache Spark by fitting XGBoost to Apache Spark’s MLLIB framework.  More inforamtion can be found at [XGBoost4J-Spark Tutorial](https://xgboost.readthedocs.io/en/latest/jvm/xgboost4j_spark_tutorial.html).
# MAGIC   
# MAGIC ### MLFlow
# MAGIC * we don't need to log the individual paramaters or metrics, with 'trackMLlib.enabled' this a tracked.
# MAGIC * MLFlow autotracking is also available (see more [here](https://www.mlflow.org/docs/latest/python_api/mlflow.keras.html))
# MAGIC * results from the next cell will be captured under the 'runs' button

# COMMAND ----------

# DBTITLE 1,Build Grid of GLM Models w/ Standardization+CrossValidation
from pyspark.ml import Pipeline
from pyspark.ml.feature import StringIndexer, VectorAssembler, OneHotEncoder
from pyspark.ml.feature import StandardScaler, Imputer
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import CrossValidator, ParamGridBuilder

## Current possible ways to handle categoricals in string indexer is 'error', 'keep', and 'skip'
indexers = map(lambda c: StringIndexer(inputCol=c, outputCol=c+"_idx", handleInvalid = 'keep'), categoricals)
ohes = map(lambda c: OneHotEncoder(inputCol=c + "_idx", outputCol=c+"_class"),categoricals)
imputers = Imputer(inputCols = numerics, outputCols = numerics)

# Establish features columns
featureCols = list(map(lambda c: c+"_class", categoricals)) + numerics

# Build the stage for the ML pipeline
# Build the stage for the ML pipeline
model_matrix_stages = list(indexers) + list(ohes) + [imputers] + \
                     [VectorAssembler(inputCols=featureCols, outputCol="features"), StringIndexer(inputCol="bad_loan", outputCol="label")]

# Apply StandardScaler to create scaledFeatures
scaler = StandardScaler(inputCol="features",
                        outputCol="scaledFeatures",
                        withStd=True,
                        withMean=True)

# Use logistic regression 
lr = LogisticRegression(maxIter=10, elasticNetParam=0.5, featuresCol = "scaledFeatures")

# Build our ML pipeline
pipeline = Pipeline(stages=model_matrix_stages+[scaler]+[lr])

# Build the parameter grid for model tuning
# (building with one parameter to reduce training time on Community Edition)
paramGrid = ParamGridBuilder() \
              .addGrid(lr.regParam, [0.1, 0.01]) \
              .build()

# uncomment for the elasticNetParam for a more interesting grid (increases the training time)
# paramGrid = ParamGridBuilder() \
#              .addGrid(lr.regParam, [0.1, 0.01]) \
#              .addGrid(lr.elasticNetParam, [0.5, 0.2]) \
#              .build()

# Execute CrossValidator for model tuning
crossval = CrossValidator(estimator=pipeline,
                          estimatorParamMaps=paramGrid,
                          evaluator=BinaryClassificationEvaluator(),
                          numFolds=5)

# this will auto track our params, also inherits the current active run
cvModel = crossval.fit(train) 

glm_model = cvModel.bestModel

# Return ROC
lr_summary = glm_model.stages[len(glm_model.stages)-1].summary

# you may need to adjust the following to get the FPR on the X axis, and TPR on the Y-Axis
display(lr_summary.roc)

# COMMAND ----------

# MAGIC %md 
# MAGIC ## Review the results in the run window
# MAGIC
# MAGIC Using the comparison tool we can now make a choice about our model
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # MLFlow and Model registry
# MAGIC * log the model and model registry to catalog
# MAGIC * this time we want to log the model as part of the run
# MAGIC * we'll use the UI to explore the model registry from our DS persona

# COMMAND ----------

registered_model_name = 'aws-naseer0814-ml-hands-on-lab'

# we need a run to attach to and record and log the model:
with mlflow.start_run(run_name='production_run'):
  
  cvModel = crossval.fit(train) # this will auto track our params, also inherits the current active run
  
  glm_model = cvModel.bestModel
  
  #from mlflow import spark
  
  # log the model and register it with the model repository (not available in community edition)
  # remove the 'registered_mode_name' parameter for community edition
  try:
    mlflow.spark.log_model(glm_model, artifact_path='glm_model', registered_model_name=registered_model_name) 
  except:
    mlflow.spark.log_model(glm_model, artifact_path='glm_model')


# COMMAND ----------

# DBTITLE 1,Set Max F1 Threshold
# if we wanted to adjust the threshold, this is how we would do it,
# we're not going to re-evaluate this model, so can ignore for now

fMeasure = lr_summary.fMeasureByThreshold
maxFMeasure = fMeasure.groupBy().max('F-Measure').select('max(F-Measure)').head()
maxFMeasure = maxFMeasure['max(F-Measure)']
fMeasure = fMeasure.toPandas()
bestThreshold = float ( fMeasure[ fMeasure['F-Measure'] == maxFMeasure] ["threshold"])
lr.setThreshold(bestThreshold)

# COMMAND ----------

# DBTITLE 1,Build GBT Model
# note that no metrics are captured
from pyspark.ml.classification import GBTClassifier

# Establish stages for our GBT model
indexers = map(lambda c: StringIndexer(inputCol=c, outputCol=c+"_idx", handleInvalid = 'keep'), categoricals)
imputers = Imputer(inputCols = numerics, outputCols = numerics)
featureCols = list(map(lambda c: c+"_idx", categoricals)) + numerics

# Define vector assemblers
model_matrix_stages = list(indexers) + [imputers] + \
                     [VectorAssembler(inputCols=featureCols, outputCol="features"), StringIndexer(inputCol="bad_loan", outputCol="label")]

# Define a GBT model.
gbt = GBTClassifier(featuresCol="features",
                    labelCol="label",
                    lossType = "logistic",
                    maxBins = 52,
                    maxIter=20,
                    maxDepth=5)

# Chain indexer and GBT in a Pipeline
pipeline = Pipeline(stages=model_matrix_stages+[gbt])

# Train model.  This also runs the indexer.
gbt_model = pipeline.fit(train)

# COMMAND ----------

# DBTITLE 1,Grab Model Metrics
# suggest we remove this cell too
from pyspark.mllib.evaluation import BinaryClassificationMetrics
from pyspark.ml.linalg import Vectors

def extract(row):
  return (row.net,) + tuple(row.probability.toArray().tolist()) +  (row.label,) + (row.prediction,)

def score(model,data):
  pred = model.transform(data).select("net", "probability", "label", "prediction")
  pred = pred.rdd.map(extract).toDF(["net", "p0", "p1", "label", "prediction"])
  return pred 

def auc(pred):
  metric = BinaryClassificationMetrics(pred.select("p1", "label").rdd)
  return metric.areaUnderROC

glm_train = score(glm_model, train)
glm_valid = score(glm_model, valid)
gbt_train = score(gbt_model, train)
gbt_valid = score(gbt_model, valid)

glm_train.createOrReplaceTempView("glm_train")
glm_valid.createOrReplaceTempView("glm_valid")
gbt_train.createOrReplaceTempView("gbt_train")
gbt_valid.createOrReplaceTempView("gbt_valid")

# instead of running this, we'll use MLFlow to bring it all together in a single experiment
 # print ("GLM Training AUC:" + str(auc(glm_train)))
 # print ("GLM Validation AUC :" + str(auc(glm_valid)))
 # print ("GBT Training AUC :" + str(auc(gbt_train)))
#  print ("GBT Validation AUC :" + str(auc(gbt_valid)))

# COMMAND ----------

# DBTITLE 1,Stacked ROC Curves
# MAGIC %scala
# MAGIC import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
# MAGIC // import org.apache.spark.sql.functions.typedLit
# MAGIC import org.apache.spark.sql.functions.{array, lit, map, struct}
# MAGIC
# MAGIC def roc(pred:org.apache.spark.sql.DataFrame, model_id:String): org.apache.spark.sql.DataFrame = {
# MAGIC   var testScoreAndLabel = pred.select("p1", "label").map{ case Row(p:Double,l:Double) => (p,l)}
# MAGIC   val metrics = new BinaryClassificationMetrics(testScoreAndLabel.rdd, 100)
# MAGIC   val roc = metrics.roc().toDF().withColumn("model", lit(model_id))
# MAGIC   return roc
# MAGIC }
# MAGIC
# MAGIC val glm_train = roc( spark.table("glm_train"), "glm_train")
# MAGIC val glm_valid = roc( spark.table("glm_valid"), "glm_valid")
# MAGIC val gbt_train = roc( spark.table("gbt_train"), "gbt_train")
# MAGIC val gbt_valid = roc( spark.table("gbt_valid"), "gbt_valid")
# MAGIC
# MAGIC val roc_curves = glm_train.union(glm_valid).union(gbt_train).union(gbt_valid)
# MAGIC
# MAGIC //settings for the chart: Series grouping : model, x-axis: _1, y-axis: _2
# MAGIC display(roc_curves)

# COMMAND ----------

# MAGIC %md ## Quantify the Business Value
# MAGIC
# MAGIC A great way to quickly understand the business value of this model is to use the confusion matrix to evaluate the cost of a poor loan decision.  The definition of our matrix is as follows:
# MAGIC
# MAGIC * Prediction=1, Label=1 (Blue) : Correctly found bad loans. sum_net = loss avoided.
# MAGIC * Prediction=1, Label=0 (Orange) : Incorrectly labeled bad loans. sum_net = profit forfeited.
# MAGIC * Prediction=0, Label=1 (Green) : Incorrectly labeled good loans. sum_net = loss still incurred.
# MAGIC * Prediction=0, Label=0 (Red) : Correctly found good loans. sum_net = profit retained.
# MAGIC
# MAGIC The following code snippet calculates the following confusion matrix.

# COMMAND ----------

# configure plot as bar; series groupings: label, prediction, value; sum_net
display(glm_valid.groupBy("label", "prediction").agg((sum(col("net"))).alias("sum_net")))

# COMMAND ----------

# MAGIC %md
# MAGIC <img src="https://pages.databricks.com/rs/094-YMS-629/images/stop.png?raw=true" width=50/>
# MAGIC ### Stop the notebook for setting experiment location

# COMMAND ----------

dbutils.notebook.exit("stop")

# COMMAND ----------

# by setting the experiment we now log to a single location in the workspace: In the sidebar, click the home button select your user name and then right click and create a folder named mlflow and set the the experiment below. example : mlflow.set_experiment('/Users/userfirstname.userlastname@emaildomain.com/mlflow/gbt-glm-new')

# COMMAND ----------

# DBTITLE 1,Now bring all the metrics together and register the model again in the model registry
#mlflow.set_experiment('/AWS-ML-Devday/MLflow/gbt-glm-new')
mlflow.set_experiment('/Users/naseer.ahmed@databricks.com/mlflow/gbt-glm-new')
#from mlflow import spark

with mlflow.start_run(run_name="glm"):
  mlflow.log_param("regParam", 0.01)
  mlflow.log_metric("auc", auc(glm_valid))
  
  # we can log via the API or through the UI (we've already registered one model)
  # will not register for community edition
  try:
    mlflow.spark.log_model(glm_model, artifact_path='glm_model', registered_model_name=registered_model_name) 
  except:
    mlflow.spark.log_model(glm_model, 'glm_model')
    
with mlflow.start_run(run_name="gbt"):
  mlflow.log_param("maxDepth", 5)
  mlflow.log_metric("auc", auc(gbt_valid))
  mlflow.spark.log_model(gbt_model, 'gbt_model')


# COMMAND ----------

# MAGIC %md # MLFLow model registry and sagemaker deployment

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### Switch to our [2 notebook](https://field-eng.cloud.databricks.com/#notebook/2435517/command/2435518) and follow the steps to deploy the GLM model to SageMaker.
# MAGIC