# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC ##Streaming Data Quality using AWS Deequ
# MAGIC
# MAGIC This notebook uses the `Deequ` package from AWS to run analysis on a streaming data source, and to derive key quality metrics about the data. Deequ is able to provide a variety of quantitative statistics and metrics about a dataset, and has utilities to generate, track, and interpret these metrics. See [this blog](https://aws.amazon.com/blogs/big-data/test-data-quality-at-scale-with-deequ/) for more detailed examples, or check the [GitHub repo](https://github.com/awslabs/deequ/).
# MAGIC
# MAGIC For this notebook, we use structured streaming, combined with Delta tables and the Deequ package, to provide a live view of a dataset's "health".
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;"><img src="https://i.imgur.com/zrMP9oM.png" height="700" width = "700"/></div>
# MAGIC
# MAGIC We'll use several Deequ metrics in our analysis; some of these are explained below. The full list can be found in the above links.
# MAGIC - `ApproxCountDistinct`: returns the approximate count of distinct values in a column
# MAGIC - `Distinctness`: returns the fraction of (distinct values / total values) in a column
# MAGIC - `Completeness`: returns the fraction of values that are non-null in a column
# MAGIC - `Compliance`: returns the fraction of values in a column that meet a given constraint
# MAGIC
# MAGIC _Note: this notebook requires the Deequ package; add the package from Maven Central using com.amazon.deequ. For Slack notifications, [spark-slack](https://github.com/MrPowers/spark-slack) or a similar package is required._

# COMMAND ----------

# MAGIC %md
# MAGIC Before we begin, we need to do some cleanup; we'll also need to download some data.

# COMMAND ----------

# MAGIC %fs
# MAGIC mkdirs /tmp/StreamingDataQuality/

# COMMAND ----------

# MAGIC %sh
# MAGIC # clear the delta checkpoint
# MAGIC rm -rf /dbfs/tmp/StreamingDataQuality/checkpoint
# MAGIC
# MAGIC # download some generated stock tick data; this is a public Mockaroo endpoint- as such, we can't guarantee availability!
# MAGIC curl "https://api.mockaroo.com/api/2aedaa80?count=1000&key=8eb06b50" > /dbfs/tmp/StreamingDataQuality/stockTicks.json

# COMMAND ----------

# read the raw JSON, then repartition and write into a tmp parquet folder
spark.read.json("/tmp/StreamingDataQuality/stockTicks.json").repartition(100).write.mode("overwrite").parquet("/tmp/StreamingDataQuality/source/")

# COMMAND ----------

# MAGIC %md
# MAGIC First we'll set up our delta tables and any necessary temporary views, as well as importing the packages to be used.

# COMMAND ----------

# MAGIC %scala
# MAGIC import spark.implicits._
# MAGIC import org.apache.spark.sql._
# MAGIC import org.apache.spark.sql.functions._
# MAGIC import org.apache.spark.sql.functions.concat
# MAGIC import com.amazon.deequ.{VerificationSuite, VerificationResult}
# MAGIC import com.amazon.deequ.VerificationResult.checkResultsAsDataFrame
# MAGIC import com.amazon.deequ.checks.{Check, CheckLevel, CheckStatus}
# MAGIC import com.amazon.deequ.suggestions.{ConstraintSuggestionRunner, Rules}
# MAGIC import com.amazon.deequ.analyzers._
# MAGIC import com.amazon.deequ.analyzers.runners.AnalysisRunner
# MAGIC import com.amazon.deequ.analyzers.runners.AnalyzerContext.successMetricsAsDataFrame
# MAGIC import com.amazon.deequ.analyzers.{Analysis, ApproxCountDistinct, Completeness, Compliance, Distinctness, InMemoryStateProvider, Size}
# MAGIC
# MAGIC val data_path = "/tmp/StreamingDataQuality/source/"
# MAGIC val checkpoint_path = "/tmp/StreamingDataQuality/checkpoint/"
# MAGIC val base_df = spark.read.parquet(data_path)
# MAGIC val empty_df = base_df.where("0 = 1")
# MAGIC val l1: Long = 0
# MAGIC
# MAGIC spark.sql("DROP TABLE IF EXISTS trades_delta")
# MAGIC spark.sql("DROP TABLE IF EXISTS bad_records")
# MAGIC spark.sql("DROP TABLE IF EXISTS deequ_metrics")
# MAGIC
# MAGIC base_df.createOrReplaceTempView("trades_historical")
# MAGIC empty_df.write.format("delta").saveAsTable("trades_delta")
# MAGIC empty_df.withColumn("batchID",lit(l1)).write.format("delta").saveAsTable("bad_records")
# MAGIC dbutils.fs.mkdirs(checkpoint_path)

# COMMAND ----------

# MAGIC %md
# MAGIC First, we'll take a look at the suggested quality constraints that Deequ can automatically generate. Deequ will inspect the data you give it, and generate constraints that assume future data should look similar.

# COMMAND ----------

# MAGIC %scala
# MAGIC val suggestionResult = ConstraintSuggestionRunner()
# MAGIC   .onData(spark.sql("SELECT * FROM trades_historical"))
# MAGIC   .addConstraintRules(Rules.DEFAULT)
# MAGIC   .run()
# MAGIC
# MAGIC suggestionResult.constraintSuggestions.foreach { case (column, suggestions) =>
# MAGIC   suggestions.foreach { suggestion =>
# MAGIC     println(s"Constraint suggestion for '$column':\t${suggestion.description}\n" +
# MAGIC       s"The corresponding scala code is ${suggestion.codeForConstraint}\n")
# MAGIC   }
# MAGIC }

# COMMAND ----------

# MAGIC %md
# MAGIC Currently, Deequ leaves it to us to decide which of these constraints to actually use. We'll choose a few to run on our full dataset. We'll also set up a few other pieces provided by Deequ to hold our stateful metrics.

# COMMAND ----------

# MAGIC %scala
# MAGIC // create a stateStore to hold our stateful metrics
# MAGIC val stateStoreCurr = InMemoryStateProvider()
# MAGIC val stateStoreNext = InMemoryStateProvider()
# MAGIC
# MAGIC // create the analyzer to run on the streaming data
# MAGIC val analysis = Analysis()
# MAGIC .addAnalyzer(Size())
# MAGIC .addAnalyzer(ApproxCountDistinct("symbol"))
# MAGIC .addAnalyzer(Distinctness("symbol"))
# MAGIC .addAnalyzer(Completeness("ipaddr"))
# MAGIC .addAnalyzer(Completeness("quantity"))
# MAGIC .addAnalyzer(Completeness("price"))
# MAGIC .addAnalyzer(Compliance("top quantity", "quantity >= 0"))

# COMMAND ----------

# MAGIC %md
# MAGIC Now that everything is in place, we can run the stream to populate our delta table. 
# MAGIC
# MAGIC Note that before running this cell, it is preferable to run the other streaming cells below first, so that they will consume all of the records from this producer.

# COMMAND ----------

# MAGIC %scala
# MAGIC // parse the schema for the source parquet
# MAGIC val schema = base_df.schema
# MAGIC
# MAGIC // start the stream
# MAGIC spark.readStream
# MAGIC .schema(schema)
# MAGIC .format("parquet")
# MAGIC .option("maxFilesPerTrigger",1)
# MAGIC .load(data_path)
# MAGIC .writeStream.format("delta")
# MAGIC .option("failOnDataLoss", false)
# MAGIC .option("checkpointLocation", checkpoint_path)
# MAGIC .format("delta").table("trades_delta")

# COMMAND ----------

# MAGIC %md
# MAGIC We now need to read the delta table we just created, so that we can apply the Deequ analysis to this data. To do this, we first read the previous delta table as a stream, and then use foreachBatch to do the following:
# MAGIC - Set up the stateStores
# MAGIC - Run our analysis on the current batch
# MAGIC - Run a unit validation on the current batch
# MAGIC - If unit verification fails, add the batch to the bad records table
# MAGIC - Update the metrics table with the current batch
# MAGIC
# MAGIC This cell writes to two tables: bad_records (which contains records from any batch that fails validation) and deequ_metrics (which contains the latest aggregated metrics from all streaming records).

# COMMAND ----------

# MAGIC %scala
# MAGIC // read the delta table and analyze
# MAGIC spark.readStream
# MAGIC .format("delta")
# MAGIC .table("trades_delta")
# MAGIC .writeStream
# MAGIC .foreachBatch { (batchDF: DataFrame, batchId: Long) =>
# MAGIC   
# MAGIC   // reassign our current state to the previous next state
# MAGIC   val stateStoreCurr = stateStoreNext
# MAGIC   
# MAGIC   // run our analysis on the current batch, aggregate with saved state
# MAGIC   val metricsResult = AnalysisRunner.run(
# MAGIC     data = batchDF,
# MAGIC     analysis = analysis,
# MAGIC     aggregateWith = Some(stateStoreCurr),
# MAGIC     saveStatesWith = Some(stateStoreNext))
# MAGIC   
# MAGIC   // verify critical metrics for this microbatch i.e., trade quantity, ipaddr not null, etc.
# MAGIC   val verificationResult = VerificationSuite()
# MAGIC   .onData(batchDF)
# MAGIC   .addCheck(
# MAGIC     Check(CheckLevel.Error, "unitTest")
# MAGIC       .hasMax("quantity", _ <= 10000) // max is 10000
# MAGIC       .hasCompleteness("ipaddr", _ >= 0.95) // 95%+ non-null IPs
# MAGIC       .isNonNegative("quantity")) // should not contain negative values
# MAGIC     .run()
# MAGIC   
# MAGIC   // if verification fails, write batch to bad records table
# MAGIC   if (verificationResult.status != CheckStatus.Success) {
# MAGIC     batchDF.withColumn("batchID",lit(batchId))
# MAGIC     .write.format("delta").mode("append").saveAsTable("bad_records")
# MAGIC   }
# MAGIC   
# MAGIC   // get the current metrics as a dataframe
# MAGIC   val metric_results = successMetricsAsDataFrame(spark, metricsResult)
# MAGIC   .withColumn("ts", current_timestamp())
# MAGIC   
# MAGIC   // write the current results into the metrics table
# MAGIC   metric_results.write.format("delta").mode("Overwrite").saveAsTable("deequ_metrics")
# MAGIC
# MAGIC }
# MAGIC .start()

# COMMAND ----------

# MAGIC %md
# MAGIC Now, we can visualize the metrics. Note that because we are updating the table, we need to set `ignoreChanges` to `true`. This means each update of the metrics will be written as a duplicate entry; we can parse this out to only take the latest view, or we can use this to create a time series view of the data quality.

# COMMAND ----------

# MAGIC %scala
# MAGIC display(spark.readStream.format("delta")
# MAGIC         .option("ignoreChanges", "true")
# MAGIC         .table("deequ_metrics")
# MAGIC         .where($"name" === "Size" || $"name" === "ApproxCountDistinct"))

# COMMAND ----------

# MAGIC %scala
# MAGIC display(spark.readStream.format("delta")
# MAGIC         .option("ignoreChanges", "true")
# MAGIC         .table("deequ_metrics")
# MAGIC         .where($"name" === "Completeness" || $"name" === "Distinctness"))

# COMMAND ----------

# MAGIC %scala
# MAGIC display(spark.readStream.format("delta")
# MAGIC         .option("ignoreChanges", "true")
# MAGIC         .table("deequ_metrics")
# MAGIC         .where($"name" === "Completeness" || $"name" === "Distinctness"))

# COMMAND ----------

# MAGIC %scala
# MAGIC val batchCounts = spark.read.format("delta").table("bad_records")
# MAGIC .groupBy($"batchId").count().withColumnRenamed("batchId", "batchId2").withColumnRenamed("count", "total")
# MAGIC
# MAGIC display(spark.read.format("delta").table("bad_records")
# MAGIC         .filter($"quantity" < 0 || $"quantity" > 10000 || $"ipaddr" === null)
# MAGIC         .groupBy($"batchId").count()
# MAGIC         .join(batchCounts, $"batchId2" === $"batchId", "inner")
# MAGIC         .withColumn("percent_bad", bround(lit(100)*$"count"/$"total",3))
# MAGIC         .drop("batchId2").orderBy(desc("percent_bad")))

# COMMAND ----------

# MAGIC %scala
# MAGIC display(spark.readStream.format("delta").table("bad_records")
# MAGIC         .filter($"quantity" < 0 || $"quantity" > 10000 || $"ipaddr" === null))

# COMMAND ----------

# MAGIC %scala
# MAGIC val verificationResult: VerificationResult = { VerificationSuite()
# MAGIC   .onData(spark.sql("select * from trades_delta"))
# MAGIC   .addCheck(
# MAGIC     Check(CheckLevel.Error, "Review Check") 
# MAGIC       .hasMax("quantity", _ <= 10000) // max is 10000
# MAGIC       .hasCompleteness("quantity", _ >= 0.95) // should never be NULL
# MAGIC       .isUnique("ipaddr") // should not contain duplicates
# MAGIC       .hasCompleteness("ipaddr", _ >= 0.95)
# MAGIC       .isContainedIn("buysell", Array("buy","sell")) // contains only the listed values
# MAGIC       .isNonNegative("quantity")) // should not contain negative values
# MAGIC   .run()
# MAGIC }
# MAGIC
# MAGIC // convert check results to a Spark data frame
# MAGIC val resultDataFrame = checkResultsAsDataFrame(spark, verificationResult)
# MAGIC display(resultDataFrame)

# COMMAND ----------

# MAGIC %scala
# MAGIC display(resultDataFrame)

# COMMAND ----------

# MAGIC %md
# MAGIC MLFlow also works well as a tracking tool for quality metrics- we can use Databricks' built-in MLFlow runs to directly log parameters and metrics against our notebook. Cells 21 and 22 can be run multiple times to capture snapshots across delta versions and timestamps.

# COMMAND ----------

# MAGIC %scala
# MAGIC import io.delta.tables._
# MAGIC // get the path of the deequ_metrics delta table
# MAGIC val fullPath = spark.read.table("deequ_metrics").select(input_file_name).take(1)(0)(0).toString
# MAGIC val regPattern = "^(.+)/([^/]+)$".r
# MAGIC val regPattern(tablePath, fileName) = fullPath
# MAGIC
# MAGIC // pull the current delta history and create a temp table (to be read by python)
# MAGIC val deltaTable = DeltaTable.forPath(spark, tablePath)
# MAGIC val lastOperationDF = deltaTable.history(1)
# MAGIC lastOperationDF.createOrReplaceTempView("deltaVersion")

# COMMAND ----------

import mlflow
import time
from pyspark.sql.functions import col

# get the deequ metrics table as a dataframe
rows = spark.read.table("deequ_metrics").collect()

# get the delta table version
delta_df = spark.read.table("deltaVersion")
ts = delta_df.select("timestamp").take(1)[0][0]
deltaVersion = delta_df.select("version").take(1)[0][0]

# get number of bad records
num_bad_recs = (spark.read.table("bad_records")
.filter("quantity < 0" or "quantity > 10000" or "ipaddr == ''").count())

# start a new mlflow run
with mlflow.start_run():

  mlflow.log_param("timestamp", ts)
  mlflow.log_param("delta_version", deltaVersion)
  mlflow.log_metric("num_bad_records", num_bad_recs)

  for i in range(len(rows)):

    # build the key-value pairs for the metrics
    instance = rows[i][1]
    name = rows[i][2]
    key = instance.replace("*","all") + "_" + name
    val = rows[i][3]

    # log the metric
    mlflow.log_metric(key, val)

# COMMAND ----------

# MAGIC %md
# MAGIC We can even send alerts based on our data quality checks. Use Slack, email, or the client of your choice!

# COMMAND ----------

# MAGIC %scala
# MAGIC import com.github.mrpowers.spark.slack.Notifier
# MAGIC
# MAGIC val webhookUrl = "<my.slack.webhook>"
# MAGIC val notifier = new Notifier(webhookUrl)
# MAGIC
# MAGIC val num_fail = resultDataFrame.filter($"constraint_status" === "Failure").count()
# MAGIC val error_string = s""":rotating_light: Looks like you've got some Data Quality errors! :rotating_light: 
# MAGIC There were ${num_fail} errors in the latest unit test."""
# MAGIC
# MAGIC if(num_fail > 0){
# MAGIC   notifier.speak(error_string,"Slackbot","alert","user.name")
# MAGIC }

# COMMAND ----------

# MAGIC %md
# MAGIC Finally, we'll clean up the assets we created.

# COMMAND ----------

# MAGIC %scala
# MAGIC spark.sql("DROP TABLE IF EXISTS trades_delta")
# MAGIC spark.sql("DROP TABLE IF EXISTS bad_records")
# MAGIC spark.sql("DROP TABLE IF EXISTS deequ_metrics")
# MAGIC dbutils.fs.rm(checkpoint_path, true)