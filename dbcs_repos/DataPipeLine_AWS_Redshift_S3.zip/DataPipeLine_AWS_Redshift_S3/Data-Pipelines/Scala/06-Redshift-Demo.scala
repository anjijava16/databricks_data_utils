// Databricks notebook source
// MAGIC %md # Connecting to Redshift from Databricks.
// MAGIC
// MAGIC This notebook contains examples showing how to use Databricks' [spark-redshift](https://github.com/databricks/spark-redshift) library for bulk reading/writing of large datasets.
// MAGIC
// MAGIC For more moderate-sized tables in Redshift, we recommend using the [JDBC tables for Spark SQL](../../03 Data Sources/5 Databases & Other Data Sources/2 JDBC for SQL Databases.html) using a postgres driver.
// MAGIC
// MAGIC `spark-redshift` is a library to load data into Spark SQL DataFrames from Amazon Redshift, and write data back to Redshift tables. Amazon S3 is used to efficiently transfer data in and out of Redshift, and JDBC is used to automatically trigger the appropriate COPY and UNLOAD commands on Redshift.
// MAGIC
// MAGIC This library is more suited to ETL than interactive queries, since large amounts of data could be extracted to S3 for each query execution. If you plan to perform many queries against the same Redshift tables then we recommend saving the extracted data in a format such as Parquet.

// COMMAND ----------

// MAGIC %md ## Configuration
// MAGIC
// MAGIC There are three main configuration steps which are prerequisites to using `spark-redshift`:
// MAGIC
// MAGIC - Create a S3 bucket to hold temporary data.
// MAGIC - Configure AWS credentials to access that S3 bucket.
// MAGIC - Configure Redshift access credentials.

// COMMAND ----------

// MAGIC %md ### Configuring a S3 bucket to hold temporary files 
// MAGIC
// MAGIC `spark-redshift` reads and writes data to S3 when transferring data to/from Redshift, so you'll need to specify a path in S3 where the library should write these temporary files. `spark-redshift` cannot automatically clean up the temporary files that it creates in S3. As a result, we recommend that you use a dedicated temporary S3 bucket with an [object lifecycle configuration](http://docs.aws.amazon.com/AmazonS3/latest/dev/object-lifecycle-mgmt.html) to ensure that temporary files are automatically deleted after a specified expiration period.
// MAGIC
// MAGIC In this example, we'll use a bucket named `aws-airlifts-redshift/temp` to hold our temporary directory:
// MAGIC
// MAGIC You must choose an S3 bucket for the temp folder that is in the same region as your Databricks Cluster.
// MAGIC
// MAGIC ### Authenticating to S3 and Redshift
// MAGIC
// MAGIC The use of this library involves several connections which must be authenticated / secured, 
// MAGIC which are illustrated in the following diagram:
// MAGIC
// MAGIC <img src= "https://s3.ca-central-1.amazonaws.com/westca-collateral/spark_redshift.png" width="700">
// MAGIC
// MAGIC
// MAGIC This library reads and writes data to S3 when transferring data to/from Redshift. As a result, it requires AWS credentials with read and write access to a S3 bucket (specified using the tempdir configuration parameter).
// MAGIC

// COMMAND ----------

// MAGIC %md ### Configuring Redshift database credentials
// MAGIC
// MAGIC Finally, you'll need to provide a JDBC URL for accessing your Redshift cluster. You can obtain your database's hostname from the AWS web UI. You'll also have to encode a database username and password into the URL. `spark-redshift`'s [full configuration guide](https://github.com/databricks/spark-redshift#parameters) contains additional information on how to specify this URL.

// COMMAND ----------

// MAGIC %md ## Redshift environment parameters
// MAGIC
// MAGIC * jdbcUsername = "REPLACE_WITH_YOUR_USER"
// MAGIC * jdbcPassword = "REPLACE_WITH_YOUR_PASSWORD"
// MAGIC
// MAGIC and the JDBC Url of your Redshift cluster including the port and the database name

// COMMAND ----------

val jdbcUsername = dbutils.secrets.get(scope = "aws-airlifts-s3", key = "dbuser")
val jdbcPassword = dbutils.secrets.get(scope = "aws-airlifts-s3", key = "dbpasswd")

val tempDir = "s3n://aws-airlifts-redshift/temp"
val jdbcUrl = "jdbc:redshift://aws-airlifts.cmyx9eo3auew.us-west-2.redshift.amazonaws.com:5439/databricks"

// COMMAND ----------

// MAGIC %md ## A quick test to make sure we get to our Redshift cluster

// COMMAND ----------

// MAGIC %sh nc -zv aws-airlift.cmyx9eo3auew.us-west-2.redshift.amazonaws.com 5439

// COMMAND ----------

// MAGIC %md ## Reading data from Redshift
// MAGIC
// MAGIC

// COMMAND ----------

val df_customer_from_redshift = spark.read
  .format("com.databricks.spark.redshift")
  .option("url", jdbcUrl)                
  .option("dbtable", "db.customer")
  .option("tempdir", "s3n://aws-airlifts-redshift/temp")           
  .option("user", jdbcUsername) 
  .option("password", jdbcPassword)
  .option("aws_iam_role", "arn:aws:iam::997819012307:role/aws-airlifts-redshift-role")
  .load()

df_customer_from_redshift.show

// COMMAND ----------

display(dbutils.fs.ls("s3a://aws-airlifts-redshift/temp/"))

// COMMAND ----------

display(df_customer_from_redshift)

// COMMAND ----------

df_customer_from_redshift.createOrReplaceTempView("customer_view_from_redshift")

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(*)
// MAGIC FROM customer_view_from_redshift

// COMMAND ----------

display(dbutils.fs.ls("s3a://aws-airlifts/Movies"))

// COMMAND ----------

// MAGIC %sql 
// MAGIC CREATE DATABASE IF NOT EXISTS aws_webinar_delta_demo;
// MAGIC USE aws_webinar_delta_demo;

// COMMAND ----------

// MAGIC %sql
// MAGIC DROP TABLE IF EXISTS movie_ratings;
// MAGIC
// MAGIC CREATE TABLE movie_ratings
// MAGIC USING csv
// MAGIC   OPTIONS (path "s3a://aws-airlifts/Movies/ratings.csv", header "true", inferSchema="true")

// COMMAND ----------

// MAGIC %sql
// MAGIC SELECT count(*)
// MAGIC FROM movie_ratings;

// COMMAND ----------

// MAGIC   %md Let's save this into a Redshift table, which we'll also name `movie_ratings` 

// COMMAND ----------

sqlContext.sql("select * from movie_ratings")
  .write 
  .format("com.databricks.spark.redshift")
  .option("url", jdbcUrl)                
  .option("dbtable", "db.customer")
  .option("tempdir", tempDir)           
  .option("user", jdbcUsername) 
  .option("password", jdbcPassword)
  .option("aws_iam_role", "arn:aws:iam::997819012307:role/aws-airlifts-redshift-role")
  .option("dbtable", "db.movie_ratings")       // <--- name of the table to create in Redshift
  .save()

// COMMAND ----------

// MAGIC %md 
// MAGIC
// MAGIC `spark-redshift` automatically creates a Redshift table with the appropriate schema determined from the table/DataFrame being written.
// MAGIC
// MAGIC The default behavior is to create a new table and to throw an error message if a table with the same name already exists. 
// MAGIC You can use Spark SQL's `SaveMode` feature to change this behavior. For example, let's append more rows to our table:

// COMMAND ----------

import org.apache.spark.sql.SaveMode

sqlContext.sql("select * from movie_ratings limit 10")
  .write
  .format("com.databricks.spark.redshift")
  .option("url", jdbcUrl)                
  .option("dbtable", "db.customer")
  .option("tempdir", tempDir)           
  .option("user", jdbcUsername) 
  .option("password", jdbcPassword)
  .option("aws_iam_role", "arn:aws:iam::997819012307:role/aws-airlifts-redshift-role")
  .option("dbtable", "db.movie_ratings")       
  .mode(SaveMode.Append)                    // <--- Append to the existing table
  .save()

// COMMAND ----------

// MAGIC %md You can also overwrite the existing table:

// COMMAND ----------

sqlContext.sql("select * from movie_ratings")
  .write
  .format("com.databricks.spark.redshift")
  .option("url", jdbcUrl)                
  .option("dbtable", "db.customer")
  .option("tempdir", tempDir)           
  .option("user", jdbcUsername) 
  .option("password", jdbcPassword)
  .option("aws_iam_role", "arn:aws:iam::997819012307:role/aws-airlifts-redshift-role")
  .option("dbtable", "db.movie_ratings")    
  .mode(SaveMode.Overwrite)                 // <--- Drop the existing table, then write the new data
  .save()

// COMMAND ----------

// MAGIC %md 
// MAGIC #### The examples above showed the Scala API, but `spark-redshift` is also usable from SQL, Python, R, and Java.
// MAGIC
// MAGIC > Note that the SQL API only supports the creation of new tables and not overwriting or appending; this corresponds to the default save mode of the other language APIs.

// COMMAND ----------

// MAGIC %md ## Notes on spark-redshift internals
// MAGIC
// MAGIC ### Databricks Pre-loads Libraries Automatically
// MAGIC Databricks preloads the necessary libraries to use `spark-redshift` so you don't have to import and attach them yourself.
// MAGIC
// MAGIC - [Redshift Connector JAR](https://github.com/databricks/spark-redshift)
// MAGIC - [AWS Redshift SDK](http://mvnrepository.com/artifact/com.amazonaws/aws-java-sdk-redshift)

// COMMAND ----------

// MAGIC %md ###Reading from Redshift
// MAGIC `spark-redshift` executes a Redshift [UNLOAD](http://docs.aws.amazon.com/redshift/latest/dg/r_UNLOAD.html) command (using JDBC) which copies the Redshift table in parallel to a temporary S3 bucket provided by the user. Next it reads these S3 files in parallel using the Hadoop InputFormat API and maps it to an RDD instance. Finally, it applies the schema of the table (or query), retrieved using JDBC metadata retrieval capabilities, to the RDD generated in the prior step to create a DataFrame instance.
// MAGIC
// MAGIC ![](https://databricks.com/wp-content/uploads/2015/10/image01.gif "Redshift Data Ingestion")
// MAGIC

// COMMAND ----------

// MAGIC %md ### Writing to Redshift
// MAGIC `spark-redshift` will first create the table in Redshift using JDBC. It then copies the partitioned RDD encapsulated by the source DataFrame instance to the temporary S3 folder. Finally, it executes the Redshift [COPY](http://docs.aws.amazon.com/redshift/latest/dg/r_COPY.html) command that performs a high performance distributed copy of S3 folder contents to the newly created Redshift table.
// MAGIC
// MAGIC ![](https://databricks.com/wp-content/uploads/2015/10/image00.gif "Redshift Data Egression")