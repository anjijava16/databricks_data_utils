# Databricks notebook source
spark.version();

# COMMAND ----------

