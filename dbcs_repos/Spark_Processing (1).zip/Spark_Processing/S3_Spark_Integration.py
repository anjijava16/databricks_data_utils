# Databricks notebook source
print("Interagtion wit Spark With S3")

# COMMAND ----------

sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", "AKIAIQ34EN67YAZ6KWEA")
sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", "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")

# COMMAND ----------

df = spark.read.csv("s3a://mds-data-spark/input.csv",header=True,sep="|");

# COMMAND ----------

 display(df) 

# COMMAND ----------

df.write.save("s3a://mds-data-spark/output/processing_dt=2019-12-15/", format='csv', header=True)