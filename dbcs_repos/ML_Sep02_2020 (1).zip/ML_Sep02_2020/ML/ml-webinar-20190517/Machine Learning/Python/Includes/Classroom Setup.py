# Databricks notebook source
# MAGIC
# MAGIC %python
# MAGIC course_name = "machine-learning"

# COMMAND ----------

# MAGIC %run "./Dataset-Mounts"

# COMMAND ----------

# MAGIC %scala
# MAGIC displayHTML("All done!")
# MAGIC