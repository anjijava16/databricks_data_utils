# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Course Overview and Setup
# MAGIC ## Machine Learning in Production
# MAGIC ### MLflow and Model Deployment
# MAGIC
# MAGIC In this course data scientists and data engineers learn the best practices for putting machine learning models into production.  It starts with managing experiments, projects, and models using MLflow.  It then explores various deployment options including batch, continuous with Spark Streaming, and on demand with RESTful and containerized services.  Finally, it covers monitoring machine learning models once they have been deployed into production.
# MAGIC
# MAGIC By the end of this course, you will have built the infrastructure to log, deploy, and monitor machine learning models.
# MAGIC
# MAGIC ** Prerequisites:**<br><br>
# MAGIC
# MAGIC - Python (`pandas`, `sklearn`, `numpy`)
# MAGIC - Background in machine learning and data science
# MAGIC - Basic knowledge of Spark DataFrames (recommended)
# MAGIC
# MAGIC ** The course consists of the following lessons:**<br><br>
# MAGIC
# MAGIC 0. Course Overview and Setup
# MAGIC 0. Experiment Tracking
# MAGIC 0. Packaging ML Projects
# MAGIC 0. Model Management 
# MAGIC 0. Production Issues
# MAGIC 0. Batch Deployment
# MAGIC 0. Streaming Deployment
# MAGIC 0. Real Time Deployment
# MAGIC 0. Drift Monitoring
# MAGIC 0. Alerting
# MAGIC 0. Delta Time Travel

# COMMAND ----------

# MAGIC %md
# MAGIC -- INSTRUCTOR_ONLY
# MAGIC
# MAGIC Notes on dependencies:
# MAGIC   - Set up the slack channel webhook
# MAGIC   - Increase CosmosDB throughput
# MAGIC   - Confirm SageMaker and AzureML endpoints are working
# MAGIC   - **Use ML Runtime** for packages including `keras` and `tensorflow`
# MAGIC   - Library Dependencies using PyPi unless otherwise noted
# MAGIC     - `azureml-sdk`
# MAGIC     - `azureml-sdk[databricks]`
# MAGIC     - `mlflow==0.9.0`
# MAGIC     - `scikit-multiflow`
# MAGIC     - `com.microsoft.azure:azure-cosmosdb-spark_2.4.0_2.11:1.3.5` (Maven)
# MAGIC     - `org.mlflow:mlflow-client:0.9.0` (Maven)
# MAGIC
# MAGIC Internal Resources:
# MAGIC   - [Go to market strategy](https://docs.google.com/document/d/11TY2A6MNPvFy1O-XmKalp59vC0vDbqN5-MAZXsJ1Pe4/edit#)
# MAGIC   - [Golden pitch deck](https://docs.google.com/presentation/d/1wkqmBxFTBCTf_GwD46W77-wFgXKWFStmEwYIpyBA7zI/edit#slide=id.p16)
# MAGIC   - [MLflow strategy](https://docs.google.com/presentation/d/1jqL54c-usY5SZyyL9C6AxISBrArSGLlHSnmNV6LWdOs/edit#slide=id.g41fc7cf04d_0_117)
# MAGIC   - [Demo from ILT](https://databricks-prod-cloudfront.cloud.databricks.com/public/793177bc53e528530b06c78a4fa0e086/0/5769800/100020/latest.html)
# MAGIC   - [Andy's talk on multi-step workflows](https://drive.google.com/drive/u/0/folders/0B86uHPNtT6KsflAzRGZwcmVCTkZ5cEhqRjhuVWhpb2lDSElGVzdWcmlVX1hkb1hCOUd0cnM)
# MAGIC   - [Andre's links of available resources](https://databricks.atlassian.net/wiki/spaces/~andre.mesarovic/pages/571244676/MLflow+Links#MLflowLinks-DatabricksInternal)
# MAGIC   - [Andre's links of available notebooks](https://demo.cloud.databricks.com/#notebook/1564377/command/2395991) 
# MAGIC   - [CI/CD Pitch](https://docs.google.com/presentation/d/1rwsqGcvCYOFoqAWWZcDR04b-VMHxD_iK2agFQpoArSI/edit#slide=id.g50e53f9326_1_27) and [blog](https://databricks.com/blog/2017/10/30/continuous-integration-continuous-delivery-databricks.html)
# MAGIC   - For MLeap, See [Adam's talk](https://www.youtube.com/watch?v=KOehXxEgXFM) and [his notebook](https://databricks-prod-cloudfront.cloud.databricks.com/public/4027ec902e239c93eaaa8714f173bcfc/7033591513855707/699028214697099/6890845802385168/latest.html) 
# MAGIC   - [Mani's doc on data drift](https://docs.google.com/document/d/1CFT42OjkpaE4Lm0j2xBZCQ6--_N1DMdirgO1WG_9hkc/edit?ts=5ca7fac3#heading=h.q2dag7y3ql7w)
# MAGIC   - [Compare/Contrast MLflow and Azure ML](https://docs.google.com/presentation/d/13T84QxS3QNfQzzwP7EngtNIwSTmcvjvFJ-FSa4CaLj4/edit?ts=5ca4fb30#slide=id.g55c496f54c_4_7)
# MAGIC   
# MAGIC External Resources:
# MAGIC   - [Docs](https://mlflow.org/docs/latest/index.html)
# MAGIC   - [github](https://github.com/mlflow/mlflow/)
# MAGIC   - [Richard's talk](https://www.datasciencecentral.com/video/apache-sparkm-mllib-2-x-productionize-your-machine-learning-model)
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2019 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>