# Databricks notebook source
# MAGIC %python
# MAGIC course_name = "Spark ILT"

# COMMAND ----------

# MAGIC %run "./Dataset-Mounts"

# COMMAND ----------

# MAGIC %run "./Test-Library"

# COMMAND ----------

# MAGIC %run "./Table-Creator"

# COMMAND ----------

displayHTML("All done!")
