# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Exploring the Augmented Sample Data

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# MAGIC %run ./includes/utilities

# COMMAND ----------

# MAGIC %md
# MAGIC ### Load Scipy Libraries

# COMMAND ----------

# MAGIC %run ./includes/scipy_stack

# COMMAND ----------

# MAGIC %md
# MAGIC ## Load the Sample Data as a Pandas DataFrame
# MAGIC
# MAGIC Recall that we wrote the sample data as a Delta table to
# MAGIC the path, `goldPath + "health_tracker_sample_agg"`.
# MAGIC
# MAGIC 1. Use `spark.read` to read the Delta table as a Spark DataFrame.
# MAGIC 2. Use the `.toPandas()` DataFrame method to load the Spark
# MAGIC    DataFrame as a Pandas DataFrame.

# COMMAND ----------

# ANSWER
health_tracker_augmented_df = (
  spark.read
  .format("delta")
  .load(goldPath + "health_tracker_augmented")
  .toPandas()
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display the Unique Lifestyles

# COMMAND ----------

# ANSWER
lifestyles = health_tracker_augmented_df.lifestyle.unique()
lifestyles

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create Feature and Target Objects

# COMMAND ----------

features = health_tracker_augmented_df.drop("lifestyle", axis=1)
target = health_tracker_augmented_df[["lifestyle"]].copy()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display a `.sample()` of the Features DataFrame

# COMMAND ----------

features.sample(10)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Display the `.dtypes` of the Features DataFrame

# COMMAND ----------

features.dtypes

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use `seaborn` to Display a Distribution Plot for Each Feature, Colored by Lifestyle

# COMMAND ----------

# ANSWER
fig, ax = plt.subplots(1,5, figsize=(25,5))

for i, feature in enumerate(features.select_dtypes(include=[float])):
  for lifestyle in lifestyles:
    subset = features[target.lifestyle == lifestyle]
    sns.distplot(subset[feature], ax=ax[i], label=lifestyle)
  ax[i].legend()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use `seaborn` to Display a Distribution Plot for Each Resting Heart Rate, Colored by Categorical Feature

# COMMAND ----------

fig, ax = plt.subplots(1,3, figsize=(27,5))

for i, feature in enumerate(features.select_dtypes(exclude=[float])):
  for value in features[feature].unique():
    subset = features[features[feature] == value]
    sns.distplot(subset["mean_resting_heartrate"], ax=ax[i], label=value)
  ax[i].legend(loc='center left', bbox_to_anchor=(1.0, 0.5))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Use Pandas Plotting to Display a Bar Plot for Each Categorical Feature by Lifestyle

# COMMAND ----------

fig, ax = plt.subplots(1,3, figsize=(27,5))
(
  health_tracker_augmented_df
  .groupby("female")
  .lifestyle.value_counts()
  .unstack(0)
  .plot(kind="bar", ax=ax[0]).legend(loc='center left',bbox_to_anchor=(1.0, 0.5))
)
(
  health_tracker_augmented_df
  .groupby("country")
  .lifestyle.value_counts()
  .unstack(0)
  .plot(kind="bar", ax=ax[1]).legend(loc='center left',bbox_to_anchor=(1.0, 0.5))
)
(
  health_tracker_augmented_df
  .groupby("occupation")
  .lifestyle.value_counts()
  .unstack(0)
  .plot(kind="bar", ax=ax[2]).legend(loc='center left',bbox_to_anchor=(1.0, 0.5))
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Scaling Data
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2020 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>