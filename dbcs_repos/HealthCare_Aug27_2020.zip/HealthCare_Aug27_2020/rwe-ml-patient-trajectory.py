# Databricks notebook source
# MAGIC %md
# MAGIC # Predict the outcome of an encounter, given historic data
# MAGIC ##<img src="https://databricks.com/wp-content/themes/databricks/assets/images/header_logo_2x.png" alt="logo" width="150"/> 
# MAGIC Distributed ML with MLFlow and Hyperopt
# MAGIC In this notebook, we train a model to predict whether a patient is at risk of a given codition, using the patient's encounter history and demographic information. 
# MAGIC
# MAGIC <ol>
# MAGIC   <li> **Data**: We use the dataset created in the previouse step that we created using simulated patient records.</li>
# MAGIC   <li> **Parameteres**: Users can specify the target condition (to be predicted), the number of comorbid conditions to include and the number of days of record before the most recent encounter
# MAGIC   <li> **Model Training**: We use [*hyperopt*](https://docs.databricks.com/applications/machine-learning/automl/hyperopt/index.html#hyperopt) with SparkTrials for distributed hyperparameter tuning and trying different algorithms</li>
# MAGIC   <li> **Model tracking and management**: Using [*MLFlow*](https://docs.databricks.com/applications/mlflow/index.html#mlflow), we track our training experiments and log the models for the best model </li>
# MAGIC </ol>

# COMMAND ----------

# MAGIC %run ./00-rwe-etl-delta

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## 1. Specify paths and parameters

# COMMAND ----------

dbutils.widgets.text('condition', 'drug overdose', 'Condition to model')
dbutils.widgets.text('num_conditions', '10', '# of comorbidities to include')
dbutils.widgets.text('num_days', '90', '# of days to use')

# COMMAND ----------

condition=dbutils.widgets.get('condition')
num_conditions=int(dbutils.widgets.get('num_conditions'))
num_days=int(dbutils.widgets.get('num_days'))

# COMMAND ----------

# DBTITLE 0,load data for training
## Specify the path to delta tables on dbfs
delta_path = "dbfs:/tmp/rwe-ehr/delta"

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Data preparation
# MAGIC To create the training data, we need to extract a dataset with both positive (affected ) and negative (not affected) labels.

# COMMAND ----------

from pyspark.sql import Window
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 2.1 Load Tables

# COMMAND ----------

patient_encounters = spark.read.load(delta_path+'/patient_encounters')
# patient_encounters = spark.sql('Select * from rwd.patient_encounters')

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 2.2 Create a list of patients to include

# COMMAND ----------

all_patients=patient_encounters.select('PATIENT').dropDuplicates()

# get the list of patients with the target condition (cases)
positive_patients = patient_encounters.select('PATIENT').where(lower("REASONDESCRIPTION").like("%{}%".format(condition))).dropDuplicates().withColumn('label',lit(1))

negative_patients = (
  all_patients
  .join(positive_patients,on=['PATIENT'],how='left_anti')
  .limit(positive_patients.count())
  .withColumnRenamed('Id','PATIENT')
  .withColumn('label',lit(0))
  .dropDuplicates()
)

# create a list of patients to include in training 
patients_to_study = positive_patients.union(negative_patients).cache()
patients_to_study.groupBy('label').count().show()

# COMMAND ----------

patients_data_df = patient_encounters.join(patients_to_study,on=['PATIENT'])

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2.3 Limit encounters to those within the given window of time
# MAGIC and add age at the time of diagnosis

# COMMAND ----------

w = (
    Window.partitionBy('PATIENT').orderBy(desc('START_TIME'))
)

patients_recent_diag_date_df = (
  patients_data_df
  .select('PATIENT','START_TIME')
  .withColumn('rank',row_number().over(w))
  .filter('rank == 1')
  .withColumnRenamed('START_TIME','most_recent_diag_date')
  .drop('rank')
  .dropDuplicates()
)

# COMMAND ----------

cols=['ORGANIZATION','ENCOUNTERCLASS', 'BIRTHDATE', 'ETHNICITY', 'GENDER','REASONDESCRIPTION','age_at_diag_date', 'label']
patients_data_limit_days =(
    patients_data_df
    .join(patients_recent_diag_date_df,on=['PATIENT'])
    .withColumn('days_diff',datediff(col('most_recent_diag_date'),col('START_TIME')))
    .withColumn('age_at_diag_date',datediff(col('most_recent_diag_date'),col('BIRTHDATE'))/365)
    .filter('days_diff < {}'.format(num_days))
    .select(cols)
  )

# COMMAND ----------

# DBTITLE 1,distribution of age by gender
display(patients_data_limit_days)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 2.4 Add comomorbidity features

# COMMAND ----------

#create a dataframe of comorbid conditions
comorbid_conditions = (
  positive_patients.join(patient_encounters, ['PATIENT'])
  .where(col('REASONDESCRIPTION').isNotNull())
  .dropDuplicates(['PATIENT', 'REASONDESCRIPTION'])
  .groupBy('REASONDESCRIPTION').count()
  .orderBy('count', ascending=False)
  .limit(num_conditions)
)

display(comorbid_conditions)

# COMMAND ----------

comorbidity_list = comorbid_conditions.withColumn('weight',col('count')/max('count').over(Window.partitionBy())).collect()
encounter_features=patients_data_limit_days

idx = 0
for comorbidity in comorbidity_list[1:]:
    encounter_features = (
      encounter_features
      .withColumn("comorbidity_%d" % idx, comorbidity['weight']*(encounter_features['REASONDESCRIPTION'].like('%' + comorbidity['REASONDESCRIPTION'] + '%')).cast('int'))
      .withColumn("comorbidity_%d"  % idx,coalesce(col("comorbidity_%d" % idx),lit(0))) # replacing null values with 0
      .cache()
    )
    idx += 1

# COMMAND ----------

display(encounter_features)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## 3. Model selection and training

# COMMAND ----------

import pandas as pd
import numpy as np

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score

import mlflow
import mlflow.sklearn

from hyperopt import fmin, tpe, hp, SparkTrials, STATUS_OK, Trials, space_eval
np.random.seed(42)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 3.1 Create dataset for training using scikit-learn

# COMMAND ----------

encounter_features_pdf=encounter_features.select(cols).toPandas()
data_pdf=pd.get_dummies(encounter_features_pdf) # transform categorical variables to vector of indicator functions
X=data_pdf.drop(['label'],axis=1).values
y=data_pdf['label'].values

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 3.2 Define a training function for model selection using hyperopt

# COMMAND ----------

def train(params):
    np.random.seed(42)
    classifier_type = params['type']
    tune=params['tune']
    del params['type']
    del params['tune']
    
    if classifier_type == 'svm':
        clf = SVC(**params)
    elif classifier_type == 'lgr':
        clf = LogisticRegression(**params)
    elif classifier_type == 'rndf':
        clf=RandomForestClassifier(**params)
    else:
        return 0
    accuracy = cross_val_score(clf, X, y).mean()
    
    if tune:
      return {'loss': -accuracy, 'status': STATUS_OK}
    else:
      clf.fit(X,y)
      mlflow.sklearn.log_model(clf,'model_clf')
      uri=mlflow.get_artifact_uri(artifact_path='model_clf')
      return(uri)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 3.3 Define search space

# COMMAND ----------

search_space = hp.choice('classifier_type', [
    
    {
        'type': 'lgr',
        'tune': True,
    },
    {
        'type': 'svm',
        'tune': True,
        'C':hp.choice("C", [1.0, 10]),
    },
    {
        'type': 'rndf',
        'tune': True,
#         'max_depth': hp.choice('max_depth', [10, 20]),
    },
    
])

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Note that all runs are automatically tracked by `mlflow`

# COMMAND ----------

spark_trials = SparkTrials(parallelism=2)

with mlflow.start_run():
  best_result = fmin(
    fn=train, 
    space=search_space,
    algo=tpe.suggest,
    max_evals=32,
    trials=spark_trials
  )


# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ### 3.4 Train the model with the best parameters

# COMMAND ----------

params=space_eval(search_space, best_result)
params.update({'tune':False})
model_uri=train(params)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## 4. Load the model for scoring

# COMMAND ----------

model=mlflow.sklearn.load_model(model_uri=model_uri)
sample_data=X[1:10]

# COMMAND ----------

model.predict(sample_data)