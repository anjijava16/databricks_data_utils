# Databricks notebook source
 df=spark.read.format("jdbc").option("url", "jdbc:mysql://101.53.145.200:3306/mmtechso_reportdb").option("driver", "com.mysql.jdbc.Driver").option("dbtable", "customer_test").option("user", "welcome").option("password", "bu3anyper").load()

# COMMAND ----------

display(df)

# COMMAND ----------

