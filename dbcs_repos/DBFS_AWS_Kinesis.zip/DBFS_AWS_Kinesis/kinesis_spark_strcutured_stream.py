# Databricks notebook source
#Reference Links
# https://databricks.com/blog/2017/08/09/apache-sparks-structured-streaming-with-amazon-kinesis-on-databricks.html


# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC // === Configurations for Kinesis streams ===
# MAGIC val awsAccessKeyId = "AKIAIIUNUQ7Z5BBSDOMA"
# MAGIC val awsSecretKey = "qlVReRAZXrzRlrEuZAzU7nclZNCcmdYjl3PdZJN6"
# MAGIC val kinesisStreamName = "welcome-spark-databricks"
# MAGIC val kinesisRegion = "us-east-1" // e.g., "us-west-2"
# MAGIC
# MAGIC val kinesis = spark.readStream
# MAGIC   .format("kinesis")
# MAGIC   .option("streamName", kinesisStreamName)
# MAGIC   .option("region", kinesisRegion)
# MAGIC   .option("initialPosition", "TRIM_HORIZON")
# MAGIC   .option("awsAccessKey", awsAccessKeyId)
# MAGIC   .option("awsSecretKey", awsSecretKey)
# MAGIC   .load()
# MAGIC val result = kinesis.selectExpr("lcase(CAST(data as STRING)) as word")
# MAGIC   .groupBy($"word")
# MAGIC   .count()
# MAGIC //display(result)
# MAGIC

# COMMAND ----------

