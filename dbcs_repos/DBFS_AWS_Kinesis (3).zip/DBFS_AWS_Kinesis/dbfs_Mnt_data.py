# Databricks notebook source
dbutils.fs.ls("/mnt/data")

# COMMAND ----------

dbutils.fs.ls("/mnt/s3data/")

# COMMAND ----------

dbutils.fs.ls("/mnt/data")

# COMMAND ----------

dbutils.fs.ls("/mnt/training")

# COMMAND ----------

