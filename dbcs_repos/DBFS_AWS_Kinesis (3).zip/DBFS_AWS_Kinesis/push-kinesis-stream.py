# Databricks notebook source
# MAGIC %scala 
# MAGIC // === Configurations for Kinesis streams ===
# MAGIC val awsAccessKeyId = "AKIAIIUNUQ7Z5BBSDOMA"
# MAGIC val awsSecretKey = "qlVReRAZXrzRlrEuZAzU7nclZNCcmdYjl3PdZJN6"
# MAGIC val kinesisStreamName = "welcome-spark-databricks"
# MAGIC val kinesisRegion = "us-east-1" // e.g., "us-west-2"
# MAGIC
# MAGIC
# MAGIC import com.amazonaws.services.kinesis.model.PutRecordRequest
# MAGIC import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder
# MAGIC import com.amazonaws.auth.{AWSStaticCredentialsProvider, BasicAWSCredentials}
# MAGIC import java.nio.ByteBuffer
# MAGIC import scala.util.Random
# MAGIC
# MAGIC // Verify that the Kinesis settings have been set
# MAGIC require(!awsAccessKeyId.contains("YOUR"), "AWS Access Key has not been set")
# MAGIC require(!awsSecretKey.contains("YOUR"), "AWS Access Secret Key has not been set")
# MAGIC require(!kinesisStreamName.contains("YOUR"), "Kinesis stream has not been set")
# MAGIC require(!kinesisRegion.contains("YOUR"), "Kinesis region has not been set")
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %scala
# MAGIC // Create the low-level Kinesis Client from the AWS Java SDK.
# MAGIC val kinesisClient = AmazonKinesisClientBuilder.standard()
# MAGIC   .withRegion(kinesisRegion)
# MAGIC   .withCredentials(new AWSStaticCredentialsProvider(new BasicAWSCredentials(awsAccessKeyId, awsSecretKey)))
# MAGIC   .build()
# MAGIC
# MAGIC println(s"Putting words onto stream $kinesisStreamName")
# MAGIC var lastSequenceNumber: String = null
# MAGIC
# MAGIC for (i <- 0 to 10) {
# MAGIC   val time = System.currentTimeMillis
# MAGIC   // Generate words: fox in sox
# MAGIC   for (word <- Seq("Through", "three", "cheese", "trees", "three", "free", "fleas", "flew", "While", "these", "fleas", "flew", "freezy", "breeze", "blew", "Freezy", "breeze", "made", "these", "three", "trees", "freeze", "Freezy", "trees", "made", "these", "trees", "cheese", "freeze", "That's", "what", "made", "these", "three", "free", "fleas", "sneeze")) {
# MAGIC     val data = s"$word"
# MAGIC     val partitionKey = s"$word"
# MAGIC     val request = new PutRecordRequest()
# MAGIC         .withStreamName(kinesisStreamName)
# MAGIC         .withPartitionKey(partitionKey)
# MAGIC         .withData(ByteBuffer.wrap(data.getBytes()))
# MAGIC     if (lastSequenceNumber != null) {
# MAGIC       request.setSequenceNumberForOrdering(lastSequenceNumber)
# MAGIC     }    
# MAGIC     val result = kinesisClient.putRecord(request)
# MAGIC     lastSequenceNumber = result.getSequenceNumber()
# MAGIC   }
# MAGIC   Thread.sleep(math.max(10000 - (System.currentTimeMillis - time), 0)) // loop around every ~10 seconds 
# MAGIC }
# MAGIC

# COMMAND ----------

