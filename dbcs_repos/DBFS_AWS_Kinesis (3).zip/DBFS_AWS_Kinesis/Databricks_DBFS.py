# Databricks notebook source
dbutils.fs.help()

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/jars")

# COMMAND ----------

dbutils.fs.ls("dbfs:/FileStore/jars/maven/com/")

# COMMAND ----------

# MAGIC %sh
# MAGIC ls /databricks/jars

# COMMAND ----------

# MAGIC %sh
# MAGIC ls /databricks/

# COMMAND ----------

# MAGIC %sh
# MAGIC more  init_scripts

# COMMAND ----------

# MAGIC %sh
# MAGIC ls data/

# COMMAND ----------

