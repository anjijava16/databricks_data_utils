# Databricks notebook source
# MAGIC
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px; height: 163px">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab 8: Querying from SageMaker vs from Parquet
# MAGIC
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) In this lab you:<br>
# MAGIC  - Deploy a model to SageMaker
# MAGIC  - Set up querying through a parquet file
# MAGIC  - Conduct time comparisons between the 2 methods

# COMMAND ----------

# MAGIC %run "./../Includes/Classroom-Setup"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Set up SageMaker
# MAGIC
# MAGIC Run the following cell to deploy our Airbnb model to SageMaker.

# COMMAND ----------

import json
import os
import boto3

# Set AWS credentials as environment variables
os.environ["AWS_ACCESS_KEY_ID"] = 'AKIAI4T2MLVBUB372FAA'
os.environ["AWS_SECRET_ACCESS_KEY"] = 'g1lSUmTtP2Y5TM4G3nryqg4TysUeKuJLKG0EYAZE' # READ ONLY ACCESS KEYS
os.environ["AWS_DEFAULT_REGION"] = 'us-west-2'


def query_endpoint_example(inputs, appName="airbnb-latest-0001", verbose=True):
  if verbose:
    print("Sending batch prediction request with inputs: {}".format(inputs))
  client = boto3.session.Session().client("sagemaker-runtime", "us-west-2")
  
  response = client.invoke_endpoint(
      EndpointName=appName,
      Body=json.dumps(inputs),
      ContentType='application/json',
  )
  preds = response['Body'].read().decode("ascii")
  preds = json.loads(preds)
  
  if verbose:
    print("Received response: {}".format(preds))
  return preds

def check_status(appName):
  sage_client = boto3.client('sagemaker', region_name="us-west-2")
  endpoint_description = sage_client.describe_endpoint(EndpointName=appName)
  endpoint_status = endpoint_description["EndpointStatus"]
  return endpoint_status

print("Application status is: {}".format(check_status(appName="airbnb-latest-0001")))

# COMMAND ----------

# MAGIC %md
# MAGIC Load in airbnb data to use as inputs for our queries.
# MAGIC
# MAGIC Reference the helper function in the 08-Real-Time-Deployment notebook to complete the `random_n_samples_sagemaker` function so that it connects to the `sagemaker-runtime` client and sends the record in the appropriate JSON format.

# COMMAND ----------

# TODO

import pandas as pd
import random
from sklearn.model_selection import train_test_split

df = pd.read_csv("/dbfs/mnt/training/airbnb/sf-listings/airbnb-cleaned-mlflow.csv")
X_train, X_test, y_train, y_test = train_test_split(df.drop(["price"], axis=1), df[["price"]].values.ravel(), random_state=42)

def random_n_samples_sagemaker(n, df=X_train, verbose=False):
  
  # FILL_IN
  
  return query_endpoint_example( FILL_IN , appName="airbnb-latest-0001", verbose=verbose)

# COMMAND ----------

# MAGIC %md
# MAGIC Check that the output of `random_n_samples_sagemaker` is what you expect.

# COMMAND ----------

random_n_samples_sagemaker(5, verbose=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using Parquet File
# MAGIC
# MAGIC Read in the Airbnb parquet file as a Spark DataFrame.

# COMMAND ----------

prediction_df = spark.read.parquet("/mnt/training/airbnb/sf-listings/prediction.parquet") 
display(prediction_df)

# COMMAND ----------

# MAGIC %md
# MAGIC Complete the following helper function `random_n_samples_parquet` to return `n` random queries from `predictions_df`.

# COMMAND ----------

# TODO
from pyspark.sql.functions import col

def random_n_samples_parquet(n, df=prediction_df):

  # get n ids to query using
  query_ids = # FILL_IN
  
  # get prediction of each row of 'query_ids'
  preds = []
  for i in query_ids:
    pred = # FILL_IN
    preds.append(pred)
    
  return preds

# COMMAND ----------

# MAGIC %md
# MAGIC Check that the output of `random_n_samples_parquet` is what you expect.

# COMMAND ----------

random_n_samples_parquet(5)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Time Comparisons
# MAGIC
# MAGIC Let's compare the time it takes to get the result of a single query from SageMaker and from a parquet file.

# COMMAND ----------

batch_size = 1

# COMMAND ----------

# MAGIC %timeit -n5 random_n_samples_sagemaker(batch_size)

# COMMAND ----------

# MAGIC %timeit -n5 random_n_samples_parquet(batch_size)

# COMMAND ----------

# MAGIC %md
# MAGIC Using the read in parquet file is faster!
# MAGIC
# MAGIC But what if we want to ask multiple queries? Increase `batch_size` up to 30 and see which method is faster with a larger number of queries.

# COMMAND ----------

batch_size = 30

# COMMAND ----------

# MAGIC %timeit -n5 random_n_samples_sagemaker(batch_size)

# COMMAND ----------

# MAGIC %timeit -n5 random_n_samples_parquet(batch_size)

# COMMAND ----------

# MAGIC %md
# MAGIC Which performed better?  What are the trade-offs between using the two in production?
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2019 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>