// Databricks notebook source
// MAGIC
// MAGIC %md # Course: DataFrames
// MAGIC * Version 1.3.2
// MAGIC * Built 2019-05-08 02:41:25 UTC
// MAGIC
// MAGIC Copyright 2019 Databricks, Inc.