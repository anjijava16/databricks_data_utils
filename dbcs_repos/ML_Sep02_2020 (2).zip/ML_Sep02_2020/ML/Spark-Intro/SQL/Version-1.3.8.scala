// Databricks notebook source
// MAGIC
// MAGIC %md # Course: Spark-SQL
// MAGIC * Version 1.3.8
// MAGIC * Built 2019-05-08 02:52:43 UTC
// MAGIC
// MAGIC Copyright 2019 Databricks, Inc.