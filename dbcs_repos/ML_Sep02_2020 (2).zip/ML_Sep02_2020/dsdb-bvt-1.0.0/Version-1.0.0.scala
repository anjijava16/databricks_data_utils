// Databricks notebook source
// MAGIC
// MAGIC %md # Course: dsdb-bvt
// MAGIC * Version 1.0.0
// MAGIC * Built 2020-08-26 16:43:34 UTC
// MAGIC * Git revision: 974157389a03268bfca747114ac643314c8390f6
// MAGIC
// MAGIC Copyright © 2020 Databricks, Inc.