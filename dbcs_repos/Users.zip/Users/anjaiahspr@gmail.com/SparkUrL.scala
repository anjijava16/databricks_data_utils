// Databricks notebook source
val html = scala.io.Source.fromURL("https://health.data.ny.gov/api/views/jxy9-yhdk/rows.json?accessType=DOWNLOAD").mkString
//val list = html.split("\n").filter(_ != "").map(_.trim)
val rdds = sc.parallelize(Seq(html))
//val rdd = sc.parallelize(Seq(jsonStr))
//val df = spark.read.json(rdds)
val dfs= spark.read.option("multiline","true").json(rdds)
 dfs.show()
//rdds.take(10)
//spark.sql("SELECT url_col, parse_url(`url_col`, 'HOST') as HOST, parse_url(`url_col`,'QUERY') as QUERY from temp").show(false)


// COMMAND ----------

