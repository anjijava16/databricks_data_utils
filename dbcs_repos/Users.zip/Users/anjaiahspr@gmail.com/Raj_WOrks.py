# Databricks notebook source
df=spark.read.csv("/FileStore/tables/train.csv",header = 'True',inferSchema='True')

# COMMAND ----------

df.printSchema()

# COMMAND ----------

display(df)