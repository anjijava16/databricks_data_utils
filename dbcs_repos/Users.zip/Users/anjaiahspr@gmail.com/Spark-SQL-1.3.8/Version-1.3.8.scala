// Databricks notebook source
// MAGIC
// MAGIC %md # Course: Spark-SQL
// MAGIC * Version 1.3.8
// MAGIC * Built 2019-03-25 03:07:54 UTC
// MAGIC
// MAGIC Copyright \u00a9 2019 Databricks, Inc.