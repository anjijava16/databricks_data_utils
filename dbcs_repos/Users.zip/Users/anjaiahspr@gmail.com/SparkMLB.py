# Databricks notebook source
df=spark.read.csv("/FileStore/tables/home_data.csv",header='true',inferSchema='true')
df.printSchema()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df=spark.read.csv("/FileStore/tables/people.csv",header='true',inferSchema='true',sep=";")
display(df)


# COMMAND ----------

json_df=spark.read.json("/FileStore/tables/people.json")
display(json_df)

# COMMAND ----------

json_df.select("name","age").show(2)

# COMMAND ----------

json_df.groupBy("age").count().show()

# COMMAND ----------

json_df.createOrReplaceTempView("people")

# COMMAND ----------

spark_df=spark.sql("""select * from people""")

# COMMAND ----------

spark_df.show(10)

# COMMAND ----------

train_df=spark.read.csv("/FileStore/tables/train.csv",header='true',inferSchema='true',sep=",")
train_df.show(10)

# COMMAND ----------



# COMMAND ----------

#train_df.filter("Embarked='S'").count()
#train_df.filter("Embarked='C'").count()
train_df.filter("Embarked='Q'").count()



# COMMAND ----------



# COMMAND ----------

titanic_df=train_df

# COMMAND ----------

#titanic_df.select("Survived","Pclass","Embarked").show()
groupBy_ouput=titanic_df.groupBy("Survived").count()

# COMMAND ----------

display(groupBy_ouput)

# COMMAND ----------

pclass_df=titanic_df.groupBy("Pclass","Survived").count()

# COMMAND ----------

#def null_value_count(df):

AWSAccessKeyId="AKIAJLOXD44LWDJTRD2Q"
AWSSecretKey="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"
ACCESS_KEY = "AKIAJLOXD44LWDJTRD2Q"
SECRET_KEY ="am/Z8qhP4f6gTWC6tYz8EpOCEA2quuJLvicd0BVp"
ENCODED_SECRET_KEY = SECRET_KEY.replace("/", "%2F")
AWS_BUCKET_NAME = "mmtechsoft"
MOUNT_NAME = "data"

dbutils.fs.mount("s3a://%s:%s@%s" % (ACCESS_KEY, ENCODED_SECRET_KEY, AWS_BUCKET_NAME), "/%s" % MOUNT_NAME)
display(dbutils.fs.ls("/mnt/%s" % MOUNT_NAME))
  

# COMMAND ----------

df=spark.read.csv("/mmtechsoft/data/home_data.csv",header='true',inferSchema='true')
df.printSchema()