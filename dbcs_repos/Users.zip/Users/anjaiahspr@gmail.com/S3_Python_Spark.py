# Databricks notebook source
sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", "xxx")
sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", "xxx/9WddPVzl/WuwcLXr")

# COMMAND ----------

df = spark.read.csv("s3a://mds-data-spark/input.csv",header=False,sep="|");

# COMMAND ----------

display(df)

# COMMAND ----------

#df.write.format("csv")
df.write.save("s3a://mds-data-spark/output/processing_dt=2019-12-12/", format='csv', header=True)

# COMMAND ----------

df=spark.read.format("jdbc").option("url", "jdbc:mysql://101.53.145.200:3306/mmtechso_reportdb").option("driver", "com.mysql.jdbc.Driver").option("dbtable", "customer_test").option("user", "welcome").option("password", "bu3anyper").load()