# Databricks notebook source
#sc

#spark

spark.version

# COMMAND ----------

df= spark.read.csv("/FileStore/tables/train.csv",header="True",inferSchema="True")


# COMMAND ----------


display(df)

# COMMAND ----------

df.select("PassengerId","Pclass","Embarked").show()

# COMMAND ----------

df.groupBy("Survived").count().show()

# COMMAND ----------

