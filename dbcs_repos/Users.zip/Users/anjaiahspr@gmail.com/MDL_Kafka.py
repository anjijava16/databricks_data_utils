# Databricks notebook source
print("Welcome ")

# COMMAND ----------

sc._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", "AKIAIQ34EN67YAZ6KWEA")
sc._jsc.hadoopConfiguration().set("fs.s3n.awsSecretAccessKey", "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")

# COMMAND ----------

df = spark.read.csv("s3a://mds-data-spark/input.csv",header=True,sep="|");

# COMMAND ----------

display(df)  