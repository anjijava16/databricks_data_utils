// Databricks notebook source
// MAGIC
// MAGIC %md # Course: ETL-Part-1
// MAGIC * Version 1.2.8
// MAGIC * Built 2019-03-25 03:09:55 UTC
// MAGIC
// MAGIC Copyright \u00a9 2019 Databricks, Inc.