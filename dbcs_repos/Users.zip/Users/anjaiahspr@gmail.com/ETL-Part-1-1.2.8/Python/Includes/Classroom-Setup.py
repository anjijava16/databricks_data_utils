# Databricks notebook source
# MAGIC
# MAGIC %python
# MAGIC course_name = "ETL Part 1"

# COMMAND ----------

# MAGIC %run "./Dataset-Mounts"

# COMMAND ----------

# MAGIC %run "./Test-Library"

# COMMAND ----------

# MAGIC %python
# MAGIC displayHTML("All done!")
# MAGIC