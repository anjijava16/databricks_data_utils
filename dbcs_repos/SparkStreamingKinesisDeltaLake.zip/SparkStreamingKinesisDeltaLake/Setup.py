# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" width="555" height="64">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Getting Started on Databricks
# MAGIC
# MAGIC Databricks&reg; provides a notebook-oriented Apache Spark&trade; as-a-service workspace environment, making it easy to manage clusters and explore data interactively.
# MAGIC
# MAGIC ### Use cases for Apache Spark 
# MAGIC * Read and process huge files and data sets
# MAGIC * Query, explore, and visualize data sets
# MAGIC * Join disparate data sets found in data lakes
# MAGIC * Train and evaluate machine learning models
# MAGIC * Process live streams of data
# MAGIC * Perform analysis on large graph data sets and social networks

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Step 1
# MAGIC
# MAGIC Log into Databricks:
# MAGIC 0. Open Chrome or Firefox.
# MAGIC 0. Navigate to your Databricks environment (each installation of Databricks is commonly referred to as a **shard**).
# MAGIC   * For the **Community Edition** shard, use <a href="https://community.cloud.databricks.com" target="_blank">https&#58;//community.cloud.databricks.com</a>.
# MAGIC   * If you don't have a **Community Edition** account, sign up for a <a href="https://databricks.com/try-databricks" target="_blank">free account</a> now.
# MAGIC   * If you use a private shard, please consult with your employer for the URL, username, and password.
# MAGIC 0. Sign in with your email address and password.
# MAGIC <div><img src="https://s3-us-west-2.amazonaws.com/curriculum-release/images/eLearning/login.png" style="height: 400px; border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; box-shadow: 5px 5px 5px #aaa"/></div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Step 2
# MAGIC
# MAGIC Import the lab files into your Databricks Workspace:
# MAGIC 0. In the left sidebar, click **Home**.
# MAGIC <div><img src="https://s3-us-west-2.amazonaws.com/curriculum-release/images/eLearning/home.png" style="height: 200px"/></div><br/>
# MAGIC 0. Right-click your home folder, then click **Import**.
# MAGIC <div><img src="https://s3-us-west-2.amazonaws.com/curriculum-release/images/eLearning/import-labs-1.png" style="height: 175px; border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; box-shadow: 5px 5px 5px #aaa"/></div><br/>
# MAGIC 0. In the popup, click **URL**.
# MAGIC <div><img src="https://s3-us-west-2.amazonaws.com/curriculum-release/images/eLearning/import-labs-2.png" style="height: 125px; border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; box-shadow: 5px 5px 5px #aaa"/></div><br/>
# MAGIC 0. Paste the following URL:<br/>
# MAGIC <input type="text" value="https://files.training.databricks.com/events/webinar-2019-05/pipelines/Lessons.dbc" style="width: 40em" onDblClick="event.stopPropagation()" />
# MAGIC 0. Click the **Import** button.  The import process may take a couple of minutes to complete.
# MAGIC <div><img src="https://s3-us-west-2.amazonaws.com/curriculum-release/images/eLearning/import-labs-3.png" style="border: 1px solid #aaa; border-radius: 10px 10px 10px 10px; box-shadow: 5px 5px 5px #aaa; width: 600px"/></div><br/>
# MAGIC 0. Wait for the import to finish. This can take a minute or so to complete.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### Step 3
# MAGIC
# MAGIC Verify the notebook was properly imported:
# MAGIC 1. In the left sidebar, click **Home**.
# MAGIC 2. Select your home folder.
# MAGIC 3. Select the folder **Spark-Intro**.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Additional Topics & Resources
# MAGIC **Q:** Are there additional docs I can reference to find my way around Databricks?  
# MAGIC **A:** See <a href="https://docs.databricks.com/user-guide/getting-started.html" target="_blank">Getting Started with Databricks</a>.
# MAGIC
# MAGIC **Q:** Where can I learn more about the cluster configuration options?  
# MAGIC **A:** See <a href="https://docs.databricks.com/user-guide/clusters/index.html" target="_blank">Spark Clusters on Databricks</a>.
# MAGIC
# MAGIC **Q:** Can I import formats other than .dbc files?  
# MAGIC **A:** Yes, see <a href="https://docs.databricks.com/user-guide/notebooks/index.html#importing-notebooks" target="_blank">Importing Notebooks</a>.
# MAGIC
# MAGIC **Q:** Can I use browsers other than Chrome or Firefox?  
# MAGIC **A:** Databricks is tested for Chrome and Firefox.  It does work on Internet Explorer 11 and Safari; however, it is possible some user-interface features may not work properly.
# MAGIC
# MAGIC **Q:** Can I install the courseware notebooks into a non-Databricks distribution of Spark?  
# MAGIC **A:** No, the files that contain the courseware are in a Databricks specific format (DBC).
# MAGIC
# MAGIC **Q:** Do I have to have a paid Databricks subscription to complete this course?  
# MAGIC **A:** No, you can sign up for a free <a href="https://databricks.com/try-databricks" target="_blank">Community Edition</a> account from Databricks.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2019 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="http://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="http://help.databricks.com/">Support</a>