// Databricks notebook source
// MAGIC %sql

// COMMAND ----------



// COMMAND ----------

// MAGIC %sql
// MAGIC CREATE DATABASE EMP

// COMMAND ----------



// COMMAND ----------

// MAGIC %sql
// MAGIC
// MAGIC CREATE TABLE IF NOT EXISTS EMP.people1 (
// MAGIC id INT,
// MAGIC firstName STRING,
// MAGIC middleName STRING,
// MAGIC lastName STRING,
// MAGIC gender STRING,
// MAGIC birthDate TIMESTAMP,
// MAGIC ssn STRING,
// MAGIC salary INT
// MAGIC )

// COMMAND ----------

// MAGIC %sql
// MAGIC INSERT INTO EMP.people1(id,firstName,middleName,lastName) values(11,'jai','sai','han');
// MAGIC INSERT INTO EMP.people1(id,firstName,middleName,lastName) values(11,'jai','sai','han');
// MAGIC INSERT INTO EMP.people1(id,firstName,middleName,lastName) values(11,'jai','sai','han');
// MAGIC INSERT INTO EMP.people1(id,firstName,middleName,lastName) values(11,'jai','sai','han');
// MAGIC INSERT INTO EMP.people1(id,firstName,middleName,lastName) values(11,'jai','sai','han');

// COMMAND ----------

// MAGIC %sql
// MAGIC INSERT INTO EMP.people(id,firstName,middleName,lastName) values(11,'jai','sai','han')
// MAGIC

// COMMAND ----------

// MAGIC %sql
// MAGIC describe extended EMP.people1

// COMMAND ----------

// MAGIC %fs 
// MAGIC ls dbfs:/user/hive/warehouse/emp.db/people1

// COMMAND ----------

// MAGIC %sql
// MAGIC show create table EMP.people

// COMMAND ----------

// MAGIC %sql
// MAGIC select * from EMP.people

// COMMAND ----------

// MAGIC %fs ls 'dbfs:/user/hive/warehouse/emp.db/people1/'

// COMMAND ----------

// MAGIC %fs
// MAGIC ls dbfs:/user/hive/warehouse/emp.db/people1/_delta_log/

// COMMAND ----------

// MAGIC %fs
// MAGIC head dbfs:/user/hive/warehouse/emp.db/people1/_delta_log/.s3-optimization-0

// COMMAND ----------

// MAGIC %sql
// MAGIC
// MAGIC CREATE TABLE IF NOT EXISTS EMP.peoplepar (
// MAGIC id INT,
// MAGIC firstName STRING,
// MAGIC middleName STRING,
// MAGIC lastName STRING,
// MAGIC gender STRING,
// MAGIC birthDate TIMESTAMP,
// MAGIC ssn STRING,
// MAGIC salary INT
// MAGIC ) USING PARQUET

// COMMAND ----------

// MAGIC %sql
// MAGIC
// MAGIC CREATE TABLE IF NOT EXISTS EMP.peopleORC (
// MAGIC id INT,
// MAGIC firstName STRING,
// MAGIC middleName STRING,
// MAGIC lastName STRING,
// MAGIC gender STRING,
// MAGIC birthDate TIMESTAMP,
// MAGIC ssn STRING,
// MAGIC salary INT
// MAGIC ) USING ORC